import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MailerModule } from '@nestjs-modules/mailer';
import { AppController } from './app.controller';
import { AppService } from './app.service';

import { Role } from './entities/Role';
import { User } from './entities/User';
import { Booking } from './entities/Booking';
import { Room } from './entities/Room';
import { RoomType } from './entities/RoomType';
import { Hotel } from './entities/Hotel';
import { Restaurant } from './entities/Restaurant';
import { Table } from './entities/Table';
import { Order } from './entities/Order';
import { OrderDish } from './entities/OrderDish';
import { Dish } from './entities/Dish';
import { DishIngredient } from './entities/DishIngredient';
import { Ingredient } from './entities/Ingredient';
import { IngredientsModule } from './ingredients/ingredients.module';
import { AuthModule } from './auth/auth.module';
import { MenuModule } from './menu/menu.module';
import { OrdersModule } from './orders/orders.module';
import { UsersModule } from './users/users.module';
import { RoomsModule } from './rooms/rooms.module';
import { BookingsModule } from './bookings/bookings.module';
import { TablesModule } from './tables/tables.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    TypeOrmModule.forRoot({
      type: 'postgres',
      url: process.env.POSTGRES_URI,
      entities: [
        Role, User, Booking, Room, RoomType, Hotel,
        Restaurant, Table, Order, OrderDish, Dish,
        DishIngredient, Ingredient,
      ],
      synchronize: true, // Вмикаємо авто-створення таблиць
    }),
    MailerModule.forRoot({
      transport: {
        host: process.env.SMTP_HOST || 'smtp.ethereal.email',
        port: parseInt(process.env.SMTP_PORT || '587', 10),
        auth: {
          user: process.env.SMTP_USER || 'ethereal.user@ethereal.email',
          pass: process.env.SMTP_PASS || 'etherealpassword',
        },
      },
      defaults: {
        from: '"Hotel Management System" <noreply@hotel.com>',
      },
    }),
    IngredientsModule,
    AuthModule,
    MenuModule,
    OrdersModule,
    UsersModule,
    RoomsModule,
    BookingsModule,
    TablesModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
