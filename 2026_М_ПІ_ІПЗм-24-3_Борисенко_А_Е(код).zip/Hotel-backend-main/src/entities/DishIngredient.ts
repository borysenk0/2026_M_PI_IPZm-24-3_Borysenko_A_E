import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Dish } from './Dish';
import { Ingredient } from './Ingredient';

@Entity('dish_ingredient')
export class DishIngredient {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ name: 'dish_id' })
  dish_id: number;

  @ManyToOne(() => Dish, dish => dish.dishIngredients)
  @JoinColumn({ name: 'dish_id' })
  dish: Dish;

  @Column({ name: 'ingredient_id' })
  ingredient_id: number;

  @ManyToOne(() => Ingredient, ingredient => ingredient.dishIngredients)
  @JoinColumn({ name: 'ingredient_id' })
  ingredient: Ingredient;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  quantity_required: number;
}
