import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Order } from './Order';
import { Dish } from './Dish';

@Entity('order_dish')
export class OrderDish {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ name: 'order_id' })
  order_id: number;

  @ManyToOne(() => Order, order => order.orderDishes)
  @JoinColumn({ name: 'order_id' })
  order: Order;

  @Column({ name: 'dish_id' })
  dish_id: number;

  @ManyToOne(() => Dish, dish => dish.orderDishes)
  @JoinColumn({ name: 'dish_id' })
  dish: Dish;

  @Column()
  quantity: number;
}
