import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { OrderDish } from './OrderDish';
import { DishIngredient } from './DishIngredient';

@Entity('dishes')
export class Dish {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  cost: number;

  @OneToMany(() => OrderDish, orderDish => orderDish.dish)
  orderDishes: OrderDish[];

  @OneToMany(() => DishIngredient, dishIngredient => dishIngredient.dish, { cascade: true })
  dishIngredients: DishIngredient[];
}
