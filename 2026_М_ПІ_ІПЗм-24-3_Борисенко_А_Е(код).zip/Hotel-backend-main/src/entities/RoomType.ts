import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { Hotel } from './Hotel';
import { Room } from './Room';

@Entity('room_types')
export class RoomType {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ name: 'room_class_id', nullable: true })
  room_class_id: number;

  @Column({ name: 'hotel_id' })
  hotel_id: number;

  @ManyToOne(() => Hotel, hotel => hotel.roomTypes)
  @JoinColumn({ name: 'hotel_id' })
  hotel: Hotel;

  @Column()
  max_occupancy: number;

  @Column()
  sleeping_place: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  price_per_night: number;

  @OneToMany(() => Room, room => room.roomType)
  rooms: Room[];
}
