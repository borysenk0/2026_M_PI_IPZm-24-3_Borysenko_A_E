import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { User } from './User';
import { Table } from './Table';
import { Booking } from './Booking';
import { OrderDish } from './OrderDish';

@Entity('orders')
export class Order {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ name: 'user_id', nullable: true })
  user_id: number;

  @ManyToOne(() => User, user => user.orders)
  @JoinColumn({ name: 'user_id' })
  user: User;

  @Column({ name: 'table_id', nullable: true })
  table_id: number;

  @ManyToOne(() => Table, table => table.orders)
  @JoinColumn({ name: 'table_id' })
  table: Table;

  @Column({ name: 'booking_id', nullable: true })
  booking_id: number;

  @ManyToOne(() => Booking, booking => booking.orders)
  @JoinColumn({ name: 'booking_id' })
  booking: Booking;

  @Column()
  status: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  total_price: number;

  @Column({ type: 'date' })
  created_at: string;

  @Column({ type: 'int', default: 15 })
  estimated_prep_minutes: number;

  @OneToMany(() => OrderDish, orderDish => orderDish.order)
  orderDishes: OrderDish[];
}
