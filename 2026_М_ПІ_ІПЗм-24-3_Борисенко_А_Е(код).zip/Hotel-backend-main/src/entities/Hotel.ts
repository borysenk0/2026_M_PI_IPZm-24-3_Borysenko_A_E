import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { Room } from './Room';
import { RoomType } from './RoomType';
import { Restaurant } from './Restaurant';

@Entity('hotels')
export class Hotel {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ type: 'text' })
  description: string;

  @OneToMany(() => RoomType, rt => rt.hotel)
  roomTypes: RoomType[];

  @OneToMany(() => Room, r => r.hotel)
  rooms: Room[];

  @OneToMany(() => Restaurant, r => r.hotel)
  restaurants: Restaurant[];
}
