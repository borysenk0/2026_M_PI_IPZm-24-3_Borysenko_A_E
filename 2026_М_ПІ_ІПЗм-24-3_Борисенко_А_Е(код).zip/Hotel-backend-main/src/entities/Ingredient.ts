import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { DishIngredient } from './DishIngredient';

@Entity('ingredients')
export class Ingredient {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  count: number;

  @Column()
  unit: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  min_threshold: number;

  @OneToMany(() => DishIngredient, dishIngredient => dishIngredient.ingredient)
  dishIngredients: DishIngredient[];
}
