import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { Hotel } from './Hotel';
import { Table } from './Table';

@Entity('restaurants')
export class Restaurant {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ name: 'hotel_id' })
  hotel_id: number;

  @ManyToOne(() => Hotel, hotel => hotel.restaurants)
  @JoinColumn({ name: 'hotel_id' })
  hotel: Hotel;

  @OneToMany(() => Table, table => table.restaurant)
  tables: Table[];
}
