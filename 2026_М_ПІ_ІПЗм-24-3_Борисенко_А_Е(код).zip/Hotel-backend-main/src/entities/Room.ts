import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { Hotel } from './Hotel';
import { RoomType } from './RoomType';
import { Booking } from './Booking';

@Entity('rooms')
export class Room {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  number: number;

  @Column()
  status: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ name: 'hotel_id' })
  hotel_id: number;

  @ManyToOne(() => Hotel, hotel => hotel.rooms)
  @JoinColumn({ name: 'hotel_id' })
  hotel: Hotel;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  cost: number;

  @Column({ name: 'room_type_id' })
  room_type_id: number;

  @ManyToOne(() => RoomType, rt => rt.rooms)
  @JoinColumn({ name: 'room_type_id' })
  roomType: RoomType;

  @OneToMany(() => Booking, booking => booking.room)
  bookings: Booking[];
}
