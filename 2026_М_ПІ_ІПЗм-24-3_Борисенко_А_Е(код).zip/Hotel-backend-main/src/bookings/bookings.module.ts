import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BookingsService } from './bookings.service';
import { BookingsController } from './bookings.controller';
import { Booking } from '../entities/Booking';
import { Room } from '../entities/Room';

@Module({
  imports: [TypeOrmModule.forFeature([Booking, Room])],
  providers: [BookingsService],
  controllers: [BookingsController],
})
export class BookingsModule {}
