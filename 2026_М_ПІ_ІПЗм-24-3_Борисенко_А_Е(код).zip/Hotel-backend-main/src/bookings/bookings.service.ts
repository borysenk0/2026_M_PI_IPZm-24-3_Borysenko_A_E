import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Booking } from '../entities/Booking';
import { Room } from '../entities/Room';

@Injectable()
export class BookingsService {
  constructor(
    @InjectRepository(Booking) private bookingRepo: Repository<Booking>,
    @InjectRepository(Room) private roomRepo: Repository<Room>,
  ) { }

  findAll() {
    return this.bookingRepo.find({
      order: { id: 'DESC' },
      relations: ['user', 'room']
    });
  }

  async create(data: Partial<Booking>) {
    const booking = this.bookingRepo.create(data);
    const savedBooking = await this.bookingRepo.save(booking);
    await this.syncRoomStatus(savedBooking.room_id, savedBooking.status);
    return savedBooking;
  }

  async update(id: number, data: Partial<Booking>) {
    const booking = await this.bookingRepo.findOneBy({ id });
    if (!booking) throw new NotFoundException();

    this.bookingRepo.merge(booking, data);
    const updatedBooking = await this.bookingRepo.save(booking);

    if (data.status) {
      await this.syncRoomStatus(updatedBooking.room_id, updatedBooking.status);
    }

    return updatedBooking;
  }

  async remove(id: number) {
    const booking = await this.bookingRepo.findOneBy({ id });
    if (!booking) throw new NotFoundException();
    return this.bookingRepo.remove(booking);
  }

  private async syncRoomStatus(roomId: number, bookingStatus: string) {
    if (!roomId || !bookingStatus) return;
    const room = await this.roomRepo.findOneBy({ id: roomId });
    if (!room) return;

    const bStatus = bookingStatus.toUpperCase();
    let newRoomStatus: string | null = null;

    if (bStatus === 'CHECKED_IN') {
      newRoomStatus = 'OCCUPIED';
    } else if (bStatus === 'CHECKED_OUT' || bStatus === 'CANCELLED') {
      newRoomStatus = 'AVAILABLE';
    } else if (bStatus === 'CONFIRMED') {
      newRoomStatus = 'RESERVED';
    }

    if (newRoomStatus && room.status.toUpperCase() !== newRoomStatus) {
      room.status = newRoomStatus;
      await this.roomRepo.save(room);
    }
  }
}
