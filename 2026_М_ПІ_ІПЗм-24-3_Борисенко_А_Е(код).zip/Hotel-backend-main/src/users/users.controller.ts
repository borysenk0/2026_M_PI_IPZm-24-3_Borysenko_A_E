import { Controller, Get, Put, Delete, Body, Param, ParseIntPipe } from '@nestjs/common';
import { UsersService } from './users.service';

@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get()
  findAll() {
    return this.usersService.findAllUsers();
  }

  @Put(':id')
  update(@Param('id', ParseIntPipe) id: number, @Body() data: any) {
    // allow changing email, full_name, role_id
    const payload: any = {};
    if (data.email) payload.email = data.email;
    if (data.full_name) payload.full_name = data.full_name;
    if (data.role_id) payload.role_id = data.role_id;
    
    return this.usersService.updateUser(id, payload);
  }

  @Delete(':id')
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.usersService.removeUser(id);
  }

  @Get('roles')
  getRoles() {
    return this.usersService.findAllRoles();
  }
}
