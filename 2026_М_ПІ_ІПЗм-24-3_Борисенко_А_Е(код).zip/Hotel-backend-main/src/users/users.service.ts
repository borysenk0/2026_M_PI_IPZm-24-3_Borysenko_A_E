import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { User } from '../entities/User';
import { Role } from '../entities/Role';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User) private userRepo: Repository<User>,
    @InjectRepository(Role) private roleRepo: Repository<Role>,
  ) {}

  findAllUsers() {
    return this.userRepo.find({ order: { id: 'ASC' }, relations: ['role'] });
  }

  async updateUser(id: number, data: Partial<User>) {
    const user = await this.userRepo.findOne({ where: { id } });
    if (!user) throw new NotFoundException('User not found');
    
    if (data.password_hash && !data.password_hash.startsWith('$2')) {
      // hash it if it's plaintext
      const salt = await bcrypt.genSalt();
      data.password_hash = await bcrypt.hash(data.password_hash, salt);
    }
    
    this.userRepo.merge(user, data);
    return this.userRepo.save(user);
  }

  async removeUser(id: number) {
    const user = await this.userRepo.findOne({ where: { id } });
    if (!user) throw new NotFoundException('User not found');
    return this.userRepo.remove(user);
  }

  findAllRoles() {
    return this.roleRepo.find({ order: { id: 'ASC' } });
  }
}
