import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Dish } from '../entities/Dish';
import { DishIngredient } from '../entities/DishIngredient';

@Injectable()
export class MenuService {
  constructor(
    @InjectRepository(Dish)
    private dishRepository: Repository<Dish>,
    @InjectRepository(DishIngredient)
    private dishIngredientRepo: Repository<DishIngredient>,
  ) {}

  findAll(): Promise<Dish[]> {
    return this.dishRepository.find({
      order: { id: 'ASC' },
      relations: ['dishIngredients', 'dishIngredients.ingredient'],
    });
  }

  async findOne(id: number): Promise<Dish | null> {
    return this.dishRepository.findOne({
      where: { id },
      relations: ['dishIngredients', 'dishIngredients.ingredient'],
    });
  }

  create(data: Partial<Dish>) {
    const dish = this.dishRepository.create(data);
    return this.dishRepository.save(dish);
  }

  async update(id: number, data: Partial<Dish>) {
    const dish = await this.dishRepository.findOneBy({ id });
    if (!dish) throw new NotFoundException();

    await this.dishIngredientRepo.delete({ dish_id: id });

    dish.name = data.name ?? dish.name;
    dish.cost = data.cost ?? dish.cost;
    await this.dishRepository.save(dish);

    if (data.dishIngredients && data.dishIngredients.length > 0) {
      const newIngredients = data.dishIngredients.map(di => {
        return this.dishIngredientRepo.create({
          dish_id: id,
          ingredient_id: di.ingredient_id,
          quantity_required: di.quantity_required,
        });
      });
      await this.dishIngredientRepo.save(newIngredients);
    }
    
    return this.findOne(id);
  }

  async remove(id: number) {
    const dish = await this.dishRepository.findOneBy({ id });
    if (!dish) throw new NotFoundException();
    return this.dishRepository.remove(dish);
  }
}
