import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MenuService } from './menu.service';
import { MenuController } from './menu.controller';
import { Dish } from '../entities/Dish';
import { DishIngredient } from '../entities/DishIngredient';

@Module({
  imports: [TypeOrmModule.forFeature([Dish, DishIngredient])],
  providers: [MenuService],
  controllers: [MenuController],
  exports: [MenuService],
})
export class MenuModule {}
