import { Injectable, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { User } from '../entities/User';
import { Role } from '../entities/Role';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User) private readonly userRepo: Repository<User>,
    @InjectRepository(Role) private readonly roleRepo: Repository<Role>,
    private readonly jwtService: JwtService,
  ) {}

  async validateUser(email: string, pass: string): Promise<any> {
    const user = await this.userRepo.findOne({
      where: { email },
      relations: ['role'],
    });

    if (user) {
      // Для seeded users де password_hash === 'hash' ми можемо перевірити як є
      const isSeededMatch = user.password_hash === 'hash' && pass === 'password';
      const isBcryptMatch = await bcrypt.compare(pass, user.password_hash).catch(() => false);

      if (isSeededMatch || isBcryptMatch || user.password_hash === pass) {
        const { password_hash, ...result } = user;
        return result;
      }
    }
    return null;
  }

  async login(user: any) {
    const payload = { email: user.email, sub: user.id, role: user.role?.name };
    return {
      access_token: this.jwtService.sign(payload),
      user: user,
    };
  }

  async register(full_name: string, email: string, pass: string) {
    // Шукаємо або створюємо роль 'user'
    let role = await this.roleRepo.findOne({ where: { name: 'user' } });
    if (!role) {
      role = this.roleRepo.create({ name: 'user' });
      await this.roleRepo.save(role);
    }

    const salt = await bcrypt.genSalt();
    const password_hash = await bcrypt.hash(pass, salt);

    const checkUser = await this.userRepo.findOne({ where: { email } });
    if (checkUser) {
      throw new UnauthorizedException('Email already exists');
    }

    const newUser = this.userRepo.create({
      full_name,
      email,
      password_hash,
      role_id: role.id,
    });

    const savedUser = await this.userRepo.save(newUser);
    savedUser.role = role;
    return this.login(savedUser);
  }
}
