import { Controller, Post, Body, UnauthorizedException, Get, Request } from '@nestjs/common';
import { AuthService } from './auth.service';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('login')
  async login(@Body() body: any) {
    const user = await this.authService.validateUser(body.email, body.password);
    if (!user) {
      throw new UnauthorizedException('Invalid credentials');
    }
    return this.authService.login(user);
  }

  @Post('register')
  async register(@Body() body: any) {
    return this.authService.register(body.full_name, body.email, body.password);
  }

  // Спеціальний роут для перевірки токену/отримання даних поточного юзера (для фронтенду)
  // Тут поки що найпростіший метод без JWT Guard, у майбутньому можна додати JwtAuthGuard
  @Get('me')
  async getProfile(@Request() req: any) {
    return req.user; // To be populated by Guard
  }
}
