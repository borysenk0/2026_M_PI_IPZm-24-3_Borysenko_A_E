import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Table } from '../entities/Table';

@Injectable()
export class TablesService {
  constructor(
    @InjectRepository(Table) private tableRepo: Repository<Table>,
  ) {}

  findAll() {
    return this.tableRepo.find({ order: { id: 'ASC' } });
  }

  create(data: Partial<Table>) {
    const table = this.tableRepo.create(data);
    return this.tableRepo.save(table);
  }

  async update(id: number, data: Partial<Table>) {
    const table = await this.tableRepo.findOneBy({ id });
    if (!table) throw new NotFoundException();
    this.tableRepo.merge(table, data);
    return this.tableRepo.save(table);
  }

  async remove(id: number) {
    const table = await this.tableRepo.findOneBy({ id });
    if (!table) throw new NotFoundException();
    return this.tableRepo.remove(table);
  }
}
