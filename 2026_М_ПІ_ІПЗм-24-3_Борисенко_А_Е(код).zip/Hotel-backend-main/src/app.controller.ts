import { Controller, Get } from '@nestjs/common';
import { AppService } from './app.service';
import { DataSource } from 'typeorm';
import { Restaurant } from './entities/Restaurant';
import { Hotel } from './entities/Hotel';

@Controller()
export class AppController {
  constructor(
    private readonly appService: AppService,
    private readonly dataSource: DataSource
  ) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  @Get('restaurants')
  getRestaurants() {
    return this.dataSource.getRepository(Restaurant).find();
  }

  @Get('hotels')
  getHotels() {
    return this.dataSource.getRepository(Hotel).find();
  }
}
