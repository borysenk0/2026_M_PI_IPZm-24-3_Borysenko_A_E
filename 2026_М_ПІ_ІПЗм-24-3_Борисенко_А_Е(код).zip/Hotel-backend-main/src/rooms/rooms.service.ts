import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Room } from '../entities/Room';

@Injectable()
export class RoomsService {
  constructor(
    @InjectRepository(Room) private roomRepo: Repository<Room>,
  ) {}

  findAll() {
    return this.roomRepo.find({ order: { id: 'ASC' } });
  }

  async update(id: number, data: Partial<Room>) {
    const room = await this.roomRepo.findOneBy({ id });
    if (!room) throw new NotFoundException('Room not found');
    this.roomRepo.merge(room, data);
    return this.roomRepo.save(room);
  }

  async remove(id: number) {
    const room = await this.roomRepo.findOneBy({ id });
    if (!room) throw new NotFoundException();
    return this.roomRepo.remove(room);
  }
}
