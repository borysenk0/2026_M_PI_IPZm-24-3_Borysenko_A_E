import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Ingredient } from '../entities/Ingredient';

@Injectable()
export class IngredientsService {
  constructor(
    @InjectRepository(Ingredient)
    private ingredientsRepository: Repository<Ingredient>,
  ) {}

  findAll(): Promise<Ingredient[]> {
    return this.ingredientsRepository.find({
      order: { id: 'ASC' },
    });
  }

  findOne(id: number): Promise<Ingredient | null> {
    return this.ingredientsRepository.findOneBy({ id });
  }

  async create(ingredientData: Partial<Ingredient>): Promise<Ingredient> {
    const newIngredient = this.ingredientsRepository.create(ingredientData);
    return this.ingredientsRepository.save(newIngredient);
  }

  async update(id: number, updateData: Partial<Ingredient>): Promise<Ingredient> {
    const ingredient = await this.findOne(id);
    if (!ingredient) {
      throw new NotFoundException(`Інгредієнт з ID ${id} не знайдено`);
    }
    this.ingredientsRepository.merge(ingredient, updateData);
    return this.ingredientsRepository.save(ingredient);
  }

  async remove(id: number): Promise<void> {
    const ingredient = await this.findOne(id);
    if (!ingredient) {
      throw new NotFoundException(`Інгредієнт з ID ${id} не знайдено`);
    }
    await this.ingredientsRepository.remove(ingredient);
  }
}
