import { DataSource } from 'typeorm';
import { config } from 'dotenv';

import { Role } from './entities/Role';
import { User } from './entities/User';
import { Hotel } from './entities/Hotel';
import { Restaurant } from './entities/Restaurant';
import { RoomType } from './entities/RoomType';
import { Room } from './entities/Room';
import { Table } from './entities/Table';
import { Dish } from './entities/Dish';
import { Ingredient } from './entities/Ingredient';
import { DishIngredient } from './entities/DishIngredient';
import { Booking } from './entities/Booking';
import { Order } from './entities/Order';
import { OrderDish } from './entities/OrderDish';

config();

const AppDataSource = new DataSource({
  type: 'postgres',
  url: process.env.POSTGRES_URI,
  entities: [
    Role, User, Hotel, Restaurant, RoomType, Room, Table, Dish, Ingredient, DishIngredient,
    Booking, Order, OrderDish
  ],
  synchronize: true, // Вмикає синхронізацію структури БД під час сідування
});

async function runSeed() {
  await AppDataSource.initialize();
  console.log('Database connected!');

  // Перевірка, чи база вже заповнена (щоб уникнути дублікатів при повторних запусках)
  const roleRepo = AppDataSource.getRepository(Role);
  if ((await roleRepo.count()) > 0) {
    console.log('Database already seeded! Skipping...');
    await AppDataSource.destroy();
    return; // Якщо хочете очистити БД і наповнити знову — видаліть або перестворіть базу
  }

  console.log('Seeding data...');

  // --- 1. Roles ---
  const adminRole = roleRepo.create({ name: 'admin' });
  const managerRole = roleRepo.create({ name: 'manager' });
  const userRole = roleRepo.create({ name: 'user' });
  await roleRepo.save([adminRole, managerRole, userRole]);

  // --- 2. Users ---
  const userRepo = AppDataSource.getRepository(User);
  const admin = userRepo.create({ full_name: 'Super Admin', email: 'admin@example.com', password_hash: 'hash', role_id: adminRole.id });
  const manager = userRepo.create({ full_name: 'Hotel Manager', email: 'manager@example.com', password_hash: 'hash', role_id: managerRole.id });
  
  // Юзер, що вже заселений
  const checkedInUser = userRepo.create({ full_name: 'Ivan CheckedIn', email: 'user.checked_in@example.com', password_hash: 'hash', role_id: userRole.id });
  // Юзер з майбутньою броняю
  const futureUser = userRepo.create({ full_name: 'Olena Future', email: 'user.future@example.com', password_hash: 'hash', role_id: userRole.id });
  // Новий юзер без броні
  const registeredUser = userRepo.create({ full_name: 'Petro Registered', email: 'user.registered@example.com', password_hash: 'hash', role_id: userRole.id });
  
  await userRepo.save([admin, manager, checkedInUser, futureUser, registeredUser]);

  // --- 3. Hotel ---
  const hotelRepo = AppDataSource.getRepository(Hotel);
  const hotel = hotelRepo.create({ name: 'Grand Hotel Diplomat', description: 'The best hotel to stay in the city heart.' });
  await hotelRepo.save(hotel);

  // --- 4. Room Types ---
  const roomTypeRepo = AppDataSource.getRepository(RoomType);
  const standardType = roomTypeRepo.create({ name: 'Standard', room_class_id: 1, hotel_id: hotel.id, max_occupancy: 2, sleeping_place: '1 Double Bed', price_per_night: 80.00 });
  const deluxeType = roomTypeRepo.create({ name: 'Deluxe', room_class_id: 2, hotel_id: hotel.id, max_occupancy: 3, sleeping_place: '1 King Bed, 1 Sofa', price_per_night: 150.00 });
  const suiteType = roomTypeRepo.create({ name: 'Suite', room_class_id: 3, hotel_id: hotel.id, max_occupancy: 4, sleeping_place: '2 King Beds', price_per_night: 300.00 });
  await roomTypeRepo.save([standardType, deluxeType, suiteType]);

  // --- 5. Rooms ---
  const roomRepo = AppDataSource.getRepository(Room);
  const room101 = roomRepo.create({ number: 101, status: 'occupied', description: 'Standard room with street view', hotel_id: hotel.id, room_type_id: standardType.id, cost: 80.00 });
  const room102 = roomRepo.create({ number: 102, status: 'booked', description: 'Standard room on 1st floor', hotel_id: hotel.id, room_type_id: standardType.id, cost: 80.00 });
  const room201 = roomRepo.create({ number: 201, status: 'available', description: 'Deluxe corner room', hotel_id: hotel.id, room_type_id: deluxeType.id, cost: 150.00 });
  const room202 = roomRepo.create({ number: 202, status: 'available', description: 'Deluxe room', hotel_id: hotel.id, room_type_id: deluxeType.id, cost: 150.00 });
  const room301 = roomRepo.create({ number: 301, status: 'available', description: 'Luxury Suite', hotel_id: hotel.id, room_type_id: suiteType.id, cost: 300.00 });
  await roomRepo.save([room101, room102, room201, room202, room301]);

  // --- 6. Bookings ---
  // Сьогоднішня дата і майбутні (для реалістичності)
  const today = new Date();
  const pastCheckIn = new Date(today); pastCheckIn.setDate(today.getDate() - 2);
  const futureCheckOut = new Date(today); futureCheckOut.setDate(today.getDate() + 3);
  
  const futureCheckIn = new Date(today); futureCheckIn.setDate(today.getDate() + 10);
  const futureCheckOut2 = new Date(today); futureCheckOut2.setDate(today.getDate() + 15);

  const bookingRepo = AppDataSource.getRepository(Booking);
  const currentBooking = bookingRepo.create({ user_id: checkedInUser.id, room_id: room101.id, check_in_date: pastCheckIn.toISOString().split('T')[0], check_out_date: futureCheckOut.toISOString().split('T')[0], status: 'checked_in' });
  const futureBooking = bookingRepo.create({ user_id: futureUser.id, room_id: room102.id, check_in_date: futureCheckIn.toISOString().split('T')[0], check_out_date: futureCheckOut2.toISOString().split('T')[0], status: 'confirmed' });
  await bookingRepo.save([currentBooking, futureBooking]);

  // --- 7. Restaurant & Tables ---
  const restRepo = AppDataSource.getRepository(Restaurant);
  const restaurant = restRepo.create({ name: 'Diplomat Lounge', hotel_id: hotel.id });
  await restRepo.save(restaurant);

  const tableRepo = AppDataSource.getRepository(Table);
  const table1 = tableRepo.create({ number: 1, status: 'available', restaurant_id: restaurant.id });
  const table2 = tableRepo.create({ number: 2, status: 'occupied', restaurant_id: restaurant.id });
  const table3 = tableRepo.create({ number: 3, status: 'available', restaurant_id: restaurant.id });
  const table4 = tableRepo.create({ number: 4, status: 'available', restaurant_id: restaurant.id });
  await tableRepo.save([table1, table2, table3, table4]);

  // --- 8. Ingredients ---
  const ingRepo = AppDataSource.getRepository(Ingredient);
  const beef = ingRepo.create({ name: 'Beef', count: 20.0, unit: 'kg', min_threshold: 5.0 });
  const potato = ingRepo.create({ name: 'Potato', count: 50.0, unit: 'kg', min_threshold: 10.0 });
  const tomato = ingRepo.create({ name: 'Tomato', count: 15.0, unit: 'kg', min_threshold: 3.0 });
  const lettuce = ingRepo.create({ name: 'Lettuce', count: 10.0, unit: 'kg', min_threshold: 2.0 });
  const coffee = ingRepo.create({ name: 'Coffee Beans', count: 8.0, unit: 'kg', min_threshold: 2.0 });
  const milk = ingRepo.create({ name: 'Milk', count: 25.0, unit: 'liter', min_threshold: 5.0 });
  await ingRepo.save([beef, potato, tomato, lettuce, coffee, milk]);

  // --- 9. Dishes & DishIngredients ---
  const dishRepo = AppDataSource.getRepository(Dish);
  const steakDish = dishRepo.create({ name: 'Beef Steak with Potatoes', cost: 25.50 });
  const saladDish = dishRepo.create({ name: 'Fresh Salad', cost: 12.00 });
  const latteDish = dishRepo.create({ name: 'Café Latte', cost: 4.50 });
  await dishRepo.save([steakDish, saladDish, latteDish]);

  const dishIngRepo = AppDataSource.getRepository(DishIngredient);
  await dishIngRepo.save([
    dishIngRepo.create({ dish_id: steakDish.id, ingredient_id: beef.id, quantity_required: 0.3 }),
    dishIngRepo.create({ dish_id: steakDish.id, ingredient_id: potato.id, quantity_required: 0.2 }),
    dishIngRepo.create({ dish_id: saladDish.id, ingredient_id: tomato.id, quantity_required: 0.2 }),
    dishIngRepo.create({ dish_id: saladDish.id, ingredient_id: lettuce.id, quantity_required: 0.1 }),
    dishIngRepo.create({ dish_id: latteDish.id, ingredient_id: coffee.id, quantity_required: 0.05 }),
    dishIngRepo.create({ dish_id: latteDish.id, ingredient_id: milk.id, quantity_required: 0.2 }),
  ]);

  // --- 10. Orders & OrderDishes ---
  const orderRepo = AppDataSource.getRepository(Order);
  // Замовлення від юзера, який зараз проживає в номері (сидить за столиком 2)
  const order1 = orderRepo.create({ 
    user_id: checkedInUser.id, 
    table_id: table2.id, 
    booking_id: currentBooking.id, 
    status: 'in_progress', 
    total_price: 30.00, 
    created_at: today.toISOString().split('T')[0] 
  });
  await orderRepo.save([order1]);

  const orderDishRepo = AppDataSource.getRepository(OrderDish);
  await orderDishRepo.save([
    orderDishRepo.create({ order_id: order1.id, dish_id: steakDish.id, quantity: 1 }),
    orderDishRepo.create({ order_id: order1.id, dish_id: latteDish.id, quantity: 1 })
  ]);

  console.log('Seed completed successfully!');
  await AppDataSource.destroy();
}

runSeed().catch(err => {
  console.error('Error during seed:', err);
  process.exit(1);
});
