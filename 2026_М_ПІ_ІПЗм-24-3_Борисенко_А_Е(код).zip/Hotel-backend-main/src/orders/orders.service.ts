import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { MailerService } from '@nestjs-modules/mailer';
import { Order } from '../entities/Order';
import { OrderDish } from '../entities/OrderDish';
import { Ingredient } from '../entities/Ingredient';
import { User } from '../entities/User';
import { OrdersGateway } from './orders.gateway';

@Injectable()
export class OrdersService {
  constructor(
    @InjectRepository(Order) private orderRepo: Repository<Order>,
    @InjectRepository(OrderDish) private orderDishRepo: Repository<OrderDish>,
    @InjectRepository(Ingredient) private ingredientRepo: Repository<Ingredient>,
    @InjectRepository(User) private userRepo: Repository<User>,
    private readonly mailerService: MailerService,
    private readonly ordersGateway: OrdersGateway,
  ) {}

  async findAll() {
    return this.orderRepo.find({
      relations: ['orderDishes', 'orderDishes.dish'],
      order: { id: 'DESC' }
    });
  }

  async create(data: any) {
    let prepTime = 15;
    if (data.dishes && Array.isArray(data.dishes)) {
      data.dishes.forEach((d: any) => {
        prepTime += d.quantity * 2;
      });
    }

    const order = this.orderRepo.create({
      user_id: data.user_id,
      table_id: data.table_id || null,
      booking_id: data.booking_id || null,
      status: 'NEW',
      total_price: data.total_price,
      created_at: new Date().toISOString().split('T')[0],
      estimated_prep_minutes: prepTime,
    });
    const savedOrder = await this.orderRepo.save(order);

    if (data.dishes && Array.isArray(data.dishes)) {
      const orderDishes = data.dishes.map((d: any) => {
        return this.orderDishRepo.create({
          order_id: savedOrder.id,
          dish_id: d.dish_id,
          quantity: d.quantity,
        });
      });
      await this.orderDishRepo.save(orderDishes);
    }
    
    // Notify clients about new order
    this.ordersGateway.notifyNewOrder();
    
    return savedOrder;
  }

  async updateTime(orderId: number, additionalMinutes: number) {
    const order = await this.orderRepo.findOneBy({ id: orderId });
    if (!order) throw new NotFoundException('Order not found');
    order.estimated_prep_minutes += additionalMinutes;
    return this.orderRepo.save(order);
  }

  async findAllActive() {
    return this.orderRepo.find({
      where: [{ status: 'NEW' }, { status: 'COOKING' }, { status: 'in_progress' }],
      relations: ['orderDishes', 'orderDishes.dish', 'table', 'user'],
      order: { id: 'ASC' }
    });
  }

  async updateStatus(orderId: number, status: string) {
    const order = await this.orderRepo.findOne({
      where: { id: orderId },
      relations: [
        'orderDishes', 
        'orderDishes.dish', 
        'orderDishes.dish.dishIngredients', 
        'orderDishes.dish.dishIngredients.ingredient'
      ]
    });

    if (!order) throw new NotFoundException('Order not found');

    order.status = status;
    const savedOrder = await this.orderRepo.save(order);

    // Automation logic for diploma!
    if (status.toUpperCase() === 'READY') {
      await this.deductInventory(order);
    }

    // Notify clients about updated order
    this.ordersGateway.notifyOrderUpdated();

    return savedOrder;
  }

  // --- ЯДРО АВТОМАТИЗАЦІЇ (ДЛЯ ДИПЛОМУ) ---
  private async deductInventory(order: Order) {
    for (const od of order.orderDishes) {
      const dish = od.dish;
      const quantityOrdered = od.quantity;

      for (const di of dish.dishIngredients) {
        const ingredient = di.ingredient;
        const amountToDeduct = di.quantity_required * quantityOrdered;

        // Зменшуємо залишки
        ingredient.count -= amountToDeduct;
        
        // Зберігаємо зміни
        await this.ingredientRepo.save(ingredient);

        // Перевіряємо пороги та відправляємо email
        if (ingredient.count < ingredient.min_threshold) {
          await this.sendLowStockEmail(ingredient);
        }
      }
    }
  }

  private async sendLowStockEmail(ingredient: Ingredient) {
    try {
      const staff = await this.userRepo.find({
        relations: ['role'],
        where: [
          { role: { name: 'admin' } },
          { role: { name: 'manager' } }
        ]
      });
      
      const emails = new Set(staff.map(u => u.email).filter(Boolean));
      emails.add('kostiantyn.hamalii@nure.ua'); // Required fallback array item
      const toEmails = Array.from(emails);

      await this.mailerService.sendMail({
        to: toEmails,
        subject: `⚠️ КРИТИЧНИЙ ЗАЛИШОК: ${ingredient.name}`,
        text: `Увага! Залишок інгредієнта "${ingredient.name}" впав розрахункового мінімуму!\n\nПоточний залишок: ${ingredient.count} ${ingredient.unit}\nМінімальний поріг: ${ingredient.min_threshold} ${ingredient.unit}\n\nБудь ласка, терміново сформуйте замовлення постачальнику.`,
        html: `
          <h2 style="color: red;">Увага! Критичний залишок</h2>
          <p>Залишок інгредієнта <strong>${ingredient.name}</strong> впав нижче норми.</p>
          <ul>
            <li><strong>Поточний залишок:</strong> ${ingredient.count} ${ingredient.unit}</li>
            <li><strong>Мінімальний поріг:</strong> ${ingredient.min_threshold} ${ingredient.unit}</li>
          </ul>
          <p><em>Будь ласка, терміново сформуйте замовлення постачальнику.</em></p>
        `,
      });
      console.log(`Email sent for low stock: ${ingredient.name}`);
    } catch (e) {
      console.error('Error sending email:', e);
    }
  }
}
