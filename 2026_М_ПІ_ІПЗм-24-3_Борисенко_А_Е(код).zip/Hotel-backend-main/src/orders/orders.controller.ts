import { Controller, Get, Post, Patch, Param, Body, ParseIntPipe } from '@nestjs/common';
import { OrdersService } from './orders.service';

@Controller('orders')
export class OrdersController {
  constructor(private readonly ordersService: OrdersService) {}

  @Get()
  getAllOrders() {
    return this.ordersService.findAll();
  }

  @Get('active')
  getActiveOrders() {
    return this.ordersService.findAllActive();
  }

  @Post()
  createOrder(@Body() body: any) {
    return this.ordersService.create(body);
  }

  @Patch(':id/status')
  updateStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body('status') status: string
  ) {
    return this.ordersService.updateStatus(id, status);
  }

  @Patch(':id/time')
  updateTime(
    @Param('id', ParseIntPipe) id: number,
    @Body('minutes') minutes: number
  ) {
    return this.ordersService.updateTime(id, minutes);
  }
}
