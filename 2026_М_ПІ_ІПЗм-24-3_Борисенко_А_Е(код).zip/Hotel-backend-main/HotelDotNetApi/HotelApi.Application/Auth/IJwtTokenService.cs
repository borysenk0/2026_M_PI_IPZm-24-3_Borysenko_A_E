using HotelApi.Domain.Models;

namespace HotelApi.Application.Auth;

public interface IJwtTokenService
{
    (string Token, DateTime ExpiresAtUtc) CreateToken(AppUser user, string roleName);
}
