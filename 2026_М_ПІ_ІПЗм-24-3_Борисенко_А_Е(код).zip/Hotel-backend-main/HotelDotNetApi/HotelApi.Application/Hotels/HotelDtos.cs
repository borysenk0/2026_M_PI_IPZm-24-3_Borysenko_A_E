namespace HotelApi.Application.Hotels;

public record HotelDto(int Id, string Name);

public record CreateHotelDto(string Name);

public record UpdateHotelDto(string Name);
