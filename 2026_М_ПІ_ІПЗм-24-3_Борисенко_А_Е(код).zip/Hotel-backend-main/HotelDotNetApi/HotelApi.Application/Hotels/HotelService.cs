using HotelApi.Domain.Interfaces;
using HotelApi.Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelApi.Application.Hotels;

public class HotelService : IHotelService
{
    private readonly IRepository<Hotel> _hotels;
    private readonly IRepository<Room> _rooms;

    public HotelService(IRepository<Hotel> hotels, IRepository<Room> rooms)
    {
        _hotels = hotels;
        _rooms = rooms;
    }

    public async Task<IReadOnlyList<HotelDto>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _hotels.Query()
            .AsNoTracking()
            .OrderBy(h => h.Id)
            .Select(h => new HotelDto(h.Id, h.Name))
            .ToListAsync(cancellationToken);
    }

    public async Task<HotelDto?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        var h = await _hotels.Query().AsNoTracking().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        return h is null ? null : new HotelDto(h.Id, h.Name);
    }

    public async Task<HotelDto> CreateAsync(CreateHotelDto dto, CancellationToken cancellationToken = default)
    {
        var entity = new Hotel { Name = dto.Name.Trim() };
        _hotels.Add(entity);
        await _hotels.SaveChangesAsync(cancellationToken);
        return new HotelDto(entity.Id, entity.Name);
    }

    public async Task<HotelDto?> UpdateAsync(int id, UpdateHotelDto dto, CancellationToken cancellationToken = default)
    {
        var entity = await _hotels.Query().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        if (entity is null)
            return null;
        entity.Name = dto.Name.Trim();
        await _hotels.SaveChangesAsync(cancellationToken);
        return new HotelDto(entity.Id, entity.Name);
    }

    public async Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await _hotels.Query().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        if (entity is null)
            return false;
        if (await _rooms.Query().AnyAsync(r => r.HotelId == id, cancellationToken))
            return false;
        _hotels.Remove(entity);
        await _hotels.SaveChangesAsync(cancellationToken);
        return true;
    }
}
