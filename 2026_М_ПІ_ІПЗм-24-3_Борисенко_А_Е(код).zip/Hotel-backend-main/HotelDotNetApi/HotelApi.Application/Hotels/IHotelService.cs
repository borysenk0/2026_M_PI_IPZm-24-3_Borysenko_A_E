namespace HotelApi.Application.Hotels;

public interface IHotelService
{
    Task<IReadOnlyList<HotelDto>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<HotelDto?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task<HotelDto> CreateAsync(CreateHotelDto dto, CancellationToken cancellationToken = default);
    Task<HotelDto?> UpdateAsync(int id, UpdateHotelDto dto, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default);
}
