namespace HotelApi.Application.Roles;

public record RoleDto(int Id, string Name);

public record CreateRoleDto(string Name);

public record UpdateRoleDto(string Name);
