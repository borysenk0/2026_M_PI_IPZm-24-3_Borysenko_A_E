using HotelApi.Domain.Interfaces;
using HotelApi.Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelApi.Application.Roles;

public class RoleService : IRoleService
{
    private readonly IRepository<Role> _roles;
    private readonly IRepository<AppUser> _users;

    public RoleService(IRepository<Role> roles, IRepository<AppUser> users)
    {
        _roles = roles;
        _users = users;
    }

    public async Task<IReadOnlyList<RoleDto>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _roles.Query()
            .OrderBy(r => r.Id)
            .Select(r => new RoleDto(r.Id, r.Name))
            .ToListAsync(cancellationToken);
    }

    public async Task<RoleDto?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        var r = await _roles.Query().AsNoTracking().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        return r is null ? null : new RoleDto(r.Id, r.Name);
    }

    public async Task<RoleDto> CreateAsync(CreateRoleDto dto, CancellationToken cancellationToken = default)
    {
        var entity = new Role { Name = dto.Name.Trim() };
        _roles.Add(entity);
        await _roles.SaveChangesAsync(cancellationToken);
        return new RoleDto(entity.Id, entity.Name);
    }

    public async Task<RoleDto?> UpdateAsync(int id, UpdateRoleDto dto, CancellationToken cancellationToken = default)
    {
        var entity = await _roles.Query().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        if (entity is null)
            return null;
        entity.Name = dto.Name.Trim();
        await _roles.SaveChangesAsync(cancellationToken);
        return new RoleDto(entity.Id, entity.Name);
    }

    public async Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await _roles.Query().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        if (entity is null)
            return false;
        if (await _users.Query().AnyAsync(u => u.RoleId == id, cancellationToken))
            return false;
        _roles.Remove(entity);
        await _roles.SaveChangesAsync(cancellationToken);
        return true;
    }
}
