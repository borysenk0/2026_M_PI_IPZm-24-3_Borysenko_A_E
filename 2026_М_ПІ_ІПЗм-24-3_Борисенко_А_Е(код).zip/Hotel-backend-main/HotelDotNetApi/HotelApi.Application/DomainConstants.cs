namespace HotelApi.Application;

public static class RoomStatuses
{
    public const string Available = "available";
    public const string Occupied = "occupied";
}

public static class BookingStatuses
{
    public const string Confirmed = "confirmed";
    public const string Cancelled = "cancelled";
    public const string Pending = "pending";
}
