using HotelApi.Domain.Interfaces;
using HotelApi.Domain.Models;
using HotelApi.Application.Auth;
using HotelApi.Application.Security;
using Microsoft.EntityFrameworkCore;

namespace HotelApi.Application.Users;

public class UserService : IUserService
{
    private const int GuestRoleId = 2;

    private readonly IRepository<AppUser> _users;
    private readonly IRepository<Booking> _bookings;
    private readonly IJwtTokenService _jwt;

    public UserService(IRepository<AppUser> users, IRepository<Booking> bookings, IJwtTokenService jwt)
    {
        _users = users;
        _bookings = bookings;
        _jwt = jwt;
    }

    public async Task<IReadOnlyList<UserDto>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _users.Query()
            .AsNoTracking()
            .OrderBy(u => u.Id)
            .Select(u => new UserDto(u.Id, u.FullName, u.RoleId, u.Email))
            .ToListAsync(cancellationToken);
    }

    public async Task<UserDto?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        var u = await _users.Query().AsNoTracking().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        return u is null ? null : new UserDto(u.Id, u.FullName, u.RoleId, u.Email);
    }

    public async Task<UserDto> CreateAsync(CreateUserDto dto, CancellationToken cancellationToken = default)
    {
        var entity = new AppUser
        {
            FullName = dto.FullName.Trim(),
            RoleId = dto.RoleId,
            Email = dto.Email.Trim().ToLowerInvariant(),
            PasswordHash = PasswordHasher.Hash(dto.Password)
        };
        _users.Add(entity);
        await _users.SaveChangesAsync(cancellationToken);
        return new UserDto(entity.Id, entity.FullName, entity.RoleId, entity.Email);
    }

    public async Task<UserDto?> UpdateAsync(int id, UpdateUserDto dto, CancellationToken cancellationToken = default)
    {
        var entity = await _users.Query().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        if (entity is null)
            return null;
        entity.FullName = dto.FullName.Trim();
        entity.RoleId = dto.RoleId;
        entity.Email = dto.Email.Trim().ToLowerInvariant();
        if (!string.IsNullOrEmpty(dto.Password))
            entity.PasswordHash = PasswordHasher.Hash(dto.Password);
        await _users.SaveChangesAsync(cancellationToken);
        return new UserDto(entity.Id, entity.FullName, entity.RoleId, entity.Email);
    }

    public async Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await _users.Query().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        if (entity is null)
            return false;
        if (await _bookings.Query().AnyAsync(b => b.UserId == id, cancellationToken))
            return false;
        _users.Remove(entity);
        await _users.SaveChangesAsync(cancellationToken);
        return true;
    }

    public async Task<AuthResponseDto> RegisterAsync(RegisterDto dto, CancellationToken cancellationToken = default)
    {
        var email = dto.Email.Trim().ToLowerInvariant();
        if (await _users.Query().AnyAsync(u => u.Email == email, cancellationToken))
            throw new InvalidOperationException("Email is already registered.");

        var entity = new AppUser
        {
            FullName = dto.FullName.Trim(),
            RoleId = GuestRoleId,
            Email = email,
            PasswordHash = PasswordHasher.Hash(dto.Password)
        };
        _users.Add(entity);
        await _users.SaveChangesAsync(cancellationToken);

        var loadedEntity = await _users.Query().Include(u => u.Role).FirstOrDefaultAsync(u => u.Id == entity.Id, cancellationToken);
        var (token, expires) = _jwt.CreateToken(loadedEntity!, loadedEntity!.Role.Name);
        return new AuthResponseDto(token, expires, new UserDto(loadedEntity!.Id, loadedEntity!.FullName, loadedEntity!.RoleId, loadedEntity!.Email));
    }

    public async Task<AuthResponseDto?> LoginAsync(LoginDto dto, CancellationToken cancellationToken = default)
    {
        var email = dto.Email.Trim().ToLowerInvariant();
        var user = await _users.Query()
            .Include(u => u.Role)
            .FirstOrDefaultAsync(u => u.Email == email, cancellationToken);
        if (user is null || !PasswordHasher.Verify(dto.Password, user.PasswordHash))
            return null;

        var (token, expires) = _jwt.CreateToken(user, user.Role.Name);
        return new AuthResponseDto(token, expires, new UserDto(user.Id, user.FullName, user.RoleId, user.Email));
    }
}
