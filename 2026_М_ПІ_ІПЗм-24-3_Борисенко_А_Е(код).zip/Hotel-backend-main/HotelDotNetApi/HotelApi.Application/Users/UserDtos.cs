namespace HotelApi.Application.Users;

public record UserDto(int Id, string FullName, int RoleId, string Email);

public record CreateUserDto(string FullName, int RoleId, string Email, string Password);

public record UpdateUserDto(string FullName, int RoleId, string Email, string? Password);

public record RegisterDto(string FullName, string Email, string Password);

public record LoginDto(string Email, string Password);

public record AuthResponseDto(string Token, DateTime ExpiresAtUtc, UserDto User);
