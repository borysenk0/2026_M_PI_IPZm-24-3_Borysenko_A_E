using HotelApi.Domain.Interfaces;
using HotelApi.Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelApi.Application.RoomTypes;

public class RoomTypeService : IRoomTypeService
{
    private readonly IRepository<RoomType> _roomTypes;
    private readonly IRepository<Hotel> _hotels;
    private readonly IRepository<Room> _rooms;

    public RoomTypeService(IRepository<RoomType> roomTypes, IRepository<Hotel> hotels, IRepository<Room> rooms)
    {
        _roomTypes = roomTypes;
        _hotels = hotels;
        _rooms = rooms;
    }

    public async Task<IReadOnlyList<RoomTypeDto>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _roomTypes.Query()
            .AsNoTracking()
            .OrderBy(t => t.HotelId)
            .ThenBy(t => t.Name)
            .Select(t => new RoomTypeDto(
                t.Id,
                t.HotelId,
                t.Name,
                t.Class,
                t.MaxOccupancy,
                t.SleepingPlaces,
                t.PricePerNight))
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<RoomTypeDto>> GetByHotelIdAsync(int hotelId, CancellationToken cancellationToken = default)
    {
        return await _roomTypes.Query()
            .AsNoTracking()
            .Where(t => t.HotelId == hotelId)
            .OrderBy(t => t.Name)
            .Select(t => new RoomTypeDto(
                t.Id,
                t.HotelId,
                t.Name,
                t.Class,
                t.MaxOccupancy,
                t.SleepingPlaces,
                t.PricePerNight))
            .ToListAsync(cancellationToken);
    }

    public async Task<RoomTypeDto?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        return await _roomTypes.Query()
            .AsNoTracking()
            .Where(t => t.Id == id)
            .Select(t => new RoomTypeDto(
                t.Id,
                t.HotelId,
                t.Name,
                t.Class,
                t.MaxOccupancy,
                t.SleepingPlaces,
                t.PricePerNight))
            .FirstOrDefaultAsync(cancellationToken);
    }

    public async Task<RoomTypeDto> CreateAsync(CreateRoomTypeDto dto, CancellationToken cancellationToken = default)
    {
        await EnsureHotelExistsAsync(dto.HotelId, cancellationToken);
        ValidateOccupancy(dto.MaxOccupancy);
        ValidatePrice(dto.PricePerNight);

        var entity = new RoomType
        {
            HotelId = dto.HotelId,
            Name = dto.Name.Trim(),
            Class = dto.Class,
            MaxOccupancy = dto.MaxOccupancy,
            SleepingPlaces = dto.SleepingPlaces.Trim(),
            PricePerNight = dto.PricePerNight
        };
        _roomTypes.Add(entity);
        await _roomTypes.SaveChangesAsync(cancellationToken);
        return new RoomTypeDto(
            entity.Id,
            entity.HotelId,
            entity.Name,
            entity.Class,
            entity.MaxOccupancy,
            entity.SleepingPlaces,
            entity.PricePerNight);
    }

    public async Task<RoomTypeDto?> UpdateAsync(int id, UpdateRoomTypeDto dto, CancellationToken cancellationToken = default)
    {
        var entity = await _roomTypes.Query().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        if (entity is null)
            return null;

        await EnsureHotelExistsAsync(dto.HotelId, cancellationToken);
        ValidateOccupancy(dto.MaxOccupancy);
        ValidatePrice(dto.PricePerNight);

        entity.HotelId = dto.HotelId;
        entity.Name = dto.Name.Trim();
        entity.Class = dto.Class;
        entity.MaxOccupancy = dto.MaxOccupancy;
        entity.SleepingPlaces = dto.SleepingPlaces.Trim();
        entity.PricePerNight = dto.PricePerNight;
        await _roomTypes.SaveChangesAsync(cancellationToken);
        return new RoomTypeDto(
            entity.Id,
            entity.HotelId,
            entity.Name,
            entity.Class,
            entity.MaxOccupancy,
            entity.SleepingPlaces,
            entity.PricePerNight);
    }

    public async Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await _roomTypes.Query().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        if (entity is null)
            return false;
        if (await _rooms.Query().AnyAsync(r => r.RoomTypeId == id, cancellationToken))
            return false;
        _roomTypes.Remove(entity);
        await _roomTypes.SaveChangesAsync(cancellationToken);
        return true;
    }

    private async Task EnsureHotelExistsAsync(int hotelId, CancellationToken cancellationToken)
    {
        if (!await _hotels.Query().AsNoTracking().AnyAsync(h => h.Id == hotelId, cancellationToken))
            throw new InvalidOperationException($"Hotel with id {hotelId} does not exist.");
    }

    private static void ValidateOccupancy(int maxOccupancy)
    {
        if (maxOccupancy < 1)
            throw new ArgumentException("Max occupancy must be at least 1.");
    }

    private static void ValidatePrice(decimal pricePerNight)
    {
        if (pricePerNight < 0)
            throw new ArgumentException("Price per night cannot be negative.");
    }
}
