namespace HotelApi.Application.RoomTypes;

public interface IRoomTypeService
{
    Task<IReadOnlyList<RoomTypeDto>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<IReadOnlyList<RoomTypeDto>> GetByHotelIdAsync(int hotelId, CancellationToken cancellationToken = default);
    Task<RoomTypeDto?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task<RoomTypeDto> CreateAsync(CreateRoomTypeDto dto, CancellationToken cancellationToken = default);
    Task<RoomTypeDto?> UpdateAsync(int id, UpdateRoomTypeDto dto, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default);
}
