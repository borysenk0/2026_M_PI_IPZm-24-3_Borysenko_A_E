using HotelApi.Domain.Models.Enums;

namespace HotelApi.Application.RoomTypes;

public record RoomTypeDto(
    int Id,
    int HotelId,
    string Name,
    RoomClass Class,
    int MaxOccupancy,
    string SleepingPlaces,
    decimal PricePerNight);

public record CreateRoomTypeDto(
    int HotelId,
    string Name,
    RoomClass Class,
    int MaxOccupancy,
    string SleepingPlaces,
    decimal PricePerNight);

public record UpdateRoomTypeDto(
    int HotelId,
    string Name,
    RoomClass Class,
    int MaxOccupancy,
    string SleepingPlaces,
    decimal PricePerNight);
