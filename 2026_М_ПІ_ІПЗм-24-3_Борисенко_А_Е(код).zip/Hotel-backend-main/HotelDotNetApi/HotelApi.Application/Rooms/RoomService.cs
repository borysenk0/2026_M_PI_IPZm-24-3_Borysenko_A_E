using HotelApi.Domain.Interfaces;
using HotelApi.Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelApi.Application.Rooms;

public class RoomService : IRoomService
{
    private readonly IRepository<Room> _rooms;
    private readonly IRepository<Booking> _bookings;
    private readonly IRepository<RoomType> _roomTypes;

    public RoomService(IRepository<Room> rooms, IRepository<Booking> bookings, IRepository<RoomType> roomTypes)
    {
        _rooms = rooms;
        _bookings = bookings;
        _roomTypes = roomTypes;
    }

    public async Task<IReadOnlyList<RoomDto>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _rooms.Query()
            .AsNoTracking()
            .OrderBy(r => r.HotelId)
            .ThenBy(r => r.Number)
            .Select(r => new RoomDto(
                r.Id,
                r.Number,
                r.Status,
                r.Description,
                r.HotelId,
                r.RoomTypeId,
                new RoomTypeSummaryDto(
                    r.RoomType.Id,
                    r.RoomType.Name,
                    r.RoomType.Class,
                    r.RoomType.MaxOccupancy,
                    r.RoomType.SleepingPlaces,
                    r.RoomType.PricePerNight)))
            .ToListAsync(cancellationToken);
    }

    public async Task<RoomDto?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        return await _rooms.Query()
            .AsNoTracking()
            .Where(x => x.Id == id)
            .Select(r => new RoomDto(
                r.Id,
                r.Number,
                r.Status,
                r.Description,
                r.HotelId,
                r.RoomTypeId,
                new RoomTypeSummaryDto(
                    r.RoomType.Id,
                    r.RoomType.Name,
                    r.RoomType.Class,
                    r.RoomType.MaxOccupancy,
                    r.RoomType.SleepingPlaces,
                    r.RoomType.PricePerNight)))
            .FirstOrDefaultAsync(cancellationToken);
    }

    public async Task<RoomDto> CreateAsync(CreateRoomDto dto, CancellationToken cancellationToken = default)
    {
        await EnsureRoomTypeMatchesHotelAsync(dto.HotelId, dto.RoomTypeId, cancellationToken);

        var entity = new Room
        {
            Number = dto.Number,
            Status = dto.Status.Trim(),
            Description = dto.Description.Trim(),
            HotelId = dto.HotelId,
            RoomTypeId = dto.RoomTypeId
        };
        _rooms.Add(entity);
        await _rooms.SaveChangesAsync(cancellationToken);
        
        var loadedEntity = await _rooms.Query().Include(r => r.RoomType).FirstOrDefaultAsync(r => r.Id == entity.Id, cancellationToken);
        return ToDto(loadedEntity!);
    }

    public async Task<RoomDto?> UpdateAsync(int id, UpdateRoomDto dto, CancellationToken cancellationToken = default)
    {
        var entity = await _rooms.Query().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        if (entity is null)
            return null;

        await EnsureRoomTypeMatchesHotelAsync(dto.HotelId, dto.RoomTypeId, cancellationToken);

        entity.Number = dto.Number;
        entity.Status = dto.Status.Trim();
        entity.Description = dto.Description.Trim();
        entity.HotelId = dto.HotelId;
        entity.RoomTypeId = dto.RoomTypeId;
        await _rooms.SaveChangesAsync(cancellationToken);

        var loadedEntity = await _rooms.Query().AsNoTracking().Include(r => r.RoomType).FirstOrDefaultAsync(r => r.Id == entity.Id, cancellationToken);
        return ToDto(loadedEntity!);
    }

    public async Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await _rooms.Query().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        if (entity is null)
            return false;
        if (await _bookings.Query().AnyAsync(b => b.RoomId == id, cancellationToken))
            return false;
        _rooms.Remove(entity);
        await _rooms.SaveChangesAsync(cancellationToken);
        return true;
    }

    private static RoomDto ToDto(Room r)
    {
        var t = r.RoomType;
        var summary = new RoomTypeSummaryDto(
            t.Id,
            t.Name,
            t.Class,
            t.MaxOccupancy,
            t.SleepingPlaces,
            t.PricePerNight);
        return new RoomDto(r.Id, r.Number, r.Status, r.Description, r.HotelId, r.RoomTypeId, summary);
    }

    private async Task EnsureRoomTypeMatchesHotelAsync(int hotelId, int roomTypeId, CancellationToken cancellationToken)
    {
        var ok = await _roomTypes.Query()
            .AsNoTracking()
            .AnyAsync(t => t.Id == roomTypeId && t.HotelId == hotelId, cancellationToken);
        if (!ok)
            throw new InvalidOperationException("Room type does not exist or belongs to a different hotel.");
    }
}
