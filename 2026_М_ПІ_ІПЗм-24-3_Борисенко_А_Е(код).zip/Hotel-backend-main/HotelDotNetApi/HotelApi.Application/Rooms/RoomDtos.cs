using HotelApi.Domain.Models.Enums;

namespace HotelApi.Application.Rooms;

public record RoomTypeSummaryDto(
    int Id,
    string Name,
    RoomClass Class,
    int MaxOccupancy,
    string SleepingPlaces,
    decimal PricePerNight);

public record RoomDto(
    int Id,
    int Number,
    string Status,
    string Description,
    int HotelId,
    int RoomTypeId,
    RoomTypeSummaryDto RoomType);

public record CreateRoomDto(int Number, string Status, string Description, int HotelId, int RoomTypeId);

public record UpdateRoomDto(int Number, string Status, string Description, int HotelId, int RoomTypeId);
