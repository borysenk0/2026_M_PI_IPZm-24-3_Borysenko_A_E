namespace HotelApi.Application.Bookings;

public record BookingDto(
    int Id,
    int UserId,
    int RoomId,
    DateOnly CheckInDate,
    DateOnly CheckOutDate,
    string Status);

public record CreateBookingDto(
    int UserId,
    int RoomId,
    DateOnly CheckInDate,
    DateOnly CheckOutDate,
    string Status);

public record UpdateBookingDto(
    int UserId,
    int RoomId,
    DateOnly CheckInDate,
    DateOnly CheckOutDate,
    string Status);
