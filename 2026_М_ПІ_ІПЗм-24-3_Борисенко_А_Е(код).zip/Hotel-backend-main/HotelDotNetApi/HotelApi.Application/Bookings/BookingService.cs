using HotelApi.Domain.Interfaces;
using HotelApi.Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelApi.Application.Bookings;

public class BookingService : IBookingService
{
    private readonly IRepository<Booking> _bookings;

    public BookingService(IRepository<Booking> bookings)
    {
        _bookings = bookings;
    }

    public async Task<IReadOnlyList<BookingDto>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _bookings.Query()
            .AsNoTracking()
            .OrderBy(b => b.CheckInDate)
            .Select(b => new BookingDto(b.Id, b.UserId, b.RoomId, b.CheckInDate, b.CheckOutDate, b.Status))
            .ToListAsync(cancellationToken);
    }

    public async Task<BookingDto?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        var b = await _bookings.Query().AsNoTracking().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        return b is null
            ? null
            : new BookingDto(b.Id, b.UserId, b.RoomId, b.CheckInDate, b.CheckOutDate, b.Status);
    }

    public async Task<BookingDto> CreateAsync(CreateBookingDto dto, CancellationToken cancellationToken = default)
    {
        ValidateDateRange(dto.CheckInDate, dto.CheckOutDate);
        await EnsureNoOverlappingBookingAsync(
            dto.RoomId,
            dto.CheckInDate,
            dto.CheckOutDate,
            excludeBookingId: null,
            cancellationToken);

        var entity = new Booking
        {
            UserId = dto.UserId,
            RoomId = dto.RoomId,
            CheckInDate = dto.CheckInDate,
            CheckOutDate = dto.CheckOutDate,
            Status = dto.Status.Trim()
        };
        _bookings.Add(entity);
        await _bookings.SaveChangesAsync(cancellationToken);
        return new BookingDto(
            entity.Id,
            entity.UserId,
            entity.RoomId,
            entity.CheckInDate,
            entity.CheckOutDate,
            entity.Status);
    }

    public async Task<BookingDto?> UpdateAsync(int id, UpdateBookingDto dto, CancellationToken cancellationToken = default)
    {
        var entity = await _bookings.Query().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        if (entity is null)
            return null;

        ValidateDateRange(dto.CheckInDate, dto.CheckOutDate);
        await EnsureNoOverlappingBookingAsync(
            dto.RoomId,
            dto.CheckInDate,
            dto.CheckOutDate,
            excludeBookingId: id,
            cancellationToken);

        entity.UserId = dto.UserId;
        entity.RoomId = dto.RoomId;
        entity.CheckInDate = dto.CheckInDate;
        entity.CheckOutDate = dto.CheckOutDate;
        entity.Status = dto.Status.Trim();
        await _bookings.SaveChangesAsync(cancellationToken);
        return new BookingDto(
            entity.Id,
            entity.UserId,
            entity.RoomId,
            entity.CheckInDate,
            entity.CheckOutDate,
            entity.Status);
    }

    public async Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await _bookings.Query().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        if (entity is null)
            return false;
        _bookings.Remove(entity);
        await _bookings.SaveChangesAsync(cancellationToken);
        return true;
    }

    private static void ValidateDateRange(DateOnly checkIn, DateOnly checkOut)
    {
        if (checkOut <= checkIn)
            throw new ArgumentException("Check-out date must be after check-in date.");
    }

    private async Task EnsureNoOverlappingBookingAsync(
        int roomId,
        DateOnly checkIn,
        DateOnly checkOut,
        int? excludeBookingId,
        CancellationToken cancellationToken)
    {
        var query = _bookings.Query()
            .AsNoTracking()
            .Where(b => b.RoomId == roomId && b.Status != BookingStatuses.Cancelled);

        if (excludeBookingId.HasValue)
            query = query.Where(b => b.Id != excludeBookingId.Value);

        var overlapping = await query
            .Where(b => b.CheckInDate < checkOut && checkIn < b.CheckOutDate)
            .AnyAsync(cancellationToken);

        if (overlapping)
            throw new InvalidOperationException("Room is already booked for overlapping dates.");
    }
}
