using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HotelApi.Infrastructure.Migrations;

/// <inheritdoc />
public partial class RenameUserPasswordToPasswordHash : Migration
{
    /// <inheritdoc />
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.RenameColumn(
            name: "Password",
            table: "users",
            newName: "password_hash");
    }

    /// <inheritdoc />
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.RenameColumn(
            name: "password_hash",
            table: "users",
            newName: "Password");
    }
}
