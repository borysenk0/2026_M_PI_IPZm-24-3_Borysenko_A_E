using System.Security.Claims;
using System.Text;
using Scalar.AspNetCore;
using HotelApi.Infrastructure.Data;
using HotelApi.Application.Auth;
using HotelApi.Application.Bookings;
using HotelApi.Application.Hotels;
using HotelApi.Application.Roles;
using HotelApi.Application.Rooms;
using HotelApi.Application.RoomTypes;
using HotelApi.Application.Users;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi;
using HotelApi.Services.Data;
using HotelApi.Services.Endpoints;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddOpenApi(options =>
{
    options.AddDocumentTransformer((document, _, _) =>
    {
        document.Info.Title = "Hotel API";
        
        // Define security scheme
        document.Components ??= new OpenApiComponents();
        document.Components.SecuritySchemes ??= new Dictionary<string, IOpenApiSecurityScheme>();
        
        document.Components.SecuritySchemes["Bearer"] = new OpenApiSecurityScheme
        {
            Type = SecuritySchemeType.Http,
            Scheme = "bearer",
            BearerFormat = "JWT"
        };
        
        // Apply globally
        document.Security = new List<OpenApiSecurityRequirement>
        {
            new()
            {
                [new OpenApiSecuritySchemeReference("Bearer", document)] = new List<string>()
            }
        };

        document.Servers ??= new List<OpenApiServer>();
        if (document.Servers.Count == 0)
        {
            document.Servers.Add(new OpenApiServer { Url = "http://localhost:5235" });
            document.Servers.Add(new OpenApiServer { Url = "https://localhost:7014" });
        }
        return Task.CompletedTask;
    });
});
builder.Services.AddDbContext<HotelDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

var jwtSection = builder.Configuration.GetSection(JwtOptions.SectionName);
builder.Services.Configure<JwtOptions>(jwtSection);
var jwtOptions = jwtSection.Get<JwtOptions>()
    ?? throw new InvalidOperationException($"Configuration section '{JwtOptions.SectionName}' is missing or invalid.");
if (string.IsNullOrWhiteSpace(jwtOptions.Secret) || jwtOptions.Secret.Length < 32)
    throw new InvalidOperationException("Jwt:Secret must be at least 32 characters.");

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtOptions.Secret)),
            ValidateIssuer = true,
            ValidIssuer = jwtOptions.Issuer,
            ValidateAudience = true,
            ValidAudience = jwtOptions.Audience,
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromMinutes(1),
            RoleClaimType = ClaimTypes.Role
        };
    });
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("Admin", policy => policy.RequireRole("Admin"));
});

builder.Services.AddScoped(typeof(HotelApi.Domain.Interfaces.IRepository<>), typeof(HotelApi.Infrastructure.Repositories.Repository<>));
builder.Services.AddScoped<IJwtTokenService, JwtTokenService>();
builder.Services.AddScoped<IRoleService, RoleService>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<IHotelService, HotelService>();
builder.Services.AddScoped<IRoomService, RoomService>();
builder.Services.AddScoped<IRoomTypeService, RoomTypeService>();
builder.Services.AddScoped<IBookingService, BookingService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference(options =>
    {
        options.WithTitle("Hotel API")
               .WithDownloadButton(true)
               .WithDefaultHttpClient(ScalarTarget.CSharp, ScalarClient.HttpClient);
    });
}

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

if (app.Environment.IsDevelopment())
{
    using var scope = app.Services.CreateScope();
    var db = scope.ServiceProvider.GetRequiredService<HotelDbContext>();
    await db.Database.MigrateAsync();

    if (args.Contains("--seed"))
    {
        Console.WriteLine("Seeding database...");
        await DbInitializer.SeedAsync(db);
        Console.WriteLine("Seeding completed.");
        return;
    }
}

var api = app.MapGroup("/api");

api.MapAuthEndpoints();
api.MapRoleEndpoints();
api.MapUserEndpoints();
api.MapHotelEndpoints();
api.MapRoomTypeEndpoints();
api.MapRoomEndpoints();
api.MapBookingEndpoints();

app.Run();
