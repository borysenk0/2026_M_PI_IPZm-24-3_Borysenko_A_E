using HotelApi.Domain.Models;
using HotelApi.Domain.Models.Enums;
using HotelApi.Infrastructure.Data;
using HotelApi.Application.Security;
using Microsoft.EntityFrameworkCore;

namespace HotelApi.Services.Data;

public static class DbInitializer
{
    public static async Task SeedAsync(HotelDbContext context)
    {
        context.Database.EnsureCreated();

        if (await context.Hotels.AnyAsync())
        {
            return; // DB has been seeded
        }

        var hotels = new List<Hotel>
        {
            new Hotel { Name = "Grand Royal Hotel" },
            new Hotel { Name = "Seaside Resort" },
            new Hotel { Name = "Mountain View Inn" }
        };

        context.Hotels.AddRange(hotels);
        await context.SaveChangesAsync();

        var roomTypes = new List<RoomType>
        {
            // Grand Royal Hotel
            new RoomType { HotelId = hotels[0].Id, Name = "Standard Single", Class = RoomClass.Standard, MaxOccupancy = 1, SleepingPlaces = "1 Single Bed", PricePerNight = 100 },
            new RoomType { HotelId = hotels[0].Id, Name = "Deluxe Double", Class = RoomClass.Deluxe, MaxOccupancy = 2, SleepingPlaces = "1 Queen Bed", PricePerNight = 250 },
            new RoomType { HotelId = hotels[0].Id, Name = "Royal Suite", Class = RoomClass.Suite, MaxOccupancy = 4, SleepingPlaces = "2 King Beds, 1 Sofa Bed", PricePerNight = 800 },

            // Seaside Resort
            new RoomType { HotelId = hotels[1].Id, Name = "Economy Twin", Class = RoomClass.Economy, MaxOccupancy = 2, SleepingPlaces = "2 Twin Beds", PricePerNight = 80 },
            new RoomType { HotelId = hotels[1].Id, Name = "Ocean View Comfort", Class = RoomClass.Comfort, MaxOccupancy = 3, SleepingPlaces = "1 King Bed, 1 Twin Bed", PricePerNight = 200 },

            // Mountain View Inn
            new RoomType { HotelId = hotels[2].Id, Name = "Standard Cabin", Class = RoomClass.Standard, MaxOccupancy = 2, SleepingPlaces = "1 Queen Bed", PricePerNight = 120 },
            new RoomType { HotelId = hotels[2].Id, Name = "Family Suite", Class = RoomClass.Suite, MaxOccupancy = 6, SleepingPlaces = "3 Queen Beds", PricePerNight = 450 }
        };

        context.RoomTypes.AddRange(roomTypes);
        await context.SaveChangesAsync();

        var rooms = new List<Room>
        {
            // Grand Royal Hotel
            new Room { HotelId = hotels[0].Id, RoomTypeId = roomTypes[0].Id, Number = 101, Status = "Available", Description = "Cozy single room near the elevator." },
            new Room { HotelId = hotels[0].Id, RoomTypeId = roomTypes[0].Id, Number = 102, Status = "Available", Description = "Cozy single room with a view." },
            new Room { HotelId = hotels[0].Id, RoomTypeId = roomTypes[1].Id, Number = 201, Status = "Available", Description = "Spacious deluxe room with premium amenities." },
            new Room { HotelId = hotels[0].Id, RoomTypeId = roomTypes[2].Id, Number = 501, Status = "Available", Description = "Top floor royal suite with a private balcony." },

            // Seaside Resort
            new Room { HotelId = hotels[1].Id, RoomTypeId = roomTypes[3].Id, Number = 11, Status = "Available", Description = "Budget-friendly twin room." },
            new Room { HotelId = hotels[1].Id, RoomTypeId = roomTypes[4].Id, Number = 22, Status = "Available", Description = "Comfortable room with a stunning ocean view." },

            // Mountain View Inn
            new Room { HotelId = hotels[2].Id, RoomTypeId = roomTypes[5].Id, Number = 301, Status = "Available", Description = "Rustic cabin feel with modern comfort." },
            new Room { HotelId = hotels[2].Id, RoomTypeId = roomTypes[6].Id, Number = 401, Status = "Available", Description = "Large suite perfect for big families." }
        };

        context.Rooms.AddRange(rooms);
        await context.SaveChangesAsync();

        if (!await context.Users.AnyAsync())
        {
            var adminUser = new AppUser
            {
                FullName = "System Administrator",
                Email = "admin@hotel.com",
                PasswordHash = PasswordHasher.Hash("Admin123!"),
                RoleId = 1 // Admin
            };

            var guestUser = new AppUser
            {
                FullName = "John Doe",
                Email = "guest@hotel.com",
                PasswordHash = PasswordHasher.Hash("Guest123!"),
                RoleId = 2 // Guest
            };

            context.Users.AddRange(adminUser, guestUser);
            await context.SaveChangesAsync();
        }
    }
}
