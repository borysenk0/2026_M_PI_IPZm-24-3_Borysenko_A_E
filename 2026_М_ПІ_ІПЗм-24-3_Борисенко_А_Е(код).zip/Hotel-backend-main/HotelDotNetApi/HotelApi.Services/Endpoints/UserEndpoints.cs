using HotelApi.Application.Users;
using Microsoft.EntityFrameworkCore;

namespace HotelApi.Services.Endpoints;

public static class UserEndpoints
{
    public static RouteGroupBuilder MapUserEndpoints(this RouteGroupBuilder api)
    {
        var group = api.MapGroup("/users").WithTags("Users").RequireAuthorization();

        group.MapGet("/", async (IUserService svc, CancellationToken ct) => await svc.GetAllAsync(ct))
             .RequireAuthorization("Admin");

        group.MapGet("/{id:int}", async (int id, IUserService svc, CancellationToken ct) =>
        {
            var item = await svc.GetByIdAsync(id, ct);
            return item is null ? Results.NotFound() : Results.Ok(item);
        })
        .AddEndpointFilter(AuthorizationFilters.AdminOrOwnerFilter);

        group.MapPost("/", async (CreateUserDto dto, IUserService svc, CancellationToken ct) =>
        {
            try
            {
                var created = await svc.CreateAsync(dto, ct);
                return Results.Created($"/api/users/{created.Id}", created);
            }
            catch (DbUpdateException)
            {
                return Results.Conflict("Could not create user (duplicate email or invalid role).");
            }
        })
        .RequireAuthorization("Admin");

        group.MapPut("/{id:int}", async (int id, UpdateUserDto dto, IUserService svc, CancellationToken ct) =>
        {
            try
            {
                var updated = await svc.UpdateAsync(id, dto, ct);
                return updated is null ? Results.NotFound() : Results.Ok(updated);
            }
            catch (DbUpdateException)
            {
                return Results.Conflict("Could not update user.");
            }
        })
        .AddEndpointFilter(AuthorizationFilters.AdminOrOwnerFilter);

        group.MapDelete("/{id:int}", async (int id, IUserService svc, CancellationToken ct) =>
        {
            var ok = await svc.DeleteAsync(id, ct);
            if (!ok)
                return Results.Conflict("User not found or has bookings.");
            return Results.NoContent();
        })
        .RequireAuthorization("Admin");

        return api;
    }
}
