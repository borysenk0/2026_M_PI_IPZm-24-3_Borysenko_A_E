using HotelApi.Application.Roles;
using Microsoft.EntityFrameworkCore;

namespace HotelApi.Services.Endpoints;

public static class RoleEndpoints
{
    public static RouteGroupBuilder MapRoleEndpoints(this RouteGroupBuilder api)
    {
        var group = api.MapGroup("/roles").WithTags("Roles").RequireAuthorization("Admin");

        group.MapGet("/", async (IRoleService svc, CancellationToken ct) => await svc.GetAllAsync(ct));

        group.MapGet("/{id:int}", async (int id, IRoleService svc, CancellationToken ct) =>
        {
            var item = await svc.GetByIdAsync(id, ct);
            return item is null ? Results.NotFound() : Results.Ok(item);
        });

        group.MapPost("/", async (CreateRoleDto dto, IRoleService svc, CancellationToken ct) =>
        {
            try
            {
                var created = await svc.CreateAsync(dto, ct);
                return Results.Created($"/api/roles/{created.Id}", created);
            }
            catch (DbUpdateException)
            {
                return Results.Conflict("Could not create role (duplicate name or constraint violation).");
            }
        });

        group.MapPut("/{id:int}", async (int id, UpdateRoleDto dto, IRoleService svc, CancellationToken ct) =>
        {
            try
            {
                var updated = await svc.UpdateAsync(id, dto, ct);
                return updated is null ? Results.NotFound() : Results.Ok(updated);
            }
            catch (DbUpdateException)
            {
                return Results.Conflict("Could not update role.");
            }
        });

        group.MapDelete("/{id:int}", async (int id, IRoleService svc, CancellationToken ct) =>
        {
            var ok = await svc.DeleteAsync(id, ct);
            if (!ok)
                return Results.Conflict("Role not found or still assigned to users.");
            return Results.NoContent();
        });

        return api;
    }
}
