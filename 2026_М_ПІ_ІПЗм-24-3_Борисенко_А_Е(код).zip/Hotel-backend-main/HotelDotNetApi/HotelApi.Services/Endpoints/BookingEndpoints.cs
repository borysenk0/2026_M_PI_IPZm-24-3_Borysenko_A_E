using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using HotelApi.Application.Bookings;
using Microsoft.EntityFrameworkCore;

namespace HotelApi.Services.Endpoints;

public static class BookingEndpoints
{
    public static RouteGroupBuilder MapBookingEndpoints(this RouteGroupBuilder api)
    {
        var group = api.MapGroup("/bookings").WithTags("Bookings").RequireAuthorization();

        group.MapGet("/", async (IBookingService svc, CancellationToken ct) => await svc.GetAllAsync(ct))
             .RequireAuthorization("Admin");

        group.MapGet("/{id:int}", async (int id, IBookingService svc, CancellationToken ct) =>
        {
            var item = await svc.GetByIdAsync(id, ct);
            return item is null ? Results.NotFound() : Results.Ok(item);
        })
        .AddEndpointFilter(AuthorizationFilters.AdminOrBookingOwnerFilter);

        group.MapPost("/", async (ClaimsPrincipal user, CreateBookingDto dto, IBookingService svc, CancellationToken ct) =>
        {
            // If not admin, force the UserId to be the current user
            var userIdToUse = dto.UserId;
            if (!user.IsInRole("Admin"))
            {
                var userIdClaim = user.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;
                if (userIdClaim != null && int.TryParse(userIdClaim, out int currentUserId))
                {
                    userIdToUse = currentUserId;
                }
            }

            var dtoToUse = dto with { UserId = userIdToUse };

            try
            {
                var created = await svc.CreateAsync(dtoToUse, ct);
                return Results.Created($"/api/bookings/{created.Id}", created);
            }
            catch (ArgumentException ex)
            {
                return Results.BadRequest(ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                return Results.BadRequest(ex.Message);
            }
            catch (DbUpdateException)
            {
                return Results.Conflict("Could not create booking (invalid user or room).");
            }
        });

        group.MapPut("/{id:int}", async (ClaimsPrincipal user, int id, UpdateBookingDto dto, IBookingService svc, CancellationToken ct) =>
        {
            // If not admin, ensure the UserId remains the same or matches current user
            // Actually, the filter already checked that the EXISTING booking belongs to the user.
            // But we should also prevent them from changing the UserId field in the DTO to someone else's.
            
            var userIdToUse = dto.UserId;
            if (!user.IsInRole("Admin"))
            {
                var userIdClaim = user.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;
                if (userIdClaim != null && int.TryParse(userIdClaim, out int currentUserId))
                {
                    userIdToUse = currentUserId;
                }
            }

            var dtoToUse = dto with { UserId = userIdToUse };

            try
            {
                var updated = await svc.UpdateAsync(id, dtoToUse, ct);
                return updated is null ? Results.NotFound() : Results.Ok(updated);
            }
            catch (ArgumentException ex)
            {
                return Results.BadRequest(ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                return Results.BadRequest(ex.Message);
            }
            catch (DbUpdateException)
            {
                return Results.Conflict("Could not update booking.");
            }
        })
        .AddEndpointFilter(AuthorizationFilters.AdminOrBookingOwnerFilter);

        group.MapDelete("/{id:int}", async (int id, IBookingService svc, CancellationToken ct) =>
        {
            var ok = await svc.DeleteAsync(id, ct);
            return ok ? Results.NoContent() : Results.NotFound();
        })
        .AddEndpointFilter(AuthorizationFilters.AdminOrBookingOwnerFilter);

        return api;
    }
}
