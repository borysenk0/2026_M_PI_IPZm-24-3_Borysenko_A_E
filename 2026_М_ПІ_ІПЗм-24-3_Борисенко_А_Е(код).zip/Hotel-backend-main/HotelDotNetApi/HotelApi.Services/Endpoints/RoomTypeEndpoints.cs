using HotelApi.Application.RoomTypes;
using Microsoft.EntityFrameworkCore;

namespace HotelApi.Services.Endpoints;

public static class RoomTypeEndpoints
{
    public static RouteGroupBuilder MapRoomTypeEndpoints(this RouteGroupBuilder api)
    {
        var group = api.MapGroup("/room-types").WithTags("Room Types");

        group.MapGet("/", async (IRoomTypeService svc, CancellationToken ct) => await svc.GetAllAsync(ct));

        group.MapGet("/by-hotel/{hotelId:int}", async (int hotelId, IRoomTypeService svc, CancellationToken ct) =>
            await svc.GetByHotelIdAsync(hotelId, ct));

        group.MapGet("/{id:int}", async (int id, IRoomTypeService svc, CancellationToken ct) =>
        {
            var item = await svc.GetByIdAsync(id, ct);
            return item is null ? Results.NotFound() : Results.Ok(item);
        });

        group.MapPost("/", async (CreateRoomTypeDto dto, IRoomTypeService svc, CancellationToken ct) =>
        {
            try
            {
                var created = await svc.CreateAsync(dto, ct);
                return Results.Created($"/api/room-types/{created.Id}", created);
            }
            catch (InvalidOperationException ex)
            {
                return Results.BadRequest(ex.Message);
            }
            catch (ArgumentException ex)
            {
                return Results.BadRequest(ex.Message);
            }
            catch (DbUpdateException)
            {
                return Results.Conflict("Could not create room type (duplicate name in hotel or invalid hotel).");
            }
        })
        .RequireAuthorization("Admin");

        group.MapPut("/{id:int}", async (int id, UpdateRoomTypeDto dto, IRoomTypeService svc, CancellationToken ct) =>
        {
            try
            {
                var updated = await svc.UpdateAsync(id, dto, ct);
                return updated is null ? Results.NotFound() : Results.Ok(updated);
            }
            catch (InvalidOperationException ex)
            {
                return Results.BadRequest(ex.Message);
            }
            catch (ArgumentException ex)
            {
                return Results.BadRequest(ex.Message);
            }
            catch (DbUpdateException)
            {
                return Results.Conflict("Could not update room type.");
            }
        })
        .RequireAuthorization("Admin");

        group.MapDelete("/{id:int}", async (int id, IRoomTypeService svc, CancellationToken ct) =>
        {
            var ok = await svc.DeleteAsync(id, ct);
            if (!ok)
                return Results.Conflict("Room type not found or still assigned to rooms.");
            return Results.NoContent();
        })
        .RequireAuthorization("Admin");

        return api;
    }
}
