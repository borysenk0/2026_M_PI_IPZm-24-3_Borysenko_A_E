using HotelApi.Application.Rooms;
using Microsoft.EntityFrameworkCore;

namespace HotelApi.Services.Endpoints;

public static class RoomEndpoints
{
    public static RouteGroupBuilder MapRoomEndpoints(this RouteGroupBuilder api)
    {
        var group = api.MapGroup("/rooms").WithTags("Rooms");

        group.MapGet("/", async (IRoomService svc, CancellationToken ct) => await svc.GetAllAsync(ct));

        group.MapGet("/{id:int}", async (int id, IRoomService svc, CancellationToken ct) =>
        {
            var item = await svc.GetByIdAsync(id, ct);
            return item is null ? Results.NotFound() : Results.Ok(item);
        });

        group.MapPost("/", async (CreateRoomDto dto, IRoomService svc, CancellationToken ct) =>
        {
            try
            {
                var created = await svc.CreateAsync(dto, ct);
                return Results.Created($"/api/rooms/{created.Id}", created);
            }
            catch (InvalidOperationException ex)
            {
                return Results.BadRequest(ex.Message);
            }
            catch (DbUpdateException)
            {
                return Results.Conflict("Could not create room (duplicate number in hotel or invalid hotel).");
            }
        })
        .RequireAuthorization("Admin");

        group.MapPut("/{id:int}", async (int id, UpdateRoomDto dto, IRoomService svc, CancellationToken ct) =>
        {
            try
            {
                var updated = await svc.UpdateAsync(id, dto, ct);
                return updated is null ? Results.NotFound() : Results.Ok(updated);
            }
            catch (InvalidOperationException ex)
            {
                return Results.BadRequest(ex.Message);
            }
            catch (DbUpdateException)
            {
                return Results.Conflict("Could not update room.");
            }
        })
        .RequireAuthorization("Admin");

        group.MapDelete("/{id:int}", async (int id, IRoomService svc, CancellationToken ct) =>
        {
            var ok = await svc.DeleteAsync(id, ct);
            if (!ok)
                return Results.Conflict("Room not found or has bookings.");
            return Results.NoContent();
        })
        .RequireAuthorization("Admin");

        return api;
    }
}
