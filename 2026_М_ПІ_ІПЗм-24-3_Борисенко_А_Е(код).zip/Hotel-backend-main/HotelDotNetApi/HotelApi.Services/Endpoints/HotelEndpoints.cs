using HotelApi.Application.Hotels;

namespace HotelApi.Services.Endpoints;

public static class HotelEndpoints
{
    public static RouteGroupBuilder MapHotelEndpoints(this RouteGroupBuilder api)
    {
        var group = api.MapGroup("/hotels").WithTags("Hotels");

        group.MapGet("/", async (IHotelService svc, CancellationToken ct) => await svc.GetAllAsync(ct));

        group.MapGet("/{id:int}", async (int id, IHotelService svc, CancellationToken ct) =>
        {
            var item = await svc.GetByIdAsync(id, ct);
            return item is null ? Results.NotFound() : Results.Ok(item);
        });

        group.MapPost("/", async (CreateHotelDto dto, IHotelService svc, CancellationToken ct) =>
        {
            var created = await svc.CreateAsync(dto, ct);
            return Results.Created($"/api/hotels/{created.Id}", created);
        })
        .RequireAuthorization("Admin");

        group.MapPut("/{id:int}", async (int id, UpdateHotelDto dto, IHotelService svc, CancellationToken ct) =>
        {
            var updated = await svc.UpdateAsync(id, dto, ct);
            return updated is null ? Results.NotFound() : Results.Ok(updated);
        })
        .RequireAuthorization("Admin");

        group.MapDelete("/{id:int}", async (int id, IHotelService svc, CancellationToken ct) =>
        {
            var ok = await svc.DeleteAsync(id, ct);
            if (!ok)
                return Results.Conflict("Hotel not found or has rooms.");
            return Results.NoContent();
        })
        .RequireAuthorization("Admin");

        return api;
    }
}
