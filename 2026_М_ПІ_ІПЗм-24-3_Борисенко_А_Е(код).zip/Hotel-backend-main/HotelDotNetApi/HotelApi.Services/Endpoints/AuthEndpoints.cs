using HotelApi.Application.Users;

namespace HotelApi.Services.Endpoints;

public static class AuthEndpoints
{
    public static void MapAuthEndpoints(this RouteGroupBuilder api)
    {
        var group = api.MapGroup("/auth").WithTags("Auth");

        group.MapPost("/register", async (RegisterDto dto, IUserService svc, CancellationToken ct) =>
        {
            try
            {
                var result = await svc.RegisterAsync(dto, ct);
                return Results.Ok(result);
            }
            catch (InvalidOperationException ex)
            {
                return Results.Conflict(ex.Message);
            }
        });

        group.MapPost("/login", async (LoginDto dto, IUserService svc, CancellationToken ct) =>
        {
            var result = await svc.LoginAsync(dto, ct);
            return result is null ? Results.Unauthorized() : Results.Ok(result);
        });
    }
}
