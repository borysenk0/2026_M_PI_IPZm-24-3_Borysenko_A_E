using System.IdentityModel.Tokens.Jwt;
using HotelApi.Application.Bookings;

namespace HotelApi.Services.Endpoints;

public static class AuthorizationFilters
{
    public static async ValueTask<object?> AdminOrOwnerFilter(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var user = context.HttpContext.User;
        if (user.IsInRole("Admin"))
        {
            return await next(context);
        }

        // Try to get userId from route
        if (context.HttpContext.Request.RouteValues.TryGetValue("id", out var idValue) && 
            int.TryParse(idValue?.ToString(), out int id))
        {
            var userIdClaim = user.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;
            if (userIdClaim != null && int.TryParse(userIdClaim, out int currentUserId) && currentUserId == id)
            {
                return await next(context);
            }
        }

        return Results.Forbid();
    }

    public static async ValueTask<object?> AdminOrBookingOwnerFilter(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var user = context.HttpContext.User;
        if (user.IsInRole("Admin"))
        {
            return await next(context);
        }

        // We need the booking service to check ownership
        var bookingSvc = context.HttpContext.RequestServices.GetRequiredService<IBookingService>();

        if (context.HttpContext.Request.RouteValues.TryGetValue("id", out var idValue) && 
            int.TryParse(idValue?.ToString(), out int bookingId))
        {
            var booking = await bookingSvc.GetByIdAsync(bookingId);
            if (booking == null) return Results.NotFound();

            var userIdClaim = user.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;
            if (userIdClaim != null && int.TryParse(userIdClaim, out int currentUserId) && currentUserId == booking.UserId)
            {
                return await next(context);
            }
        }

        return Results.Forbid();
    }
}
