namespace HotelApi.Domain.Models;

public class Hotel
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;

    public ICollection<RoomType> RoomTypes { get; set; } = new List<RoomType>();
    public ICollection<Room> Rooms { get; set; } = new List<Room>();
}
