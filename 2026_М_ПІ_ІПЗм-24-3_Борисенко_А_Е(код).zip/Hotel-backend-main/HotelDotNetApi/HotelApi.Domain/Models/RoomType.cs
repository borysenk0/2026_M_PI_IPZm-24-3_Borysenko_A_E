using HotelApi.Domain.Models.Enums;

namespace HotelApi.Domain.Models;

/// <summary>
/// A bookable room category for a hotel (layout, capacity, class, nightly price).
/// Physical <see cref="Room"/> units reference one room type.
/// </summary>
public class RoomType
{
    public int Id { get; set; }

    /// <summary>Display name, e.g. "Standard Twin".</summary>
    public string Name { get; set; } = string.Empty;

    public RoomClass Class { get; set; }

    /// <summary>Maximum number of guests.</summary>
    public int MaxOccupancy { get; set; }

    /// <summary>Human-readable bed layout, e.g. "1 queen bed" or "2 twin beds".</summary>
    public string SleepingPlaces { get; set; } = string.Empty;

    /// <summary>Base price per night for this category at this hotel.</summary>
    public decimal PricePerNight { get; set; }

    public int HotelId { get; set; }

    public Hotel Hotel { get; set; } = null!;
    public ICollection<Room> Rooms { get; set; } = new List<Room>();
}
