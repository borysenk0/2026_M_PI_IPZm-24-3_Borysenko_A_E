namespace HotelApi.Domain.Models;

public class Booking
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public int RoomId { get; set; }
    public DateOnly CheckInDate { get; set; }
    public DateOnly CheckOutDate { get; set; }
    public string Status { get; set; } = string.Empty;

    public AppUser User { get; set; } = null!;
    public Room Room { get; set; } = null!;
}
