namespace HotelApi.Domain.Models;

public class Room
{
    public int Id { get; set; }
    public int Number { get; set; }
    public string Status { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public int HotelId { get; set; }
    public int RoomTypeId { get; set; }

    public Hotel Hotel { get; set; } = null!;
    public RoomType RoomType { get; set; } = null!;
    public ICollection<Booking> Bookings { get; set; } = new List<Booking>();
}
