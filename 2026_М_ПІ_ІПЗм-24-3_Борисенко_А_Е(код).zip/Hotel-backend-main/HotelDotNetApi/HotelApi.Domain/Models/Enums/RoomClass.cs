namespace HotelApi.Domain.Models.Enums;

/// <summary>
/// Category / tier of a room (e.g. economy vs standard vs suite).
/// </summary>
public enum RoomClass
{
    Economy,
    Standard,
    Comfort,
    Deluxe,
    Suite
}
