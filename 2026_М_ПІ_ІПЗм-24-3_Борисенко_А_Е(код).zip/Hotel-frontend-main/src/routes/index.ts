import { createRouter, createWebHistory } from "vue-router";
import { useAuthStore } from '@/stores/auth'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: "/",
      name: "home",
      component: () => import("@/components/home/HomeComponent.vue"),
    },
    {
      path: "/login",
      name: "login",
      component: () => import("@/components/auth/LoginComponent.vue"),
    },
    {
      path: "/register",
      name: "register",
      component: () => import("@/components/auth/RegisterComponent.vue"),
    },
    {
      path: "/reset",
      name: "reset",
      component: () => import("@/components/auth/ResetPassword.vue"),
    },
    {
      path: "/restaurant",
      name: "guest-menu",
      component: () => import("@/components/guest/GuestMenuPage.vue"),
    },
    {
      path: "/kds",
      component: () => import("@/components/restaurant/RestaurantShell.vue"),
      meta: { roles: ['manager', 'admin'] },
      children: [
        { path: "", name: "kds-board", component: () => import("@/components/staff/KdsBoard.vue") },
        { path: "orders", name: "restaurant-orders", component: () => import("@/components/restaurant/RestaurantOrdersTable.vue") },
        { path: "tables", name: "restaurant-tables", component: () => import("@/components/restaurant/RestaurantTablesTable.vue") },
        { path: "inventory", name: "restaurant-inventory", component: () => import("@/components/restaurant/RestaurantInventoryTable.vue") },
        { path: "menu", name: "restaurant-menu", component: () => import("@/components/restaurant/RestaurantMenuTable.vue") },
      ],
    },
    {
      path: "/booking",
      name: "booking",
      component: () => import("@/components/booking/BookingComponent.vue"),
      meta: { roles: ['user', 'admin'] }
    },
    {
      path: "/room-info",
      name: "room-info",
      component: () => import("@/components/guest/RoomInfoComponent.vue"),
      meta: { roles: ['user', 'admin'] }
    },
    {
      path: "/support",
      name: "support",
      component: () => import("@/components/support/SupportComponent.vue"),
    },
    {
      path: "/admin",
      component: () => import("@/components/admin/AdminShell.vue"),
      meta: { roles: ['admin'] },
      children: [
        { path: "", name: "admin-dashboard", component: () => import("@/components/admin/AdminDashboard.vue") },
        { path: "users", name: "admin-users", component: () => import("@/components/admin/AdminUsersTable.vue") },
        { path: "rooms", name: "admin-rooms", component: () => import("@/components/admin/AdminRoomsAdminTable.vue") },
        { path: "bookings", name: "admin-bookings", component: () => import("@/components/admin/AdminBookingsTable.vue") },
        { path: "roles", name: "admin-roles", component: () => import("@/components/admin/AdminRolesTable.vue") },
        { path: "orders", name: "admin-restaurant-orders", component: () => import("@/components/restaurant/RestaurantOrdersTable.vue") },
        { path: "tables", name: "admin-restaurant-tables", component: () => import("@/components/restaurant/RestaurantTablesTable.vue") },
        { path: "inventory", name: "admin-restaurant-inventory", component: () => import("@/components/restaurant/RestaurantInventoryTable.vue") },
        { path: "menu", name: "admin-restaurant-menu", component: () => import("@/components/restaurant/RestaurantMenuTable.vue") },
      ],
    },
    {
      path: '/:catchAll(.*)',
      name: 'NotFound',
      component: () => import("@/components/home/HomeComponent.vue"),
      meta: { requiresAuth: false }
    }
  ],
});

router.beforeEach((to, from, next) => {
  const auth = useAuthStore();
  if (to.meta.roles) {
    if (!auth.isLoggedIn) {
      return next({
        name: 'login',
        query: { redirect: to.fullPath }
      });
    }

    const allowedRoles = to.meta.roles as string[];

    if (!allowedRoles.includes(auth.role)) {
      console.warn(`Access denied: User role "${auth.role}" does not have permission to access "${to.path}"`);
      return next({ name: 'home' });
    }
  }

  next();
})

export default router;