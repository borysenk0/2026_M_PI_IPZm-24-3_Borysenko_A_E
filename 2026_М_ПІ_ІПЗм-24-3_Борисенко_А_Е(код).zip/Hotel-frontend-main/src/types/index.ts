export type Id = number;

export type RoleName = 'user' | 'manager' | 'admin';

export interface Role {
  id: Id;
  name: RoleName;
}

export interface User {
  id: Id;
  full_name: string;
  role_id: Id;
  email: string;
}

export interface Hotel {
  id: Id;
  name: string;
  description: string;
}

export interface Restaurant {
  id: Id;
  name: string;
  hotel_id: Id;
}

export type RoomStatus = 'AVAILABLE' | 'RESERVED' | 'OCCUPIED';

export interface Room {
  id: Id;
  number: number;
  status: RoomStatus;
  description: string;
  hotel_id: Id;
  pricePerNight?: number;
  beds?: number;
  title?: string;
}

export type TableStatus = 'AVAILABLE' | 'RESERVED' | 'OCCUPIED';

export interface Table {
  id: Id;
  number: number;
  status: TableStatus;
  restaurant_id: Id;
}

export type BookingStatus = 'PENDING' | 'CONFIRMED' | 'CHECKED_IN' | 'CHECKED_OUT' | 'CANCELLED';

export interface Booking {
  id: Id;
  user_id: Id;
  room_id: Id;
  check_in_date: string;
  check_out_date: string;
  status: BookingStatus;
  total_price?: number;
}

export type OrderStatus = 'NEW' | 'IN_PROGRESS' | 'COOKING' | 'READY' | 'SERVED' | 'CANCELLED' | 'PAID';

export interface Order {
  id: Id;
  user_id: Id;
  table_id: Id | null;
  booking_id: Id | null;
  status: OrderStatus;
  total_price: number;
  created_at: string;
  estimated_prep_minutes: number;
}

export interface Dish {
  id: Id;
  name: string;
  cost: number;
  category?: string;
  prepTimeMinutes?: number;
  isAvailable?: boolean;
  dishIngredients?: DishIngredient[];
}

export interface OrderDish {
  id: Id;
  order_id: Id;
  dish_id: Id;
  quantity: number;
}

export interface Ingredient {
  id: Id;
  name: string;
  count: number;
  unit: string;
  min_threshold: number;
}

export interface DishIngredient {
  id: Id;
  dish_id: Id;
  ingredient_id: Id;
  quantity_required: number;
}
