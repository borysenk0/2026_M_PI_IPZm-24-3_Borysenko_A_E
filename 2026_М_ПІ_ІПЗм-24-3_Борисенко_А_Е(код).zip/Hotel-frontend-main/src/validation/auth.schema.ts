import * as yup from 'yup';

const emailRule = yup.string().required('Email обов’язковий').email('Введіть коректну пошту');
const passwordRule = yup.string().required('Пароль обов’язковий').min(6, 'Мінімум 6 символів');
const confirmPasswordRule = yup.string().required('Підтвердьте пароль').oneOf([yup.ref('password')], 'Паролі не співпадають')

export const loginSchema = yup.object({
    email: emailRule,
    password: passwordRule,
});

export const registerSchema = yup.object({
    email: emailRule,
    password: passwordRule,
    confirmPassword: confirmPasswordRule,
    agreeTerms: yup
        .boolean()
        .oneOf([true], 'Ви повинні погодитися з умовами'),
})

export const forgotPasswordSchema = yup.object({
    email: emailRule,
})