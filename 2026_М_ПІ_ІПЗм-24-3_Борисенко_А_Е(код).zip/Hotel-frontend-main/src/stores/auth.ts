import { defineStore } from 'pinia';
import { computed, ref } from 'vue';
import type { RoleName as UserRole } from '@/types';
import api from '@/api';

export interface AuthUser {
  id?: number;
  name: string;
  email: string;
  role: UserRole;
}

export const useAuthStore = defineStore(
  'auth',
  () => {
    const user = ref<AuthUser | null>(null);
    const token = ref<string | null>(null);

    const isLoggedIn = computed(() => !!user.value);
    const role = computed<UserRole>(() => user.value?.role ?? 'guest');
    const getUserName = computed(() => user.value?.name || 'Гість');

    function setUser(userData: AuthUser, userToken: string) {
      user.value = userData;
      token.value = userToken;
    }

    async function login(email: string, pass: string) {
      try {
        const res = await api.post('/auth/login', { email, password: pass });
        const { access_token, user: userData } = res.data;
        setUser({
          id: userData.id,
          name: userData.full_name,
          email: userData.email,
          role: userData.role?.name || 'user'
        }, access_token);
        return true;
      } catch (err) {
        console.error('Login error', err);
        return false;
      }
    }

    async function register(name: string, email: string, pass: string) {
      try {
        const res = await api.post('/auth/register', { full_name: name, email, password: pass });
        const { access_token, user: userData } = res.data;
        setUser({
          id: userData.id,
          name: userData.full_name,
          email: userData.email,
          role: userData.role?.name || 'user'
        }, access_token);
        return true;
      } catch (err) {
        console.error('Register error', err);
        return false;
      }
    }

    function logout() {
      user.value = null;
      token.value = null;
    }

    return {
      user,
      token,
      role,
      isLoggedIn,
      getUserName,
      setUser,
      login,
      register,
      logout,
    };
  },
  { persist: true },
);