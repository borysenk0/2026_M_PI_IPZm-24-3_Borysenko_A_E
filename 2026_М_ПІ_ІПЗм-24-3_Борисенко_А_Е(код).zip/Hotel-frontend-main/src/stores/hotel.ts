import { defineStore } from 'pinia';
import { computed, ref } from 'vue';
import type {
  Booking,
  Dish,
  DishIngredient,
  Hotel,
  Ingredient,
  Order,
  OrderDish,
  Restaurant,
  Role,
  Room,
  Table,
  User,
} from '@/types';
import { useAuthStore } from '@/stores/auth';
import api from '@/api';

export interface HotelState {
  roles: Role[];
  users: User[];
  hotels: Hotel[];
  restaurants: Restaurant[];
  rooms: Room[];
  tables: Table[];
  bookings: Booking[];
  orders: Order[];
  dishes: Dish[];
  dishIngredients: DishIngredient[];
  orderDishes: OrderDish[];
  ingredients: Ingredient[];
}

export const useHotelStore = defineStore(
  'hotel',
  () => {
    const state = ref<HotelState>({
      roles: [],
      users: [],
      hotels: [],
      restaurants: [],
      rooms: [],
      tables: [],
      bookings: [],
      orders: [],
      dishes: [],
      dishIngredients: [],
      orderDishes: [],
      ingredients: [],
    });

    async function fetchAll() {
      try {
        const [usersRes, rolesRes, roomsRes, tablesRes, bookingsRes, dishesRes, restsRes, hotelsRes, ordersRes] = await Promise.all([
          api.get('/users'),
          api.get('/users/roles'),
          api.get('/rooms'),
          api.get('/tables'),
          api.get('/bookings'),
          api.get('/menu'),
          api.get('/restaurants'),
          api.get('/hotels'),
          api.get('/orders'),
        ]);

        state.value.users = usersRes.data.map((u: any) => ({ ...u, role_id: u.role_id || u.role?.id }));
        state.value.roles = rolesRes.data;
        state.value.rooms = roomsRes.data.map((r: any) => ({ ...r, status: r.status.toUpperCase() }));
        state.value.tables = tablesRes.data.map((t: any) => ({ ...t, status: t.status.toUpperCase() }));
        state.value.bookings = bookingsRes.data.map((b: any) => ({ ...b, status: b.status.toUpperCase() }));
        state.value.dishes = dishesRes.data;
        state.value.restaurants = Math.isArray?.(restsRes.data) ? restsRes.data : Array.isArray(restsRes.data) ? restsRes.data : [];
        state.value.hotels = Array.isArray(hotelsRes.data) ? hotelsRes.data : [];
        state.value.orders = Array.isArray(ordersRes.data) ? ordersRes.data.map((o: any) => ({ ...o, status: (o.status || '').toUpperCase() })) : [];
      } catch (err) {
        console.error('Failed to load full state', err);
      }
    }

    const auth = useAuthStore();

    const currentUser = computed<User | null>(() => {
      const email = auth.user?.email;
      if (!email) return null;
      return state.value.users.find((u) => u.email === email) ?? null;
    });

    const currentRole = computed<Role | null>(() => {
      const user = currentUser.value;
      if (!user) return null;
      return state.value.roles.find((r) => r.id === user.role_id) ?? null;
    });

    const currentUserBookings = computed<Booking[]>(() => {
      const user = currentUser.value;
      if (!user) return [];
      return state.value.bookings.filter((b) => b.user_id === user.id);
    });

    const today = () => {
      const d = new Date();
      const pad2 = (n: number) => String(n).padStart(2, '0');
      return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
    };

    const currentDateStr = computed(() => today());

    const activeBooking = computed<Booking | null>(() => {
      // Для перевірки статусу проживання головним є статус CHECKED_IN.
      // Дати можуть бути прострочені (напр. гість ще не виселився), 
      // але він все ще вважається мешканцем, поки статус не CHECKED_OUT.
      return (
        currentUserBookings.value.find((b) => b.status === 'CHECKED_IN') ?? null
      );
    });

    const isSettled = computed<boolean>(() => !!activeBooking.value);

    const currentRoom = computed<Room | null>(() => {
      const booking = activeBooking.value;
      if (!booking) return null;
      return state.value.rooms.find((r) => r.id === booking.room_id) ?? null;
    });

    const currentResidentOrder = computed<Order | null>(() => {
      const booking = activeBooking.value;
      const user = currentUser.value;
      if (!booking || !user) return null;
      // для демо: беремо найновіше замовлення
      const list = state.value.orders.filter(
        (o) => o.booking_id === booking.id && o.user_id === user.id,
      );
      if (list.length === 0) return null;
      return list.reduce((latest, o) =>
        o.created_at > latest.created_at ? o : latest,
      );
    });

    const currentResidentOrderStatus = computed(() => currentResidentOrder.value?.status ?? null);

    const residentOrdersForManager = computed<Order[]>(() =>
      state.value.orders.filter(
        (o) => o.booking_id !== null
      ),
    );

    return {
      state,
      fetchAll,
      currentUser,
      currentRole,
      currentUserBookings,
      activeBooking,
      isSettled,
      currentRoom,
      currentResidentOrder,
      currentResidentOrderStatus,
      residentOrdersForManager,
    };
  },
  { persist: true },
);

