import { defineStore } from 'pinia';
import { computed, ref } from 'vue';
import api from '@/api';

export interface InventoryItemDto {
  id: number;
  name: string;
  unit: string;
  currentStock: number;
  minThreshold: number;
}

export const useInventoryStore = defineStore('inventory', () => {
  const items = ref<InventoryItemDto[]>([]);

  function setItems(payload: InventoryItemDto[]) {
    items.value = payload;
  }

  async function loadIngredients() {
    try {
      const res = await api.get('/ingredients');
      items.value = res.data.map((ing: any) => ({
        id: ing.id,
        name: ing.name,
        unit: ing.unit,
        currentStock: ing.count,
        minThreshold: ing.min_threshold
      }));
    } catch (err) {
      console.error('Failed to load ingredients', err);
    }
  }

  const lowStockItems = computed(() =>
    items.value.filter((item) => item.currentStock <= item.minThreshold),
  );

  return {
    items,
    lowStockItems,
    setItems,
    loadIngredients
  };
}, { persist: true });

