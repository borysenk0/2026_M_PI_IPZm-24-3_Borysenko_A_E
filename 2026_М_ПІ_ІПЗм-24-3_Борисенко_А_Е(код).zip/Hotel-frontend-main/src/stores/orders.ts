import { defineStore } from 'pinia';
import { ref } from 'vue';
import api from '@/api';

export enum OrderItemStatus {
  ACCEPTED = 'ACCEPTED',
  COOKING = 'COOKING',
  READY = 'READY',
  SERVED = 'SERVED',
  CANCELED = 'CANCELED',
}

export interface OrderItemDto {
  id: number;
  menuItemName: string;
  quantity: number;
  status: OrderItemStatus;
  prepDeadlineAt?: string | null;
}

export interface OrderDto {
  id: number;
  tableLabel?: string | null;
  roomNumber?: string | null;
  status: string;
  createdAt: string;
  items: OrderItemDto[];
}

export const useOrdersStore = defineStore('orders', () => {
  const activeOrders = ref<OrderDto[]>([]);

  async function fetchOrders() {
    try {
      const res = await api.get('/orders/active');
      activeOrders.value = res.data.map((o: any) => ({
        id: o.id,
        tableLabel: o.table?.number?.toString(),
        roomNumber: o.booking?.room?.number?.toString(), // If booking populated
        status: o.status.toUpperCase(),
        createdAt: o.created_at || new Date().toISOString(),
        items: o.orderDishes?.map((od: any) => ({
          id: od.id,
          menuItemName: od.dish?.name || 'Unknown',
          quantity: od.quantity,
          status: o.status.toUpperCase(), // Simplification: apply order status to items
        })) || []
      }));
    } catch (err) {
      console.error('Fetch orders error', err);
    }
  }

  async function updateStatus(orderId: number, status: string) {
    try {
      await api.patch(`/orders/${orderId}/status`, { status });
      await fetchOrders(); // refresh
    } catch (err) {
      console.error('Update status error', err);
    }
  }

  return {
    activeOrders,
    fetchOrders,
    updateStatus,
  };
}, { persist: true });

