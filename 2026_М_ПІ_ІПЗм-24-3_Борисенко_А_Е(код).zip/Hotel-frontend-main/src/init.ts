import type { Pinia } from 'pinia';
import { useHotelStore } from '@/stores/hotel';

export function initStores(pinia: Pinia) {
  const hotel = useHotelStore(pinia);

  // Fetch all core resources on application startup
  hotel.fetchAll();
}
