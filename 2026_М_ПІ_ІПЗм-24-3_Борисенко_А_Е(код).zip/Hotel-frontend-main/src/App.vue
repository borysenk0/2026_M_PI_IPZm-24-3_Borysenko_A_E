<script setup>
import { onMounted, onUnmounted } from 'vue';
import { RouterView, useRouter } from 'vue-router'
import Header from "@/components/layout/Header.vue";
import { useHotelStore } from '@/stores/hotel';
import { io } from 'socket.io-client';

const hotel = useHotelStore();
let socket;

onMounted(() => {
  hotel.fetchAll(); // Initial fetch
  
  socket = io('http://localhost:3000');
  
  socket.on('orders_updated', () => {
    hotel.fetchAll(); // Real-time sync!
  });
});

onUnmounted(() => {
  if (socket) socket.disconnect();
});
</script>

<template>
  <div>
    <Header />
    <RouterView />
    <notifications position="top center" classes="my-custom-notification" />
  </div>
</template>

<style>
.my-custom-notification {
  margin: 10px;
  margin-bottom: 0;
  border-radius: 8px;
  font-size: 14px;
  padding: 12px 20px;
  color: #ffffff;
  background: #1a1a1a;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}
.my-custom-notification.success {
  background: #10b981;
}
.my-custom-notification.error {
  background: #ef4444;
}
</style>
