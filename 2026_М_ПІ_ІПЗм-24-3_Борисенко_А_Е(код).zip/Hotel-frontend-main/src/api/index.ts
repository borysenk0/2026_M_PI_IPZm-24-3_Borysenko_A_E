import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:3000/api', // Адреса нашого NestJS бекенду
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use((config) => {
  // Дістаємо токен із localStorage (де він збережений через pinia-plugin-persistedstate)
  const authRecord = localStorage.getItem('auth');
  if (authRecord) {
    try {
      const auth = JSON.parse(authRecord);
      if (auth.token) {
        config.headers.Authorization = `Bearer ${auth.token}`;
      }
    } catch {}
  }
  return config;
});

export default api;
