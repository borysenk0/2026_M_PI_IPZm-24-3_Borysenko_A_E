import './style.css'
import { createApp, markRaw } from 'vue'
import { createPinia } from 'pinia'
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate';
import router from './routes'
import App from './App.vue'
import Notifications from '@kyvg/vue3-notification'
import { initStores } from './init';

const app = createApp(App);
const pinia = createPinia();

pinia.use(piniaPluginPersistedstate);
pinia.use(({ store }) => {
    store.router = markRaw(router);
});

app.use(pinia);
app.use(router);
app.use(Notifications);

initStores(pinia);

app.mount('#app');