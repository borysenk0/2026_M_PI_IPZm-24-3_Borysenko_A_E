<script setup lang="ts">
import { computed, ref } from 'vue';
import { useHotelStore } from '@/stores/hotel';
import GuestLayout from '@/components/layouts/GuestLayout.vue';
import ThreeModelViewer from '@/components/three/ThreeModelViewer.vue';

const hotelStore = useHotelStore();

const cart = ref<{ dish_id: number; quantity: number }[]>([]);

const cartDishes = computed(() => {
  return cart.value.map(item => {
    const dish = hotelStore.state.dishes.find(d => d.id === item.dish_id);
    return {
      dish_id: item.dish_id,
      name: dish?.name ?? 'Unknown',
      cost: dish?.cost ?? 0,
      quantity: item.quantity,
      total: (dish?.cost ?? 0) * item.quantity
    };
  });
});

const cartTotal = computed(() => cartDishes.value.reduce((acc, curr) => acc + curr.total, 0));

const estimatedPrepTime = computed(() => {
  if (cart.value.length === 0) return 0;
  let maxPrep = 15;
  cart.value.forEach(item => {
    maxPrep += item.quantity * 2;
  });
  return maxPrep;
});

const addToCart = (dishId: number) => {
  const existing = cart.value.find(item => item.dish_id === dishId);
  if (existing) {
    existing.quantity++;
  } else {
    cart.value.push({ dish_id: dishId, quantity: 1 });
  }
};

const removeFromCart = (dishId: number) => {
  cart.value = cart.value.filter(item => item.dish_id !== dishId);
};

import api from '@/api';
import { useNotification } from '@kyvg/vue3-notification';
import { onMounted, onUnmounted } from 'vue';

const { notify } = useNotification();

const placeOrder = async () => {
  if (cart.value.length === 0) return;
  if (!hotelStore.currentUser || !hotelStore.activeBooking) {
    notify({ type: 'error', title: 'Помилка', text: 'Помилка ідентифікації гостя' });
    return;
  }
  try {
    await api.post('/orders', {
      user_id: hotelStore.currentUser.id,
      booking_id: hotelStore.activeBooking.id,
      total_price: cartTotal.value,
      dishes: cart.value
    });
    cart.value = [];
    await hotelStore.fetchAll();
    notify({ type: 'success', title: 'Успішно', text: 'Замовлення відправлено на кухню!' });
  } catch(e) {
    notify({ type: 'error', title: 'Помилка', text: 'Не вдалося створити замовлення' });
  }
};

const activeOrders = computed(() => {
  const booking = hotelStore.activeBooking;
  const user = hotelStore.currentUser;
  if (!booking || !user) return [];
  return hotelStore.state.orders.filter(
    (o) => o.booking_id === booking.id && o.user_id === user.id && !['SERVED', 'CANCELLED'].includes(o.status)
  ).sort((a, b) => b.id - a.id);
});

const historicalOrders = computed(() => {
  const booking = hotelStore.activeBooking;
  const user = hotelStore.currentUser;
  if (!booking || !user) return [];
  return hotelStore.state.orders.filter(
    (o) => o.booking_id === booking.id && o.user_id === user.id && ['SERVED', 'CANCELLED'].includes(o.status)
  ).sort((a, b) => b.id - a.id);
});

const statusText = (status: string) => {
  if (status === 'NEW') return 'В очікуванні підтвердження (Нове)';
  if (status === 'COOKING' || status === 'IN_PROGRESS') return 'Готується';
  if (status === 'READY') return 'Готово (чекайте доставку)';
  if (status === 'SERVED') return 'Доставлено';
  if (status === 'CANCELLED') return 'Скасовано';
  return status;
};

let poller: any;
onMounted(() => {
  hotelStore.fetchAll();
  poller = setInterval(() => {
    hotelStore.fetchAll();
  }, 5000);
});

onUnmounted(() => {
  clearInterval(poller);
});
</script>

<template>
  <GuestLayout>
    <section class="max-w-7xl mx-auto space-y-8">
      <header class="mb-6">
        <h1 class="text-3xl font-extrabold text-gray-900 tracking-tight">Наш ресторан</h1>
        <p class="text-gray-600 mt-2">
          Замовляйте страви безпосередньо у ваш номер.
        </p>
      </header>

      <div v-if="activeOrders.length > 0" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        <div v-for="order in activeOrders" :key="order.id" class="bg-amber-50 border border-amber-200 rounded-2xl p-6 flex flex-col space-y-4 shadow-sm hover:shadow-md transition">
          <div class="flex items-center gap-3">
            <div class="h-12 w-12 bg-amber-100 rounded-full flex items-center justify-center border border-amber-300">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h2 class="text-xl font-bold text-gray-900">Замовлення #{{ order.id }}</h2>
              <p class="text-sm text-amber-700 font-bold mt-0.5">{{ statusText(order.status) }}</p>
            </div>
          </div>
          <div class="pt-2 border-t border-amber-200/50">
            <p class="text-xs text-gray-800">
              <span class="font-semibold">Орієнтовний час очікування:</span> {{ order.estimated_prep_minutes }} хв
            </p>
            <p class="text-xs text-gray-800 mt-1">
              <span class="font-semibold">Сума:</span> {{ order.total_price }} ₴
            </p>
          </div>
          <div v-if="order.orderDishes && order.orderDishes.length > 0" class="pt-2">
            <h4 class="text-xs font-bold text-gray-600 uppercase mb-1">Склад замовлення:</h4>
            <ul class="text-xs text-gray-700 max-h-24 overflow-y-auto pr-2 space-y-1">
              <li v-for="od in order.orderDishes" :key="od.id" class="flex justify-between border-b border-amber-100 pb-1">
                <span class="truncate pr-2">{{ od.dish?.name }}</span>
                <span class="font-semibold">{{ od.quantity }} шт</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div class="lg:col-span-2 space-y-6">
          <h2 class="text-xl font-bold text-gray-900 border-b pb-3">Меню страв</h2>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div v-for="dish in hotelStore.state.dishes" :key="dish.id" class="p-4 border border-gray-200 bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between">
              <div>
                <h3 class="font-bold text-gray-900 text-lg">{{ dish.name }}</h3>
                <p class="text-xl font-extrabold text-[#1a1a1a] mt-2">{{ dish.cost }} ₴</p>
              </div>
              <button 
                @click="addToCart(dish.id)"
                class="mt-4 w-full bg-gray-50 hover:bg-black hover:text-white border border-gray-200 text-gray-900 py-2.5 rounded-xl font-bold text-sm transition-all"
              >
                Додати в кошик
              </button>
            </div>
          </div>
        </div>

        <aside class="space-y-6">
          <div class="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm sticky top-24">
            <h2 class="text-xl font-bold text-gray-900 border-b pb-3 mb-4">Ваше замовлення</h2>
            
            <div v-if="cartDishes.length > 0" class="space-y-4">
              <ul class="space-y-3">
                <li v-for="item in cartDishes" :key="item.dish_id" class="flex justify-between items-start text-sm border-b border-gray-50 pb-2">
                  <div class="flex-1">
                    <span class="font-semibold text-gray-900">{{ item.name }}</span>
                    <div class="text-gray-500 text-xs mt-0.5">К-ть: {{ item.quantity }} × {{ item.cost }} ₴</div>
                  </div>
                  <div class="flex flex-col items-end gap-1">
                    <span class="font-bold text-gray-900">{{ item.total }} ₴</span>
                    <button @click="removeFromCart(item.dish_id)" class="text-[10px] uppercase tracking-wider text-red-500 hover:text-red-700 font-bold">Видалити</button>
                  </div>
                </li>
              </ul>
              
              <div class="pt-2 border-t border-gray-200">
                <div class="flex justify-between text-gray-700 text-sm mb-2">
                  <span>Приблизний час:</span>
                  <span class="font-semibold">{{ estimatedPrepTime }} хв</span>
                </div>
                <div class="flex justify-between text-lg font-black text-gray-900">
                  <span>До сплати:</span>
                  <span>{{ cartTotal }} ₴</span>
                </div>
              </div>

              <button 
                @click="placeOrder"
                class="w-full bg-[#1a1a1a] hover:bg-black text-white py-3.5 rounded-xl font-bold uppercase tracking-wider text-sm transition-all shadow-md mt-4"
              >
                Оформити замовлення
              </button>
            </div>
            
            <div v-else class="text-center py-8 text-gray-500 text-sm">
              <p>Ваш кошик порожній.</p>
              <p class="mt-1">Оберіть страви з меню зліва.</p>
            </div>
          </div>
        </aside>
      </div>
      <div v-if="historicalOrders.length > 0" class="mt-12">
        <h2 class="text-xl font-bold text-gray-900 border-b pb-3 mb-6">Історія ваших замовлень (доставлені)</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div v-for="order in historicalOrders" :key="order.id" class="p-4 bg-white border border-gray-200 rounded-2xl shadow-sm opacity-80 hover:opacity-100 transition">
            <div class="flex justify-between items-center mb-2">
              <h3 class="font-bold text-gray-800">Замовлення #{{ order.id }}</h3>
              <span class="text-[10px] uppercase font-bold px-2 py-1 bg-gray-100 text-gray-600 rounded-full">
                {{ statusText(order.status) }}
              </span>
            </div>
            <div class="text-xs text-gray-500 mb-2">
              {{ new Date(order.created_at).toLocaleDateString() }}
            </div>
            <ul class="text-xs text-gray-700 space-y-1 border-t border-gray-100 pt-2 mb-2">
              <li v-for="od in order.orderDishes" :key="od.id" class="flex justify-between">
                <span class="truncate pr-2">{{ od.dish?.name }}</span>
                <span class="font-semibold">{{ od.quantity }} шт</span>
              </li>
            </ul>
            <div class="text-right font-bold pl-2 pt-2 border-t border-gray-100 text-sm">
              Всього: {{ order.total_price }} ₴
            </div>
          </div>
        </div>
      </div>
    </section>
  </GuestLayout>
</template>

<style scoped>
</style>
