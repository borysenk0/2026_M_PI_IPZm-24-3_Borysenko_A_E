<script setup lang="ts">
import { useHotelStore } from '@/stores/hotel';
// import GuestLayout from '@/components/layouts/GuestLayout.vue'; // We probably don't need a specific layout wrapper since App uses Header directly, but let's check
import ThreeModelViewer from '@/components/three/ThreeModelViewer.vue';

const hotelStore = useHotelStore();
</script>

<template>
  <main class="max-w-7xl mx-auto px-4 sm:px-6 py-8">
    <section class="max-w-5xl mx-auto space-y-8">
      <header class="mb-6">
        <h1 class="text-3xl font-extrabold text-gray-900 tracking-tight">Інформація номеру</h1>
        <p class="text-gray-600 mt-2">
          Детальна інформація про ваш поточний номер та умови перебування.
        </p>
      </header>

      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div v-if="hotelStore.currentRoom && hotelStore.activeBooking" class="bg-white border text-left border-gray-200 rounded-2xl shadow-sm p-6 space-y-6">
          
          <div>
            <h2 class="text-xl font-bold text-gray-900 border-b pb-3 mb-4">Технічні дані</h2>
            <ul class="space-y-3">
              <li class="flex justify-between items-center text-sm">
                <span class="text-gray-500 font-medium">Номер кімнати</span>
                <span class="font-bold text-gray-900 text-base">№ {{ hotelStore.currentRoom.number }}</span>
              </li>
              <li class="flex justify-between items-center text-sm">
                <span class="text-gray-500 font-medium">Опис</span>
                <span class="font-bold text-gray-900 text-sm max-w-[60%] text-right">{{ hotelStore.currentRoom.description }}</span>
              </li>
              <li class="flex justify-between items-center text-sm">
                <span class="text-gray-500 font-medium">Статус</span>
                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  {{ hotelStore.currentRoom.status }}
                </span>
              </li>
            </ul>
          </div>

          <div>
            <h2 class="text-xl font-bold text-gray-900 border-b pb-3 mb-4">Деталі бронювання</h2>
            <ul class="space-y-3">
              <li class="flex justify-between items-center text-sm">
                <span class="text-gray-500 font-medium">Дата заїзду</span>
                <span class="font-bold text-gray-900">{{ hotelStore.activeBooking.check_in_date }}</span>
              </li>
              <li class="flex justify-between items-center text-sm">
                <span class="text-gray-500 font-medium pb-0.5">Дата виїзду</span>
                <span class="font-bold text-red-600 text-base">{{ hotelStore.activeBooking.check_out_date }}</span>
              </li>
            </ul>
          </div>
          
        </div>
        
        <div v-else class="bg-white border border-gray-200 rounded-2xl shadow-sm p-6 flex flex-col items-center justify-center text-center min-h-[300px]">
          <p class="text-gray-500 text-lg font-medium">У вас немає активного поселення.</p>
        </div>

        <div class="h-[400px] w-full rounded-2xl overflow-hidden shadow-sm border border-gray-100 bg-gray-50">
          <ThreeModelViewer
            model-url="/models/room_draco.glb"
            :min-distance="1.4"
            :max-distance="10"
          />
        </div>
      </div>
    </section>
  </main>
</template>

<style scoped>
</style>
