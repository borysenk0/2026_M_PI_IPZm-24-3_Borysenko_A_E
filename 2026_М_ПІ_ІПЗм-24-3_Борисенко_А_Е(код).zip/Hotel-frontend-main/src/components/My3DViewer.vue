<template>
  <div class="page">
    <!-- Блок с 3D-моделью -->
    <section class="hero">
      <div ref="container" class="model-viewer"></div>
    </section>

    <!-- Блок с информацией об отеле -->
    <section class="info">
      <h1>Ласкаво просимо до нашого готелю</h1>
      <p>
        Наш готель пропонує комфортні номери, спа-зону, ресторан з авторською кухнею та унікальний сервіс для гостей.
        Тут ви зможете повністю розслабитися та насолодитися відпочинком.
      </p>
    </section>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import * as THREE from 'three'
import { OrbitControls, GLTFLoader, DRACOLoader } from 'three-stdlib'

const container = ref<HTMLDivElement | null>(null)

onMounted(() => {
  if (!container.value) return

  const scene = new THREE.Scene()
  scene.background = new THREE.Color(0x111111)

  const camera = new THREE.PerspectiveCamera(
      75,
      container.value.clientWidth / container.value.clientHeight,
      0.1,
      1000
  )
  camera.position.set(0, 1, 3)

  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
  renderer.setSize(container.value.clientWidth, container.value.clientHeight)
  container.value.appendChild(renderer.domElement)

  const ambientLight = new THREE.AmbientLight(0xffffff, 0.4)
  scene.add(ambientLight)

  const directionalLight = new THREE.DirectionalLight(0xffffff, 1)
  directionalLight.position.set(0, 5, 5)
  scene.add(directionalLight)

  const controls = new OrbitControls(camera, renderer.domElement)
  controls.enableDamping = true
  controls.dampingFactor = 0.05
  controls.enableZoom = true
  controls.minDistance = 1.2
  controls.maxDistance = 12

  const loader = new GLTFLoader()
  const draco = new DRACOLoader()
  draco.setDecoderPath('https://www.gstatic.com/draco/v1/decoders/')
  loader.setDRACOLoader(draco)
  loader.load(
      '/assets/models/hotel_draco.glb',
      (gltf) => {
        const model = gltf.scene
        model.scale.set(0.5, 0.5, 0.5)
        model.position.set(0, 0, 0)
        scene.add(model)
      },
      undefined,
      (error) => console.error('Ошибка при загрузке модели:', error)
  )

  const animate = () => {
    requestAnimationFrame(animate)
    controls.update()
    renderer.render(scene, camera)
  }
  animate()

  window.addEventListener('resize', () => {
    if (!container.value) return
    camera.aspect = container.value.clientWidth / container.value.clientHeight
    camera.updateProjectionMatrix()
    renderer.setSize(container.value.clientWidth, container.value.clientHeight)
  })
})
</script>

<style scoped>
.page {
  display: flex;
  flex-direction: column;
}

.hero {
  width: 100%;
  height: 500px; /* высота блока с моделью */
  overflow: hidden;
}

.model-viewer {
  width: 100%;
  height: 100%;
}

.info {
  padding: 2rem;
  background-color: #f5f5f5;
  color: #111;
}

.info h1 {
  font-size: 2rem;
  margin-bottom: 1rem;
}

.info p {
  font-size: 1.1rem;
  line-height: 1.6;
}
</style>
