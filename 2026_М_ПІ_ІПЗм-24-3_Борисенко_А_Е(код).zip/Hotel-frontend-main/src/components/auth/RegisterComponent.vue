<script setup lang="ts">
import {useForm} from "vee-validate";
import {registerSchema} from "@/validation/auth.schema";
import {useAuthStore} from "@/stores/auth";
import {useRouter} from "vue-router";

const { errors, defineField, handleSubmit } = useForm({
  validationSchema: registerSchema,
  initialValues: {
    agreeTerms: false,
  }
});

const [email, emailProps] = defineField('email');
const [password, passwordProps] = defineField('password');
const [confirmPassword, confirmPasswordProps] = defineField('confirmPassword');
const [agreeTerms, agreeTermsProps] = defineField('agreeTerms');

const authStore = useAuthStore();
const router = useRouter();

const handleRegister = handleSubmit(async (values) => {
  const name = values.email.split('@')[0]; // Simple name from email for now
  const ok = await authStore.register(name, values.email, values.password);

  if (ok) {
    router.push({ name: 'home' });
  } else {
    alert("Помилка реєстрації. Можливо, такий email вже існує.");
  }
});
</script>

<template>
  <section class="flex flex-col items-center justify-center min-h-screen bg-white p-4">
    <div class="w-full max-w-[400px]">

      <div class="text-center mb-10">
        <h2 class="text-3xl font-bold text-[#1a1a1a] mb-3">Приєднуйтесь сьогодні</h2>
        <p class="text-gray-500">Введіть пошту та пароль для реєстрації.</p>
      </div>

      <form @submit.prevent="handleRegister" class="space-y-6">
        <div>
          <label for="email" class="block text-sm font-bold text-[#1a1a1a] mb-2">Ваша пошта</label>
          <input
              id="email"
              v-model="email"
              v-bind="emailProps"
              type="email"
              placeholder="name@mail.com"
              :class="['w-full p-3 border rounded-lg outline-none transition-all',
                       errors.email ? 'border-red-500' : 'border-gray-300 focus:border-black']"
          />
          <span class="text-red-500 text-xs mt-1 block h-4">{{ errors.email }}</span>
        </div>

        <div>
          <label for="password" class="block text-sm font-bold text-[#1a1a1a] mb-2">Пароль</label>
          <input
              id="password"
              v-model="password"
              v-bind="passwordProps"
              type="password"
              placeholder="********"
              :class="['w-full p-3 border rounded-lg outline-none transition-all',
                       errors.password ? 'border-red-500' : 'border-gray-300 focus:border-black']"
          />
          <span class="text-red-500 text-xs mt-1 block h-4">{{ errors.password }}</span>
        </div>

        <div>
          <label for="confirmPassword" class="block text-sm font-bold text-[#1a1a1a] mb-2">Підтвердіть пароль</label>
          <input
              id="confirmPassword"
              v-model="confirmPassword"
              v-bind="confirmPasswordProps"
              type="password"
              placeholder="********"
              :class="['w-full p-3 border rounded-lg outline-none transition-all',
                       errors.confirmPassword ? 'border-red-500' : 'border-gray-300 focus:border-black']"
          />
          <span class="text-red-500 text-xs mt-1 block h-4">{{ errors.confirmPassword }}</span>
        </div>

        <div>
          <div class="flex items-center gap-3">
            <input
                id="terms"
                v-model="agreeTerms"
                v-bind="agreeTermsProps"
                type="checkbox"
                class="w-5 h-5 accent-black cursor-pointer"
            />
            <label for="terms" class="text-sm text-gray-600 cursor-pointer">
              Я погоджуюсь з <a href="#" class="underline font-medium text-black">Правилами та Умовами</a>
            </label>
          </div>
          <span class="text-red-500 text-xs mt-1 block h-4">{{ errors.agreeTerms }}</span>
        </div>

        <button
            type="submit"
            class="w-full bg-[#1a1a1a] text-white py-4 rounded-xl font-bold uppercase tracking-wide hover:bg-black transition-all shadow-md cursor-pointer"
        >
          Зареєструватися зараз
        </button>

        <div class="relative flex py-2 items-center">
          <div class="flex-grow border-t border-gray-200"></div>
          <span class="flex-shrink mx-4 text-gray-400 text-sm font-medium uppercase">Або</span>
          <div class="flex-grow border-t border-gray-200"></div>
        </div>

        <div class="space-y-3">
          <button type="button" class="w-full flex items-center justify-center gap-3 border border-gray-200 py-3 rounded-xl hover:bg-gray-50 transition-all font-bold text-xs uppercase text-gray-700 cursor-pointer">
            <img src="https://www.material-tailwind.com/logos/logo-google.png" alt="Google" class="h-5 w-5" />
            Зареєструватись через Google
          </button>
        </div>

        <p class="text-center text-gray-600 text-sm mt-6">
          Вже маєте акаунт?
          <router-link to="/login" class="font-bold text-black hover:underline">
            Увійти
          </router-link>
        </p>
      </form>
    </div>
  </section>
</template>

<style scoped>

</style>