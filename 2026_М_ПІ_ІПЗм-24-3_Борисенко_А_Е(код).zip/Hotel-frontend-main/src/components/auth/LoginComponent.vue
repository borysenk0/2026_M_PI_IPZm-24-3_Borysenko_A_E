<script setup lang="ts">
import { ref } from 'vue';
import { useForm } from 'vee-validate';
import { loginSchema } from '@/validation/auth.schema';
import { EyeIcon, EyeSlashIcon } from "@heroicons/vue/24/solid";
import { useAuthStore } from '@/stores/auth';
import { useRouter } from "vue-router";

// Налаштування форми з валідацією
const { errors, defineField, handleSubmit } = useForm({
  validationSchema: loginSchema,
});

const [email, emailProps] = defineField('email');
const [password, passwordProps] = defineField('password');

const passwordShown = ref(false);
const authStore = useAuthStore();
const router = useRouter();

const togglePasswordVisibility = () => {
  passwordShown.value = !passwordShown.value;
};

// handleSubmit автоматично перевірить валідацію перед викликом функції
const handleLogin = handleSubmit(async (values) => {
  const ok = await authStore.login(values.email, values.password);

  if (ok) {
    router.push({ name: 'home' });
  } else {
    alert("Невірний email або пароль!");
  }
});
</script>

<template>
  <section class="grid text-center h-screen items-center p-8 bg-white">
    <div>
      <h3 class="text-3xl font-bold text-blue-gray-900 mb-2">
        Увійти
      </h3>
      <p class="mb-16 text-gray-600 font-normal text-[18px]">
        Введіть свій email та пароль щоб увійти
      </p>

      <form @submit.prevent="handleLogin" class="mx-auto max-w-[24rem] text-left">
        <div class="mb-6">
          <label for="email" class="mb-2 block font-medium text-gray-900 text-sm">
            Ваш Email
          </label>
          <input
              id="email"
              v-model="email"
              v-bind="emailProps"
              type="email"
              placeholder="name@mail.com"
              :class="[
                'w-full p-3 border rounded-lg outline-none transition-all placeholder:opacity-100',
                errors.email ? 'border-red-500 focus:border-red-500' : 'border-blue-gray-200 focus:border-gray-900'
              ]"
          />
          <span class="text-red-500 text-xs mt-1 block h-4">{{ errors.email }}</span>
        </div>

        <div class="mb-6">
          <label for="password" class="mb-2 block font-medium text-gray-900 text-sm">
            Пароль
          </label>
          <div class="relative">
            <input
                id="password"
                v-model="password"
                v-bind="passwordProps"
                :type="passwordShown ? 'text' : 'password'"
                placeholder="********"
                :class="[
                  'w-full p-3 border rounded-lg outline-none transition-all placeholder:opacity-100',
                  errors.password ? 'border-red-500 focus:border-red-500' : 'border-blue-gray-200 focus:border-gray-900'
                ]"
            />
            <button
                type="button"
                @click="togglePasswordVisibility"
                class="absolute right-3 top-[18px] text-gray-600 cursor-pointer"
            >
              <EyeIcon v-if="passwordShown" class="h-5 w-5" />
              <EyeSlashIcon v-else class="h-5 w-5" />
            </button>
          </div>
          <span class="text-red-500 text-xs mt-1 block h-4">{{ errors.password }}</span>
        </div>

        <button
            type="submit"
            class="w-full bg-[#1a1a1a] text-white py-4 rounded-xl font-bold tracking-widest hover:bg-black transition-all uppercase text-sm shadow-md cursor-pointer disabled:opacity-50"
        >
          Увійти
        </button>

        <div class="mt-4 flex justify-end">
          <router-link :to="{ name: 'reset' }" class="text-sm font-medium text-blue-gray-900 hover:text-gray-700">
            Забули пароль
          </router-link>
        </div>

        <button
            type="button"
            class="w-full border border-blue-gray-200 text-gray-900 py-3 rounded-lg uppercase font-bold text-xs hover:bg-gray-50 transition-all mt-6 flex items-center justify-center gap-2 cursor-pointer"
        >
          <img
              src="https://www.material-tailwind.com/logos/logo-google.png"
              alt="google"
              class="h-6 w-6"
          />
          увійти через google
        </button>

        <p class="mt-4 text-center text-sm text-gray-600 font-normal">
          Не зареєстровані?
          <router-link :to="{ name: 'register' }" class="font-medium text-gray-900 hover:underline">
            Створити аккаунт
          </router-link>
        </p>
      </form>
    </div>
  </section>
</template>

<style scoped></style>