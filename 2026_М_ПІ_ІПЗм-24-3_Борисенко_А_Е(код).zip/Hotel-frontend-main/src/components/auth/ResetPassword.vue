<script setup lang="ts">
import { ref } from 'vue';
import { useForm } from 'vee-validate';
import { forgotPasswordSchema } from '@/validation/auth.schema';

const isSent = ref(false);

const { errors, defineField, handleSubmit } = useForm({
  validationSchema: forgotPasswordSchema,
});

const [email, emailProps] = defineField('email');

const handleReset = handleSubmit((values) => {
  console.log("Запит на відновлення для:", values.email);
  // Тут буде виклик вашого NestJS бекенда
  isSent.value = true;
});
</script>

<template>
  <section class="flex flex-col items-center justify-center min-h-screen bg-white p-4">
    <div class="w-full max-w-[400px]">

      <div class="bg-[#1a1a1a] text-white rounded-2xl p-8 text-center shadow-xl mb-10">
        <h2 class="text-3xl font-bold mb-4">Скинути пароль</h2>
        <p class="text-gray-300 text-sm">
          Ви отримаєте електронний лист протягом максимум 60 секунд
        </p>
      </div>

      <form @submit.prevent="handleReset" class="px-2">
        <div class="mb-8">
          <label for="email" class="mb-2 block font-medium text-gray-900 text-sm">
            Email
          </label>
          <input
              id="email"
              v-model="email"
              v-bind="emailProps"
              type="email"
              placeholder="john@example.com"
              :class="[
                'w-full p-3 border rounded-lg outline-none transition-all placeholder:opacity-100',
                errors.email ? 'border-red-500 focus:border-red-500' : 'border-blue-gray-200 focus:border-gray-900'
              ]"
          />
          <span class="text-red-500 text-xs mt-1 block h-4">{{ errors.email }}</span>
        </div>

        <button
            type="submit"
            class="w-full bg-[#1a1a1a] text-white py-4 rounded-xl font-bold tracking-widest hover:bg-black transition-all uppercase text-sm shadow-md cursor-pointer"
        >
          Відновити
        </button>

        <div class="mt-6 text-center">
          <router-link :to="{ name: 'login' }" class="text-gray-500 text-xs hover:text-black transition-colors">
            Назад до входу
          </router-link>
        </div>
      </form>

      <transition name="fade">
        <p v-if="isSent" class="mt-4 text-green-600 text-center text-sm font-medium">
          Перевірте свою поштову скриньку! Інструкція була надіслана.
        </p>
      </transition>
    </div>
  </section>
</template>

<style scoped>
input::placeholder {
  font-weight: 300;
}

/* Коротка анімація для повідомлення про успіх */
.fade-enter-active, .fade-leave-active {
  transition: opacity 0.5s ease;
}
.fade-enter-from, .fade-leave-to {
  opacity: 0;
}
</style>