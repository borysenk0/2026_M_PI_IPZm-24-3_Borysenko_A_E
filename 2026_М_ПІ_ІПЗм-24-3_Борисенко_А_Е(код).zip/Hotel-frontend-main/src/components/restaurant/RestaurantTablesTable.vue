<script setup lang="ts">
import { computed, ref } from 'vue';
import { useHotelStore } from '@/stores/hotel';
import { useNotification } from '@kyvg/vue3-notification';
import Modal from '@/components/ui/Modal.vue';

const hotel = useHotelStore();
const { notify } = useNotification();

const rows = computed(() =>
  hotel.state.tables.map((table) => {
    const restaurant = hotel.state.restaurants.find((r) => r.id === table.restaurant_id);
    return {
      id: table.id,
      number: table.number,
      status: table.status,
      restaurantName: restaurant?.name ?? '—',
    };
  }),
);

const filterNumber = ref('');
const filterStatus = ref('');

const filteredRows = computed(() => {
  return rows.value.filter(row => {
    if (filterNumber.value && !row.number.toString().includes(filterNumber.value)) return false;
    if (filterStatus.value && row.status !== filterStatus.value) return false;
    return true;
  });
});

const clearFilters = () => {
  filterNumber.value = '';
  filterStatus.value = '';
};

const translateStatus = (status: string) => {
  const map: Record<string, string> = {
    'AVAILABLE': 'Вільний',
    'RESERVED': 'Резерв',
    'OCCUPIED': 'Зайнятий'
  };
  return map[status] || status;
};

const statusPill = (status: string) => {
  if (status === 'AVAILABLE') return 'bg-emerald-50 text-emerald-700 border-emerald-200';
  if (status === 'RESERVED') return 'bg-amber-50 text-amber-800 border-amber-200';
  if (status === 'OCCUPIED') return 'bg-red-50 text-red-700 border-red-200';
  return 'bg-gray-50 text-gray-700 border-gray-200';
};

const isAddOpen = ref(false);
const form = ref({
  number: 1,
  restaurant_id: hotel.state.restaurants.length > 0 ? hotel.state.restaurants[0].id : null,
  status: 'AVAILABLE' as 'AVAILABLE' | 'RESERVED' | 'OCCUPIED',
});

import api from '@/api';

const handleAdd = async () => {
  if (!form.value.number || form.value.number <= 0) {
    notify({ type: 'error', title: 'Помилка', text: 'Введіть коректний номер столу' });
    return;
  }
  if (!form.value.restaurant_id) {
    notify({ type: 'error', title: 'Помилка', text: 'Виберіть ресторан' });
    return;
  }

  try {
    await api.post('/tables', {
      number: form.value.number,
      restaurant_id: form.value.restaurant_id,
      status: form.value.status,
    });
    
    await hotel.fetchAll();
    notify({ type: 'success', title: 'Успішно', text: 'Стіл успішно додано' });
    isAddOpen.value = false;
    form.value = {
      number: Math.max(0, ...hotel.state.tables.map(t => t.number)) + 1,
      restaurant_id: hotel.state.restaurants.length > 0 ? hotel.state.restaurants[0].id : null,
      status: 'AVAILABLE',
    };
  } catch(e) {
    notify({ type: 'error', title: 'Помилка', text: 'Не вдалося додати стіл' });
  }
};

const isEditOpen = ref(false);
const editForm = ref({
  id: 0,
  number: 1,
  restaurant_id: null as number | null,
  status: 'AVAILABLE' as 'AVAILABLE' | 'RESERVED' | 'OCCUPIED',
});

const openEdit = (row: any) => {
  const t = hotel.state.tables.find(t => t.id === row.id);
  if (t) {
    editForm.value = { ...t };
    isEditOpen.value = true;
  }
};

const handleEdit = async () => {
  if (!editForm.value.number || editForm.value.number <= 0) {
    notify({ type: 'error', title: 'Помилка', text: 'Введіть коректний номер столу' });
    return;
  }
  if (!editForm.value.restaurant_id) {
    notify({ type: 'error', title: 'Помилка', text: 'Виберіть ресторан' });
    return;
  }

  try {
    const payload = { ...editForm.value };
    const id = payload.id;
    delete payload.id;
    await api.put(`/tables/${id}`, payload);
    await hotel.fetchAll();
    notify({ type: 'success', title: 'Успішно', text: 'Стіл оновлено' });
    isEditOpen.value = false;
  } catch(e) {
    notify({ type: 'error', title: 'Помилка', text: 'Стіл не знайдено або помилка сервера' });
  }
};

const handleDelete = async (id: number) => {
  if (!confirm('Видалити стіл?')) return;
  try {
    await api.delete(`/tables/${id}`);
    await hotel.fetchAll();
    notify({ type: 'success', title: 'Успішно', text: 'Стіл видалено' });
  } catch(e) {
    notify({ type: 'error', title: 'Помилка', text: 'Помилка при видаленні' });
  }
};
</script>

<template>
  <div>
    <section class="space-y-4">
      <header class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div>
        <h2 class="text-lg font-bold text-gray-900">Столи ресторану</h2>
        <p class="text-sm text-gray-600">
          Контроль статусу столів у залі ресторану.
        </p>
      </div>
      <button 
        @click="isAddOpen = true"
        class="bg-black hover:bg-gray-800 text-white px-4 py-2 rounded-xl font-bold text-sm shadow-sm transition"
      >
        Додати стіл
      </button>
    </header>

    <!-- Filter Ribbon -->
    <div class="bg-gray-50 border border-gray-200 rounded-2xl p-4 flex flex-wrap gap-4 items-end">
      <div class="flex-1 min-w-[200px]">
        <label class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Пошук за Номером столу</label>
        <input v-model="filterNumber" type="text" placeholder="Номер..." class="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
      </div>
      <div class="w-48">
        <label class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Статус</label>
        <select v-model="filterStatus" class="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
          <option value="">Усі статуси</option>
          <option value="AVAILABLE">Вільний (AVAILABLE)</option>
          <option value="RESERVED">Резерв (RESERVED)</option>
          <option value="OCCUPIED">Зайнятий (OCCUPIED)</option>
        </select>
      </div>
      <button @click="clearFilters" v-if="filterNumber || filterStatus" class="px-4 py-2 border border-gray-300 rounded-xl bg-white text-sm font-semibold text-gray-700 hover:bg-gray-100 transition">
        Скинути
      </button>
    </div>

    <div class="bg-white border border-gray-200 rounded-2xl overflow-hidden">
      <table class="w-full text-left">
        <thead class="bg-gray-50 border-b border-gray-200">
          <tr class="text-xs uppercase tracking-wider text-gray-600">
            <th class="p-3">ID</th>
            <th class="p-3">№ столу</th>
            <th class="p-3">Ресторан</th>
            <th class="p-3">Статус</th>
            <th class="p-3 text-right">Дії</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="row in filteredRows"
            :key="row.id"
            class="border-b border-gray-100 hover:bg-gray-50"
          >
            <td class="p-3 text-sm text-gray-700">{{ row.id }}</td>
            <td class="p-3 font-semibold text-gray-900">Стол {{ row.number }}</td>
            <td class="p-3 text-sm text-gray-700">{{ row.restaurantName }}</td>
            <td class="p-3">
              <span
                class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border"
                :class="statusPill(row.status)"
              >
                {{ translateStatus(row.status) }}
              </span>
            </td>
            <td class="p-3 text-right">
              <div class="inline-flex gap-2">
                <button
                  type="button"
                  @click="openEdit(row)"
                  class="px-3 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-sm font-semibold"
                >
                  Редагувати
                </button>
                <button
                  type="button"
                  @click="handleDelete(row.id)"
                  class="px-3 py-2 rounded-lg border border-red-200 bg-white hover:bg-red-50 text-sm font-semibold text-red-700"
                >
                  Видалити
                </button>
              </div>
            </td>
          </tr>
          <tr v-if="filteredRows.length === 0">
            <td colspan="5" class="p-6 text-center text-sm text-gray-500">
              Столів не знайдено.
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <Modal :isOpen="isAddOpen" title="Додати стіл" @close="isAddOpen = false">
    <div class="space-y-4">
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1">Номер столу</label>
        <input v-model="form.number" type="number" min="1" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" placeholder="1" />
      </div>
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1">Ресторан</label>
        <select v-model="form.restaurant_id" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none bg-white">
          <option v-for="rest in hotel.state.restaurants" :key="rest.id" :value="rest.id">
            {{ rest.name }}
          </option>
        </select>
      </div>
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1">Статус</label>
        <select v-model="form.status" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none bg-white">
          <option value="AVAILABLE">Вільний (AVAILABLE)</option>
          <option value="RESERVED">Резерв (RESERVED)</option>
          <option value="OCCUPIED">Зайнятий (OCCUPIED)</option>
        </select>
      </div>
    </div>
    <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-gray-100">
      <button @click="isAddOpen = false" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-xl font-semibold transition">
        Скасувати
      </button>
      <button @click="handleAdd" class="px-6 py-2 bg-[#1a1a1a] hover:bg-black text-white rounded-xl font-bold shadow-sm transition">
        Зберегти
      </button>
    </div>
  </Modal>

  <Modal :isOpen="isEditOpen" title="Редагувати стіл" @close="isEditOpen = false">
    <div class="space-y-4">
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1">Номер столу</label>
        <input v-model="editForm.number" type="number" min="1" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" placeholder="1" />
      </div>
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1">Ресторан</label>
        <select v-model="editForm.restaurant_id" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none bg-white">
          <option v-for="rest in hotel.state.restaurants" :key="rest.id" :value="rest.id">
            {{ rest.name }}
          </option>
        </select>
      </div>
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1">Статус</label>
        <select v-model="editForm.status" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none bg-white">
          <option value="AVAILABLE">Вільний (AVAILABLE)</option>
          <option value="RESERVED">Резерв (RESERVED)</option>
          <option value="OCCUPIED">Зайнятий (OCCUPIED)</option>
        </select>
      </div>
    </div>
    <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-gray-100">
      <button @click="isEditOpen = false" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-xl font-semibold transition">
        Скасувати
      </button>
      <button @click="handleEdit" class="px-6 py-2 bg-[#1a1a1a] hover:bg-black text-white rounded-xl font-bold shadow-sm transition">
        Зберегти
      </button>
    </div>
  </Modal>
  </div>
</template>

