<script setup lang="ts">
import { ref, onMounted, computed } from 'vue';
import { useNotification } from '@kyvg/vue3-notification';
import Modal from '@/components/ui/Modal.vue';
import api from '@/api';

const { notify } = useNotification();
const rows = ref<any[]>([]);

const loadIngredients = async () => {
  try {
    const res = await api.get('/ingredients');
    rows.value = res.data.sort((a: any, b: any) => a.name.localeCompare(b.name));
  } catch (err) {
    console.error('Failed to load ingredients', err);
  }
};

onMounted(() => {
  loadIngredients();
});

const filterName = ref('');
const filterCritical = ref(false);

const filteredRows = computed(() => {
  return rows.value.filter(r => {
    if (filterName.value && !r.name.toLowerCase().includes(filterName.value.toLowerCase())) return false;
    if (filterCritical.value && Number(r.count) >= Number(r.min_threshold)) return false;
    return true;
  });
});

const clearFilters = () => {
  filterName.value = '';
  filterCritical.value = '';
};

const isAddOpen = ref(false);
const form = ref({
  name: '',
  unit: 'кг',
  count: 0,
  min_threshold: 0,
});

const handleAdd = async () => {
  if (!form.value.name.trim()) {
    notify({ type: 'error', title: 'Помилка', text: 'Введіть назву інгредієнта' });
    return;
  }
  
  try {
    await api.post('/ingredients', {
      name: form.value.name,
      unit: form.value.unit,
      count: form.value.count,
      min_threshold: form.value.min_threshold,
    });
    await loadIngredients();
    notify({ type: 'success', title: 'Успішно', text: 'Інгредієнт збережено' });
    isAddOpen.value = false;
    form.value = { name: '', unit: 'кг', count: 0, min_threshold: 0 };
  } catch (err) {
    notify({ type: 'error', title: 'Помилка', text: 'Не вдалося зберегти інгредієнт' });
  }
};

const isEditOpen = ref(false);
const editForm = ref({
  id: 0,
  name: '',
  unit: 'кг',
  count: 0,
  min_threshold: 0,
});

const openEdit = (item: any) => {
  editForm.value = { ...item };
  isEditOpen.value = true;
};

const handleEdit = async () => {
  if (!editForm.value.name.trim()) {
    notify({ type: 'error', title: 'Помилка', text: 'Введіть назву інгредієнта' });
    return;
  }
  
  try {
    const payload = { ...editForm.value };
    const id = payload.id;
    delete payload.id;
    await api.put(`/ingredients/${id}`, payload);
    await loadIngredients();
    notify({ type: 'success', title: 'Успішно', text: 'Інгредієнт оновлено' });
    isEditOpen.value = false;
  } catch (err) {
    notify({ type: 'error', title: 'Помилка', text: 'Не вдалося оновити інгредієнт' });
  }
};

const handleDelete = async (id: number) => {
  if (!confirm('Ви впевнені, що хочете видалити цей інгредієнт?')) return;
  try {
    await api.delete(`/ingredients/${id}`);
    await loadIngredients();
    notify({ type: 'success', title: 'Успішно', text: 'Інгредієнт видалено' });
  } catch (err) {
    notify({ type: 'error', title: 'Помилка', text: 'Не вдалося видалити інгредієнт' });
  }
};
</script>

<template>
  <div>
    <section class="space-y-4">
      <header class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div>
        <h2 class="text-lg font-bold text-gray-900">Склад (інгредієнти)</h2>
        <p class="text-sm text-gray-600">
          Рядки з кількістю нижче порогу <span class="font-semibold">min_threshold</span> підсвічуються іншим кольором.
        </p>
      </div>
      <button 
        @click="isAddOpen = true"
        class="bg-black hover:bg-gray-800 text-white px-4 py-2 rounded-xl font-bold text-sm shadow-sm transition"
      >
        Додати інгредієнт
      </button>
    </header>

    <!-- Filter Ribbon -->
    <div class="bg-gray-50 border border-gray-200 rounded-2xl p-4 flex flex-wrap gap-4 items-end">
      <div class="flex-1 max-w-sm">
        <label class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Пошук за назвою</label>
        <input v-model="filterName" type="text" placeholder="Томати..." class="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
      </div>
      <div class="flex items-center gap-2 h-10 px-2">
        <input v-model="filterCritical" type="checkbox" id="criticalFilter" class="w-4 h-4 text-red-600 bg-gray-100 border-gray-300 rounded focus:ring-red-500" />
        <label for="criticalFilter" class="text-sm font-bold text-gray-700 select-none cursor-pointer">Показати лише критичні залишки</label>
      </div>
      <button @click="clearFilters" v-if="filterName || filterCritical" class="px-4 py-2 border border-gray-300 rounded-xl bg-white text-sm font-semibold text-gray-700 hover:bg-gray-100 transition">
        Скинути
      </button>
    </div>

    <div class="bg-white border border-gray-200 rounded-2xl overflow-hidden">
      <table class="w-full text-left">
        <thead class="bg-gray-50 border-b border-gray-200">
          <tr class="text-xs uppercase tracking-wider text-gray-600">
            <th class="p-3">Інгредієнт</th>
            <th class="p-3">Од. виміру</th>
            <th class="p-3">Кількість</th>
            <th class="p-3">Мін. поріг</th>
            <th class="p-3 text-right">Дії</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="item in filteredRows"
            :key="item.id"
            class="border-b border-gray-100 hover:bg-gray-50"
            :class="Number(item.count) < Number(item.min_threshold) ? 'bg-red-50' : ''"
          >
            <td class="p-3 font-semibold text-gray-900">{{ item.name }}</td>
            <td class="p-3 text-sm text-gray-700">{{ item.unit }}</td>
            <td class="p-3 text-sm">
              <span :class="Number(item.count) < Number(item.min_threshold) ? 'text-red-700 font-semibold' : 'text-gray-800'">
                {{ item.count }}
              </span>
            </td>
            <td class="p-3 text-sm text-gray-700">{{ item.min_threshold }}</td>
            <td class="p-3 text-right">
              <div class="inline-flex gap-2">
                <button
                  type="button"
                  @click="openEdit(item)"
                  class="px-3 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-sm font-semibold"
                >
                  Редагувати
                </button>
                <button
                  type="button"
                  @click="handleDelete(item.id)"
                  class="px-3 py-2 rounded-lg border border-red-200 bg-white hover:bg-red-50 text-sm font-semibold text-red-700"
                >
                  Видалити
                </button>
              </div>
            </td>
          </tr>
          <tr v-if="filteredRows.length === 0">
            <td colspan="5" class="p-6 text-center text-sm text-gray-500">
              Інгредієнтів не знайдено.
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <Modal :isOpen="isAddOpen" title="Додати інгредієнт" @close="isAddOpen = false">
    <div class="space-y-4">
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1">Назва</label>
        <input v-model="form.name" type="text" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" placeholder="Томати" />
      </div>
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Од. виміру</label>
          <input v-model="form.unit" type="text" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" placeholder="кг" />
        </div>
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Кількість</label>
          <input v-model="form.count" type="number" step="0.1" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" />
        </div>
      </div>
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1">Мін. поріг</label>
        <input v-model="form.min_threshold" type="number" step="0.1" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" />
      </div>
    </div>
    <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-gray-100">
      <button @click="isAddOpen = false" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-xl font-semibold transition">
        Скасувати
      </button>
      <button @click="handleAdd" class="px-6 py-2 bg-[#1a1a1a] hover:bg-black text-white rounded-xl font-bold shadow-sm transition">
        Зберегти
      </button>
    </div>
  </Modal>

  <Modal :isOpen="isEditOpen" title="Редагувати інгредієнт" @close="isEditOpen = false">
    <div class="space-y-4">
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1">Назва</label>
        <input v-model="editForm.name" type="text" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" placeholder="Томати" />
      </div>
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Од. виміру</label>
          <input v-model="editForm.unit" type="text" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" placeholder="кг" />
        </div>
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Кількість</label>
          <input v-model="editForm.count" type="number" step="0.1" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" />
        </div>
      </div>
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1">Мін. поріг</label>
        <input v-model="editForm.min_threshold" type="number" step="0.1" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" />
      </div>
    </div>
    <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-gray-100">
      <button @click="isEditOpen = false" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-xl font-semibold transition">
        Скасувати
      </button>
      <button @click="handleEdit" class="px-6 py-2 bg-[#1a1a1a] hover:bg-black text-white rounded-xl font-bold shadow-sm transition">
        Зберегти
      </button>
    </div>
  </Modal>
  </div>
</template>

