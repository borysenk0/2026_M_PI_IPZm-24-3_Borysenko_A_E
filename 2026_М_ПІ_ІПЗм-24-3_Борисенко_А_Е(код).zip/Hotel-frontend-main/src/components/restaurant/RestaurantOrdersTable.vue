<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from 'vue';
import { useHotelStore } from '@/stores/hotel';
import api from '@/api';
import { useNotification } from '@kyvg/vue3-notification';
import Modal from '@/components/ui/Modal.vue';

const hotel = useHotelStore();
const { notify } = useNotification();

let poller: any;
onMounted(() => {
  hotel.fetchAll();
  poller = setInterval(() => {
    hotel.fetchAll();
  }, 5000);
});

onUnmounted(() => {
  clearInterval(poller);
});

const rows = computed(() => {
  return hotel.residentOrdersForManager.map((order) => {
    const user = hotel.state.users.find((u) => u.id === order.user_id);
    const booking = hotel.state.bookings.find((b) => b.id === order.booking_id);
    const room = booking ? hotel.state.rooms.find((r) => r.id === booking.room_id) : null;
    return {
      id: order.id,
      guestName: user?.full_name ?? '—',
      roomNumber: room?.number ?? null,
      status: order.status,
      totalPrice: order.total_price,
      createdAt: new Date(order.created_at).toLocaleTimeString(),
      createdDate: new Date(order.created_at).toISOString().split('T')[0],
      estimatedPrep: order.estimated_prep_minutes,
      dishes: order.orderDishes || [],
    };
  }).sort((a, b) => b.id - a.id);
});

// Фільтрація
const filterGuest = ref('');
const filterRoom = ref('');
const filterStatus = ref('');
const filterDate = ref('');

const uniqueRooms = computed(() => {
  const rooms = new Set(rows.value.map(r => r.roomNumber).filter(Boolean));
  return Array.from(rooms) as number[];
});

const filteredRows = computed(() => {
  return rows.value.filter(row => {
    if (filterGuest.value && !row.guestName.toLowerCase().includes(filterGuest.value.toLowerCase())) return false;
    if (filterRoom.value && row.roomNumber?.toString() !== filterRoom.value) return false;
    if (filterStatus.value && row.status !== filterStatus.value) return false;
    if (filterDate.value && row.createdDate !== filterDate.value) return false;
    return true;
  });
});

const clearFilters = () => {
  filterGuest.value = '';
  filterRoom.value = '';
  filterStatus.value = '';
  filterDate.value = '';
};



const updateStatus = async (id: number, status: string) => {
  try {
    await api.patch(`/orders/${id}/status`, { status });
    await hotel.fetchAll();
    notify({ type: 'success', title: 'Успішно', text: 'Статус замовлення оновлено' });
  } catch(e) {
    notify({ type: 'error', title: 'Помилка', text: 'Не вдалося оновити статус' });
  }
};

const addTime = async (id: number) => {
  try {
    await api.patch(`/orders/${id}/time`, { minutes: 5 });
    await hotel.fetchAll();
    notify({ type: 'success', title: 'Успішно', text: 'Додано 5 хвилин' });
  } catch(e) {
    notify({ type: 'error', title: 'Помилка', text: 'Не вдалося додати час' });
  }
};

const statusPill = (status: string) => {
  if (status === 'NEW') return 'bg-slate-100 text-slate-800 border-slate-200';
  if (status === 'COOKING' || status === 'IN_PROGRESS') return 'bg-amber-100 text-amber-800 border-amber-200';
  if (status === 'READY') return 'bg-emerald-100 text-emerald-800 border-emerald-200';
  if (status === 'SERVED') return 'bg-gray-100 text-gray-700 border-gray-200';
  if (status === 'CANCELLED') return 'bg-red-100 text-red-700 border-red-200';
  return 'bg-slate-100 text-slate-800 border-slate-200';
};

const isInfoOpen = ref(false);
const selectedOrderInfo = ref<any>(null);

const openInfo = (row: any) => {
  selectedOrderInfo.value = row;
  isInfoOpen.value = true;
};
</script>

<template>
  <section class="space-y-4">
    <header class="flex flex-col sm:flex-row justify-between items-start gap-4 mb-4">
      <div>
        <h2 class="text-lg font-bold text-gray-900">Замовлення гостей (мешканці)</h2>
        <p class="text-sm text-gray-600">
          У таблиці показані активні та історичні замовлення, привʼязані до номерів.
        </p>
      </div>
    </header>

    <!-- Filter Ribbon -->
    <div class="bg-gray-50 border border-gray-200 rounded-2xl p-4 flex flex-wrap gap-4 items-end">
      <div class="flex-1 min-w-[200px]">
        <label class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Пошук за Гостем</label>
        <input v-model="filterGuest" type="text" placeholder="Ім'я гостя..." class="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
      </div>
      <div class="w-32">
        <label class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Номер</label>
        <select v-model="filterRoom" class="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
          <option value="">Усі</option>
          <option v-for="r in uniqueRooms" :key="r" :value="r.toString()">№ {{ r }}</option>
        </select>
      </div>
      <div class="w-40">
        <label class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Статус</label>
        <select v-model="filterStatus" class="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
          <option value="">Усі</option>
          <option value="NEW">Нове</option>
          <option value="COOKING">Готується</option>
          <option value="IN_PROGRESS">В роботі</option>
          <option value="READY">Готово</option>
          <option value="SERVED">Доставлено</option>
          <option value="CANCELLED">Скасовано</option>
        </select>
      </div>
      <div class="w-40">
        <label class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Дата</label>
        <input v-model="filterDate" type="date" class="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
      </div>
      <button @click="clearFilters" v-if="filterGuest || filterRoom || filterStatus || filterDate" class="px-4 py-2 border border-gray-300 rounded-xl bg-white text-sm font-semibold text-gray-700 hover:bg-gray-100 transition">
        Скинути
      </button>
    </div>

    <div class="bg-white border border-gray-200 rounded-2xl overflow-hidden">
      <table class="w-full text-left">
        <thead class="bg-gray-50 border-b border-gray-200">
          <tr class="text-xs uppercase tracking-wider text-gray-600">
            <th class="p-3">№ замовлення</th>
            <th class="p-3">Гість</th>
            <th class="p-3">Номер</th>
            <th class="p-3">Статус</th>
            <th class="p-3">Час (ETA)</th>
            <th class="p-3">Сума</th>
            <th class="p-3">Створено</th>
            <th class="p-3 text-right">Дії</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="row in filteredRows"
            :key="row.id"
            class="border-b border-gray-100 hover:bg-gray-50"
          >
            <td class="p-3 font-semibold text-gray-900">#{{ row.id }}</td>
            <td class="p-3 text-sm text-gray-800">{{ row.guestName }}</td>
            <td class="p-3 text-sm text-gray-700">
              <span v-if="row.roomNumber">№ {{ row.roomNumber }}</span>
              <span v-else class="text-gray-400">—</span>
            </td>
            <td class="p-3">
              <span
                class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border"
                :class="statusPill(row.status)"
              >
                {{ row.status }}
              </span>
            </td>
            <td class="p-3 text-sm text-gray-800 font-semibold">{{ row.estimatedPrep }} хв</td>
            <td class="p-3 text-sm text-gray-800">{{ row.totalPrice }} ₴</td>
            <td class="p-3 text-sm text-gray-500">{{ row.createdAt }}</td>
            <td class="p-3 text-right">
              <div class="inline-flex gap-2">
                <button
                  v-if="row.status === 'NEW'"
                  @click="updateStatus(row.id, 'COOKING')"
                  type="button"
                  class="px-3 py-2 rounded-lg border border-amber-200 bg-amber-50 hover:bg-amber-100 text-sm font-bold text-amber-700 transition"
                >
                  Готувати
                </button>
                <button
                  v-if="row.status === 'COOKING' || row.status === 'IN_PROGRESS'"
                  @click="updateStatus(row.id, 'READY')"
                  type="button"
                  class="px-3 py-2 rounded-lg border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-sm font-bold text-emerald-700 transition"
                >
                  Готово
                </button>
                <button
                  v-if="row.status === 'READY'"
                  @click="updateStatus(row.id, 'SERVED')"
                  type="button"
                  class="px-3 py-2 rounded-lg border border-indigo-200 bg-indigo-50 hover:bg-indigo-100 text-sm font-bold text-indigo-700 transition"
                >
                  Відправити в номер
                </button>
                <button
                  v-if="row.status === 'COOKING' || row.status === 'IN_PROGRESS'"
                  @click="addTime(row.id)"
                  type="button"
                  class="px-3 py-2 rounded-lg border border-blue-200 bg-blue-50 hover:bg-blue-100 text-sm font-bold text-blue-700 transition"
                  title="Додати 5 хв до орієнтовного часу"
                >
                  +5 хв
                </button>
                <button
                  type="button"
                  @click="openInfo(row)"
                  class="px-3 py-2 rounded-lg border border-gray-200 bg-gray-50 hover:bg-gray-100 text-sm font-semibold text-gray-800 transition"
                  title="Деталі замовлення"
                >
                  Інфо
                </button>
                <button
                  type="button"
                  v-if="!['READY', 'SERVED', 'CANCELLED'].includes(row.status)"
                  @click="updateStatus(row.id, 'CANCELLED')"
                  class="px-3 py-2 rounded-lg border border-red-200 bg-white hover:bg-red-50 text-sm font-semibold text-red-700 transition"
                >
                  Скасувати
                </button>
                <button
                  type="button"
                  v-if="row.status === 'CANCELLED'"
                  @click="updateStatus(row.id, 'NEW')"
                  class="px-3 py-2 rounded-lg border border-slate-300 bg-slate-800 hover:bg-slate-900 text-white text-sm font-semibold transition"
                >
                  Відновити
                </button>
              </div>
            </td>
          </tr>
          <tr v-if="filteredRows.length === 0">
            <td colspan="8" class="p-8 text-center text-sm text-gray-500 bg-gray-50/50">
              <div class="flex flex-col items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Немає активних замовлень мешканців.
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <Modal :isOpen="isInfoOpen" title="Деталі Замовлення" @close="isInfoOpen = false">
    <div v-if="selectedOrderInfo" class="space-y-4">
      <div class="flex justify-between items-center border-b border-gray-100 pb-3">
        <div>
          <h3 class="font-bold text-gray-900">Замовлення #{{ selectedOrderInfo.id }}</h3>
          <p class="text-sm text-gray-600 mt-1">Гість: <span class="font-semibold">{{ selectedOrderInfo.guestName }}</span> (Номер {{ selectedOrderInfo.roomNumber || '—' }})</p>
        </div>
        <span
          class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border"
          :class="statusPill(selectedOrderInfo.status)"
        >
          {{ selectedOrderInfo.status }}
        </span>
      </div>

      <div>
        <h4 class="text-sm font-bold text-gray-800 mb-2 uppercase tracking-wide">Список страв:</h4>
        <ul v-if="selectedOrderInfo.dishes && selectedOrderInfo.dishes.length > 0" class="space-y-2 max-h-60 overflow-y-auto">
          <li v-for="od in selectedOrderInfo.dishes" :key="od.id" class="flex justify-between items-center p-3 rounded-xl bg-gray-50 border border-gray-100">
            <div>
              <span class="font-semibold text-gray-900">{{ od.dish?.name }}</span>
            </div>
            <div class="text-sm font-bold text-gray-700">
              {{ od.quantity }} порц.
            </div>
          </li>
        </ul>
        <p v-else class="text-sm text-gray-500 italic">Склад страв відсутній або не завантажився.</p>
      </div>

      <div class="pt-4 border-t border-gray-100 flex justify-between items-center text-sm">
        <div class="text-gray-500">
          Створено: {{ selectedOrderInfo.createdAt }}
        </div>
        <div class="text-lg text-gray-900">
          Сума: <span class="font-black">{{ selectedOrderInfo.totalPrice }} ₴</span>
        </div>
      </div>
    </div>
    
    <div class="mt-6 pt-4 border-t border-gray-100 flex justify-end">
      <button @click="isInfoOpen = false" class="px-5 py-2 bg-gray-900 hover:bg-black text-white rounded-xl font-bold transition">
        Закрити
      </button>
    </div>
  </Modal>
</template>

