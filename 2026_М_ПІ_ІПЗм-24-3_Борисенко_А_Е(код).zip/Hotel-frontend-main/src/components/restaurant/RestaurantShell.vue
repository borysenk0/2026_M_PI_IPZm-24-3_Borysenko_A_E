<script setup lang="ts">
import Sidebar, { type SidebarItem } from '@/components/admin/Sidebar.vue';

const sidebarItems: SidebarItem[] = [
  { label: 'Замовлення', toName: 'restaurant-orders', permissions: ['manager', 'admin'] },
  { label: 'Столи', toName: 'restaurant-tables', permissions: ['manager', 'admin'] },
  { label: 'Склад', toName: 'restaurant-inventory', permissions: ['manager', 'admin'] },
  { label: 'Меню', toName: 'restaurant-menu', permissions: ['manager', 'admin'] },
];
</script>

<template>
  <main class="max-w-7xl mx-auto px-4 sm:px-6 py-8">
    <header class="mb-6">
      <h1 class="text-2xl font-bold text-gray-900">Моніторинг ресторану</h1>
      <p class="text-sm text-gray-600">
        Замовлення гостей, статус столів, склад та меню в єдиній панелі.
      </p>
    </header>

    <section class="flex flex-col lg:flex-row gap-6">
      <Sidebar :items="sidebarItems" />
      <div class="grow">
        <RouterView />
      </div>
    </section>
  </main>
</template>

