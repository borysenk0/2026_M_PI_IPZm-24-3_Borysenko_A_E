<script setup lang="ts">
import { computed, ref } from 'vue';
import { useHotelStore } from '@/stores/hotel';
import { useNotification } from '@kyvg/vue3-notification';
import Modal from '@/components/ui/Modal.vue';
import api from '@/api';

const hotel = useHotelStore();
const { notify } = useNotification();

const rows = computed(() =>
  [...hotel.state.dishes].map((dish) => ({
    id: dish.id,
    name: dish.name,
    cost: dish.cost,
  })),
);

const filterName = ref('');

const filteredRows = computed(() => {
  return rows.value.filter(r => {
    if (filterName.value && !r.name.toLowerCase().includes(filterName.value.toLowerCase())) return false;
    return true;
  });
});

const clearFilters = () => {
  filterName.value = '';
};

const isAddOpen = ref(false);
const form = ref({
  name: '',
  cost: 0,
});
const selectedIngredients = ref<{id: number, quantity: number}[]>([]);

const addIngredientRow = () => {
  if (hotel.state.ingredients.length > 0) {
    selectedIngredients.value.push({ id: hotel.state.ingredients[0].id, quantity: 1 });
  } else {
    notify({ type: 'error', title: 'Помилка', text: 'Немає доступних інгредієнтів на складі' });
  }
};
const removeIngredientRow = (index: number) => {
  selectedIngredients.value.splice(index, 1);
};

const handleAdd = async () => {
  if (!form.value.name.trim()) {
    notify({ type: 'error', title: 'Помилка', text: 'Введіть назву страви' });
    return;
  }
  if (form.value.cost <= 0) {
    notify({ type: 'error', title: 'Помилка', text: 'Введіть коректну вартість' });
    return;
  }

  const payload = {
    name: form.value.name,
    cost: form.value.cost,
    dishIngredients: selectedIngredients.value.map(ing => ({
      ingredient_id: ing.id,
      quantity_required: ing.quantity
    }))
  };

  try {
    await api.post('/menu', payload);
    await hotel.fetchAll();
    notify({ type: 'success', title: 'Успішно', text: 'Страву успішно додано' });
    isAddOpen.value = false;
    form.value = { name: '', cost: 0 };
    selectedIngredients.value = [];
  } catch(e) {
    notify({ type: 'error', title: 'Помилка', text: 'Помилка при додаванні страви' });
  }
};

const isEditOpen = ref(false);
const editForm = ref({
  id: 0,
  name: '',
  cost: 0,
});

const openEdit = (row: any) => {
  editForm.value = { id: row.id, name: row.name, cost: row.cost };
  const d = hotel.state.dishes.find(d => d.id === row.id);
  selectedIngredients.value = (d?.dishIngredients || []).map((di: any) => ({
    id: di.ingredient_id,
    quantity: di.quantity_required,
  }));
  isEditOpen.value = true;
};

const handleEdit = async () => {
  if (!editForm.value.name.trim()) {
    notify({ type: 'error', title: 'Помилка', text: 'Введіть назву страви' });
    return;
  }
  if (editForm.value.cost <= 0) {
    notify({ type: 'error', title: 'Помилка', text: 'Введіть коректну вартість' });
    return;
  }

  const payload = {
    name: editForm.value.name,
    cost: editForm.value.cost,
    dishIngredients: selectedIngredients.value.map(ing => ({
      ingredient_id: ing.id,
      quantity_required: ing.quantity
    }))
  };

  try {
    await api.put(`/menu/${editForm.value.id}`, payload);
    await hotel.fetchAll();
    notify({ type: 'success', title: 'Успішно', text: 'Страву оновлено' });
    isEditOpen.value = false;
    selectedIngredients.value = [];
  } catch(e) {
    notify({ type: 'error', title: 'Помилка', text: 'Страву не знайдено або помилка сервера' });
  }
};

const handleDelete = async (id: number) => {
  if (!confirm('Видалити страву?')) return;
  try {
    await api.delete(`/menu/${id}`);
    await hotel.fetchAll();
    notify({ type: 'success', title: 'Успішно', text: 'Страву видалено' });
  } catch(e) {
    notify({ type: 'error', title: 'Помилка', text: 'Помилка при видаленні' });
  }
};
</script>

<template>
  <div>
    <section class="space-y-4">
      <header class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div>
        <h2 class="text-lg font-bold text-gray-900">Меню ресторану</h2>
        <p class="text-sm text-gray-600">
          Список страв, які використовуються в замовленнях гостей.
        </p>
      </div>
      <button 
        @click="isAddOpen = true"
        class="bg-black hover:bg-gray-800 text-white px-4 py-2 rounded-xl font-bold text-sm shadow-sm transition"
      >
        Додати страву
      </button>
    </header>

    <!-- Filter Ribbon -->
    <div class="bg-gray-50 border border-gray-200 rounded-2xl p-4 flex flex-wrap gap-4 items-end">
      <div class="flex-1 max-w-sm">
        <label class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Пошук за Назвою</label>
        <input v-model="filterName" type="text" placeholder="Борщ..." class="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
      </div>
      <button @click="clearFilters" v-if="filterName" class="px-4 py-2 border border-gray-300 rounded-xl bg-white text-sm font-semibold text-gray-700 hover:bg-gray-100 transition">
        Скинути
      </button>
    </div>

    <div class="bg-white border border-gray-200 rounded-2xl overflow-hidden">
      <table class="w-full text-left">
        <thead class="bg-gray-50 border-b border-gray-200">
          <tr class="text-xs uppercase tracking-wider text-gray-600">
            <th class="p-3">ID</th>
            <th class="p-3">Назва страви</th>
            <th class="p-3">Вартість</th>
            <th class="p-3 text-right">Дії</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="row in filteredRows"
            :key="row.id"
            class="border-b border-gray-100 hover:bg-gray-50"
          >
            <td class="p-3 text-sm text-gray-700">{{ row.id }}</td>
            <td class="p-3 font-semibold text-gray-900">{{ row.name }}</td>
            <td class="p-3 text-sm text-gray-800">{{ row.cost }} ₴</td>
            <td class="p-3 text-right">
              <div class="inline-flex gap-2">
                <button
                  type="button"
                  @click="openEdit(row)"
                  class="px-3 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-sm font-semibold"
                >
                  Редагувати
                </button>
                <button
                  type="button"
                  @click="handleDelete(row.id)"
                  class="px-3 py-2 rounded-lg border border-red-200 bg-white hover:bg-red-50 text-sm font-semibold text-red-700"
                >
                  Видалити
                </button>
              </div>
            </td>
          </tr>
          <tr v-if="filteredRows.length === 0">
            <td colspan="4" class="p-6 text-center text-sm text-gray-500">
              Страви не знайдені.
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <Modal :isOpen="isAddOpen" title="Додати страву" @close="isAddOpen = false">
    <div class="space-y-6">
      <div class="space-y-4">
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Назва страви</label>
          <input v-model="form.name" type="text" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" placeholder="Борщ" />
        </div>
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Вартість (₴)</label>
          <input v-model="form.cost" type="number" step="1" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" />
        </div>
      </div>

      <div class="border-t border-gray-200 pt-4">
        <div class="flex items-center justify-between mb-2">
          <label class="block text-sm font-semibold text-gray-700">Інгредієнти</label>
          <button @click="addIngredientRow" class="text-sm text-blue-600 font-semibold hover:underline border border-transparent px-2 py-1 rounded-md">
            + Додати інгредієнт
          </button>
        </div>
        
        <div class="space-y-3">
          <div v-for="(ing, idx) in selectedIngredients" :key="idx" class="flex items-center gap-3">
            <select v-model="ing.id" class="flex-1 px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none bg-white">
              <option v-for="dbIng in hotel.state.ingredients" :key="dbIng.id" :value="dbIng.id">
                {{ dbIng.name }} ({{ dbIng.unit }})
              </option>
            </select>
            <input v-model="ing.quantity" type="number" step="0.1" class="w-24 px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" placeholder="К-ть" />
            <button @click="removeIngredientRow(idx)" class="text-red-500 hover:text-red-700 p-2 border border-gray-200 rounded-xl hover:bg-gray-50">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            </button>
          </div>
          <p v-if="selectedIngredients.length === 0" class="text-xs text-gray-500 text-center py-2 bg-gray-50 rounded-lg">
            Страві не призначено інгредієнтів.
          </p>
        </div>
      </div>
    </div>
    <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-gray-100">
      <button @click="isAddOpen = false" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-xl font-semibold transition">
        Скасувати
      </button>
      <button @click="handleAdd" class="px-6 py-2 bg-[#1a1a1a] hover:bg-black text-white rounded-xl font-bold shadow-sm transition">
        Зберегти
      </button>
    </div>
  </Modal>

  <Modal :isOpen="isEditOpen" title="Редагувати страву" @close="isEditOpen = false">
    <div class="space-y-6">
      <div class="space-y-4">
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Назва страви</label>
          <input v-model="editForm.name" type="text" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" placeholder="Борщ" />
        </div>
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Вартість (₴)</label>
          <input v-model="editForm.cost" type="number" step="1" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" />
        </div>
      </div>

      <div class="border-t border-gray-200 pt-4">
        <div class="flex items-center justify-between mb-2">
          <label class="block text-sm font-semibold text-gray-700">Інгредієнти</label>
          <button @click="addIngredientRow" class="text-sm text-blue-600 font-semibold hover:underline border border-transparent px-2 py-1 rounded-md">
            + Додати інгредієнт
          </button>
        </div>
        
        <div class="space-y-3">
          <div v-for="(ing, idx) in selectedIngredients" :key="idx" class="flex items-center gap-3">
            <select v-model="ing.id" class="flex-1 px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none bg-white">
              <option v-for="dbIng in hotel.state.ingredients" :key="dbIng.id" :value="dbIng.id">
                {{ dbIng.name }} ({{ dbIng.unit }})
              </option>
            </select>
            <input v-model="ing.quantity" type="number" step="0.1" class="w-24 px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" placeholder="К-ть" />
            <button @click="removeIngredientRow(idx)" class="text-red-500 hover:text-red-700 p-2 border border-gray-200 rounded-xl hover:bg-gray-50">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            </button>
          </div>
          <p v-if="selectedIngredients.length === 0" class="text-xs text-gray-500 text-center py-2 bg-gray-50 rounded-lg">
            Страві не призначено інгредієнтів.
          </p>
        </div>
      </div>
    </div>
    <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-gray-100">
      <button @click="isEditOpen = false" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-xl font-semibold transition">
        Скасувати
      </button>
      <button @click="handleEdit" class="px-6 py-2 bg-[#1a1a1a] hover:bg-black text-white rounded-xl font-bold shadow-sm transition">
        Зберегти
      </button>
    </div>
  </Modal>
  </div>
</template>

