<script setup lang="ts">
import { computed } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '@/stores/auth';
import { useHotelStore } from '@/stores/hotel';
import logoUrl from '@/assets/pictures/logo.jpg';

const router = useRouter();
const authStore = useAuthStore();
const hotelStore = useHotelStore();

const goToHome = () => router.push({ name: 'home' });

const handleLogout = () => {
  authStore.logout();
  router.push({ name: 'login' });
};

type NavItem =
  | { kind: 'route'; label: string; toName: string }
  | { kind: 'action'; label: string; onClick: () => void };

const goLogin = () => router.push({ name: 'login' });

const navItems = computed<NavItem[]>(() => {
  const role = authStore.role;
  const isSettled = hotelStore.isSettled;

  const base: NavItem[] = [
    { kind: 'route', label: 'Техпідтримка', toName: 'support' },
  ];

  // неавторизований гість: тільки техпідтримка + бронювання → login
  if (!authStore.isLoggedIn || role === 'guest') {
    return [
      ...base,
      { kind: 'action', label: 'Бронювання', onClick: goLogin },
    ];
  }

  // звичайний користувач
  if (role === 'user') {
    if (isSettled) {
      return [
        ...base,
        { kind: 'route', label: 'Наш ресторан', toName: 'guest-menu' },
        { kind: 'route', label: 'Інформація номеру', toName: 'room-info' },
      ];
    }

    return [
      ...base,
      { kind: 'route', label: 'Бронювання', toName: 'booking' },
    ];
  }

  // менеджер ресторану
  if (role === 'manager') {
    return [
      ...base,
      { kind: 'route', label: 'Моніторинг ресторану', toName: 'kds-board' },
    ];
  }

  // глобальний адмін
  if (role === 'admin') {
    return [
      ...base,
      { kind: 'route', label: 'Адмін панель', toName: 'admin-dashboard' },
    ];
  }

  return base;
});
</script>

<template>
  <header class="fixed top-0 left-0 w-full bg-white/80 backdrop-blur-md z-50 border-b border-gray-100 px-6 py-3">
    <div class="max-w-7xl mx-auto flex items-center justify-between">

      <div @click="goToHome" class="flex items-center gap-2 cursor-pointer transition-transform hover:scale-105">
        <img :src="logoUrl" alt="Logo" class="h-10 w-auto rounded-md" />
        <span class="font-bold text-xl tracking-tight text-gray-900">Atlantic Grand Hotel</span>
      </div>

      <nav class="hidden md:flex items-center gap-6">
        <template v-for="(item, idx) in navItems" :key="idx">
          <router-link
            v-if="item.kind === 'route'"
            :to="{ name: item.toName }"
            class="text-sm font-semibold text-gray-700 hover:text-black transition-colors"
          >
            {{ item.label }}
          </router-link>
          <button
            v-else
            type="button"
            @click="item.onClick"
            class="text-sm font-semibold text-gray-700 hover:text-black transition-colors"
          >
            {{ item.label }}
          </button>
        </template>
      </nav>

      <div class="flex items-center gap-4">

        <template v-if="!authStore.isLoggedIn">
          <router-link :to="{ name: 'login' }" class="text-sm font-semibold text-gray-700 hover:text-black">
            Увійти
          </router-link>
          <router-link :to="{ name: 'register' }" class="bg-black text-white px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-gray-800 transition-all shadow-sm">
            Реєстрація
          </router-link>
        </template>

        <div v-else class="flex items-center gap-4">
          <div class="flex flex-col items-end">
            <span class="text-sm font-bold text-gray-900">{{ authStore.getUserName }}</span>
            <span class="text-[10px] uppercase tracking-widest text-gray-500">
              {{ authStore.role }}
            </span>
            <button @click="handleLogout" class="text-[10px] uppercase tracking-widest text-red-500 hover:underline cursor-pointer">
              Вийти
            </button>
          </div>
          <div class="h-10 w-10 bg-gray-200 rounded-full flex items-center justify-center border border-gray-300">
            <span class="text-gray-600 font-bold">{{ authStore.user?.name?.charAt(0) || 'U' }}</span>
          </div>
        </div>

      </div>
    </div>
  </header>
  <div class="h-16"></div>
</template>