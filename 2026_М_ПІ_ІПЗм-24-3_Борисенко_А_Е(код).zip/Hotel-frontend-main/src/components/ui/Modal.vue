<script setup lang="ts">
import { onMounted, onUnmounted } from 'vue';

const props = defineProps<{
  isOpen: boolean;
  title: string;
}>();

const emit = defineEmits<{
  (e: 'close'): void;
}>();

const close = () => {
  emit('close');
};

const handleKeydown = (e: KeyboardEvent) => {
  if (e.key === 'Escape' && props.isOpen) {
    close();
  }
};

onMounted(() => document.addEventListener('keydown', handleKeydown));
onUnmounted(() => document.removeEventListener('keydown', handleKeydown));
</script>

<template>
  <Teleport to="body">
    <Transition name="modal">
      <div v-if="isOpen" class="modal-wrapper fixed inset-0 z-[100] flex items-center justify-center">
        <!-- Backdrop -->
        <div class="modal-backdrop absolute inset-0 bg-black/40 backdrop-blur-sm" @click="close"></div>
        
        <!-- Modal Content -->
        <div class="modal-content bg-white rounded-2xl shadow-xl w-full max-w-lg mx-4 z-10 overflow-hidden flex flex-col max-h-[90vh]">
          <!-- Header -->
          <div class="px-6 py-4 flex items-center justify-between border-b border-gray-100 shrink-0">
            <h3 class="text-xl font-bold text-gray-900">{{ title }}</h3>
            <button @click="close" class="text-gray-400 hover:text-gray-600 transition p-1">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          <!-- Body -->
          <div class="p-6 overflow-y-auto grow">
            <slot></slot>
          </div>
          
          <!-- Footer -->
          <div v-if="$slots.footer" class="px-6 py-4 bg-gray-50 border-t border-gray-100 flex justify-end gap-3 shrink-0">
            <slot name="footer"></slot>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<style scoped>
/* Wrapper allows children transitions to finish */
.modal-enter-active,
.modal-leave-active {
  transition: opacity 0.2s ease;
}

/* Backdrop: Instant appear, smooth disappear */
.modal-enter-active .modal-backdrop {
  opacity: 1; /* Instant 100% opacity on enter */
}
.modal-leave-active .modal-backdrop {
  transition: opacity 0.2s ease;
}
.modal-leave-to .modal-backdrop {
  opacity: 0;
}

/* Modal Content: Scale and fade on enter and leave */
.modal-enter-active .modal-content,
.modal-leave-active .modal-content {
  transition: transform 0.2s cubic-bezier(0.18, 0.89, 0.32, 1.28), opacity 0.2s ease;
}
.modal-enter-from .modal-content,
.modal-leave-to .modal-content {
  opacity: 0;
  transform: scale(0.95) translateY(10px);
}
</style>
