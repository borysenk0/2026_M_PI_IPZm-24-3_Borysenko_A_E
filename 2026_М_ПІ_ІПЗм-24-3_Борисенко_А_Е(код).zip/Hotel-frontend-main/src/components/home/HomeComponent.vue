<script setup lang="ts">
import { ref } from 'vue';
import ThreeModelViewer from '@/components/three/ThreeModelViewer.vue';

const mockHotelViews = [
  {
    id: 'view1',
    title: 'Лобі та ресепшн',
    description: 'Швидке заселення, зручні зони очікування, цілодобова підтримка.',
    imageUrl: '/assets/pictures/hote_lobby.jpg',
  },
  {
    id: 'view2',
    title: 'Ресторан та сніданки',
    description: 'Шведська лінія та авторське меню, room service, швидкі замовлення.',
    imageUrl: '/assets/pictures/restaurant_and_dinners.png',
  },
  {
    id: 'view3',
    title: 'Номери та сервіс',
    description: 'Чистота, комфорт, 3D-перегляд номера та бронювання в один клік.',
    imageUrl: '/assets/pictures/room.jpg',
  },
];

const slider = ref<HTMLDivElement | null>(null);

const scrollByCards = (direction: 'left' | 'right') => {
  if (!slider.value) return;
  const amount = Math.round(slider.value.clientWidth * 0.9);
  slider.value.scrollBy({ left: direction === 'left' ? -amount : amount, behavior: 'smooth' });
};
</script>

<template>
  <main class="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-10">
    <section class="space-y-4">
      <div class="text-center space-y-2">
        <h1 class="text-3xl sm:text-4xl font-extrabold tracking-tight text-gray-900">
          Готель · Ресторан · Сервіс в одному інтерфейсі
        </h1>
        <p class="text-gray-600 max-w-2xl mx-auto">
          3D-візуалізація, бронювання, меню ресторану та real-time моніторинг кухні.
        </p>
      </div>

      <div class="h-[620px] w-full">
        <ThreeModelViewer
          model-url="/models/hotel_draco.glb"
          :min-distance="2.2"
          :max-distance="14"
        />
      </div>
    </section>

    <section class="space-y-4">
      <div class="flex items-center justify-between">
        <h2 class="text-xl font-bold text-gray-900">Види нашого готелю</h2>
        <div class="flex gap-2">
          <button
            type="button"
            class="px-3 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-sm font-semibold"
            @click="scrollByCards('left')"
          >
            ←
          </button>
          <button
            type="button"
            class="px-3 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-sm font-semibold"
            @click="scrollByCards('right')"
          >
            →
          </button>
        </div>
      </div>

      <div
        ref="slider"
        class="flex gap-4 overflow-x-auto scroll-smooth pb-2"
        style="scrollbar-width: thin;"
      >
        <article
          v-for="card in mockHotelViews"
          :key="card.id"
          class="min-w-[320px] max-w-full bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm"
        >
          <img :src="card.imageUrl" :alt="card.title" class="h-44 w-full object-cover" />
          <div class="p-4 space-y-2">
            <h3 class="font-bold text-gray-900">{{ card.title }}</h3>
            <p class="text-sm text-gray-600">{{ card.description }}</p>
          </div>
        </article>
      </div>
    </section>
  </main>
</template>

<style scoped>
</style>