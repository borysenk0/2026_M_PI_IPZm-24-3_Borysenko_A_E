<script setup lang="ts">
import { computed, ref, onMounted } from 'vue';
import { useHotelStore } from '@/stores/hotel';
import ThreeModelViewer from '@/components/three/ThreeModelViewer.vue';
import Modal from '@/components/ui/Modal.vue';
import api from '@/api';
import { useNotification } from '@kyvg/vue3-notification';

const hotel = useHotelStore();
const { notify } = useNotification();
const selectedRoomId = ref<number | null>(null);

const isBookingModalOpen = ref(false);
const bookingForm = ref({
  check_in_date: '',
  check_out_date: ''
});

onMounted(() => {
  hotel.fetchAll();
});

const selectedRoom = computed(() =>
  hotel.state.rooms.find((r) => r.id === selectedRoomId.value) ?? null,
);

const myActiveBooking = computed(() => {
  if (!hotel.currentUser) return null;
  // Повертаємо останню активну бронь (PENDING, CONFIRMED або CHECKED_IN)
  const active = hotel.currentUserBookings.filter(b => ['PENDING', 'CONFIRMED', 'CHECKED_IN'].includes(b.status));
  return active.length > 0 ? active[active.length - 1] : null;
});

const bookedRoom = computed(() => {
  if (!myActiveBooking.value) return null;
  return hotel.state.rooms.find(r => r.id === myActiveBooking.value?.room_id) ?? null;
});

const statusPill = (status: string) => {
  if (status === 'AVAILABLE') return 'bg-green-50 text-green-700 border-green-200';
  if (status === 'RESERVED' || status === 'CONFIRMED') return 'bg-yellow-50 text-yellow-800 border-yellow-200';
  if (status === 'OCCUPIED' || status === 'CHECKED_IN') return 'bg-indigo-50 text-indigo-700 border-indigo-200';
  if (status === 'PENDING') return 'bg-amber-50 text-amber-700 border-amber-200';
  return 'bg-gray-50 text-gray-700 border-gray-200';
};

const openBookingModal = (roomId: number) => {
  selectedRoomId.value = roomId;
  bookingForm.value = { check_in_date: '', check_out_date: '' };
  isBookingModalOpen.value = true;
};

const confirmBooking = async () => {
  const today = new Date().toISOString().split('T')[0];
  
  if (!bookingForm.value.check_in_date || !bookingForm.value.check_out_date) {
    notify({ type: 'error', title: 'Увага', text: 'Заповніть обидві дати!' });
    return;
  }
  if (bookingForm.value.check_in_date < today) {
    notify({ type: 'error', title: 'Увага', text: 'Дата заїзду не може бути у минулому!' });
    return;
  }
  if (bookingForm.value.check_out_date <= bookingForm.value.check_in_date) {
    notify({ type: 'error', title: 'Увага', text: 'Дата виїзду має бути пізнішою за заїзд!' });
    return;
  }

  try {
    await api.post('/bookings', {
      user_id: hotel.currentUser?.id,
      room_id: selectedRoomId.value,
      check_in_date: bookingForm.value.check_in_date,
      check_out_date: bookingForm.value.check_out_date,
      status: 'PENDING'
    });
    await hotel.fetchAll();
    isBookingModalOpen.value = false;
    notify({ type: 'success', title: 'Успішно', text: 'Номер успішно заброньовано! Очікуйте підтвердження.' });
  } catch (err) {
    notify({ type: 'error', title: 'Помилка', text: 'Не вдалося створити бронювання.' });
  }
};

const cancelBooking = async (id: number) => {
  if (!confirm('Ви дійсно бажаєте скасувати бронь?')) return;
  try {
    await api.put(`/bookings/${id}`, { status: 'CANCELLED' });
    await hotel.fetchAll();
    notify({ type: 'warn', title: 'Скасовано', text: 'Ваша бронь була скасована.' });
  } catch (err) {
    notify({ type: 'error', title: 'Помилка', text: 'Не вдалося скасувати бронь.' });
  }
};
</script>

<template>
  <main class="max-w-7xl mx-auto px-4 sm:px-6 py-8">
    <header class="mb-6">
      <h1 class="text-2xl font-bold text-gray-900">Бронювання номерів</h1>
      <p v-if="!myActiveBooking" class="text-sm text-gray-600">
        Перегляньте доступні номери та оберіть ідеальний варіант для вашого відпочинку.
      </p>
      <p v-else class="text-sm text-gray-600">
        Інформація про ваше поточне замовлення.
      </p>
    </header>

    <!-- Якщо гість має активну бронь -->
    <section v-if="myActiveBooking" class="bg-indigo-50 border border-indigo-200 rounded-3xl p-8 flex flex-col md:flex-row items-start gap-8 shadow-sm">
      <div class="flex-1 space-y-4">
        <div>
          <div class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-3 bg-white" :class="statusPill(myActiveBooking.status)">
            Статус: {{ myActiveBooking.status }}
          </div>
          <h2 class="text-3xl font-black text-gray-900 border-b border-indigo-200/50 pb-4 mb-4">
            Ваш номер: {{ bookedRoom?.description || 'Немає опису' }} (№ {{ bookedRoom?.number }})
          </h2>
        </div>
        
        <div class="grid grid-cols-2 gap-4">
          <div class="bg-white rounded-xl p-4 border border-indigo-100 shadow-sm">
            <div class="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">Дата заїзду</div>
            <div class="text-lg font-bold text-gray-900">{{ new Date(myActiveBooking.check_in_date).toLocaleDateString() }}</div>
          </div>
          <div class="bg-white rounded-xl p-4 border border-indigo-100 shadow-sm">
            <div class="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">Дата виїзду</div>
            <div class="text-lg font-bold text-gray-900">{{ new Date(myActiveBooking.check_out_date).toLocaleDateString() }}</div>
          </div>
        </div>

        <div class="pt-4 flex gap-4">
          <button
            v-if="['PENDING', 'CONFIRMED'].includes(myActiveBooking.status)"
            @click="cancelBooking(myActiveBooking.id)"
            class="px-5 py-2.5 bg-white border border-red-200 text-red-600 hover:bg-red-50 rounded-xl font-bold transition shadow-sm"
          >
            Скасувати бронювання
          </button>
          <div v-else class="text-sm text-gray-600 bg-white px-4 py-3 border border-indigo-100 rounded-xl shadow-sm">
            Ви вже заселені. Скасувати бронь може лише адміністратор. 
            <router-link to="/restaurant" class="text-indigo-600 font-bold ml-2 hover:underline">Замовити їжу у номер &rarr;</router-link>
          </div>
        </div>
      </div>
      
      <div class="w-full md:w-[400px] h-[300px] rounded-2xl overflow-hidden border-2 border-indigo-100 shadow-md bg-white">
        <!-- Optional preview for booked room -->
         <ThreeModelViewer
            model-url="/models/room_draco.glb"
            :min-distance="1.4"
            :max-distance="10"
         />
      </div>
    </section>

    <!-- Якщо немає броні (Список номерів) -->
    <section v-else class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div class="lg:col-span-2">
        <div class="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm">
          <table class="w-full text-left">
            <thead class="bg-gray-50 border-b border-gray-200">
              <tr class="text-xs uppercase tracking-wider text-gray-600">
                <th class="p-3">Номер</th>
                <th class="p-3">Опис</th>
                <th class="p-3">Ціна/ніч</th>
                <th class="p-3">Статус на зараз</th>
                <th class="p-3 text-right">Дії</th>
              </tr>
            </thead>
            <tbody>
              <tr
                v-for="room in hotel.state.rooms"
                :key="room.id"
                class="border-b border-gray-100 hover:bg-gray-50"
              >
                <td class="p-3 font-semibold text-gray-900">{{ room.number }}</td>
                <td class="p-3 text-sm text-gray-700">
                  <div class="font-medium">{{ room.description || 'Опис відсутній' }}</div>
                </td>
                <td class="p-3 text-sm text-gray-700">{{ room.cost }} ₴</td>
                <td class="p-3">
                  <span
                    class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border whitespace-nowrap"
                    :class="statusPill(room.status)"
                  >
                    {{ room.status }}
                  </span>
                </td>
                <td class="p-3 text-right">
                  <div class="inline-flex gap-2">
                    <button
                      type="button"
                      class="px-3 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-sm font-semibold transition"
                      @click="selectedRoomId = room.id"
                    >
                      Оглянути номер
                    </button>
                    <!-- Бронювати можна всі номери, так як це може бути на майбутні дати. -->
                    <button
                      type="button"
                      class="px-3 py-2 rounded-lg bg-black text-white hover:bg-gray-800 text-sm font-semibold transition"
                      @click="openBookingModal(room.id)"
                    >
                      Забронювати
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <aside class="space-y-3">
        <div class="bg-white border border-gray-200 rounded-2xl p-4 shadow-sm">
          <h2 class="font-bold text-gray-900">Прев'ю номеру</h2>
          <p class="text-sm text-gray-600">
            {{ selectedRoom ? `Обрано: № ${selectedRoom.number} - ${selectedRoom.description || 'Немає опису'}` : 'Оберіть номер та натисніть “Оглянути номер”.' }}
          </p>
        </div>

        <div class="h-[420px]">
            <ThreeModelViewer
              v-if="selectedRoom"
              model-url="/models/room_draco.glb"
              :min-distance="1.4"
              :max-distance="10"
            />
          <div
            v-else
            class="h-full rounded-2xl border border-gray-200 bg-gray-50 grid place-items-center text-sm text-gray-500 shadow-inner"
          >
            Немає обраного номеру
          </div>
        </div>
      </aside>
    </section>

    <!-- Модалка вибору дат -->
    <Modal :isOpen="isBookingModalOpen" title="Вибір дат бронювання" @close="isBookingModalOpen = false">
      <div class="space-y-4">
        <p class="text-sm text-gray-600 mb-4">Будь ласка, вкажіть дати на коли ви бажаєте забронювати номер.</p>
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Дата заїзду (Check-in)</label>
          <input v-model="bookingForm.check_in_date" type="date" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" />
        </div>
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Дата виїзду (Check-out)</label>
          <input v-model="bookingForm.check_out_date" type="date" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" />
        </div>
      </div>
      <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-gray-100">
        <button @click="isBookingModalOpen = false" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-xl font-semibold transition">
          Скасувати
        </button>
        <button @click="confirmBooking" class="px-6 py-2 bg-[#1a1a1a] hover:bg-black text-white rounded-xl font-bold shadow-sm transition">
          Підтвердити
        </button>
      </div>
    </Modal>
  </main>
</template>

