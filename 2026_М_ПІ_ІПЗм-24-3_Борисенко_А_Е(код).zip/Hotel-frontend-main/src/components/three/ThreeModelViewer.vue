<script setup lang="ts">
import { onMounted, onUnmounted, ref, watch } from 'vue'
import * as THREE from 'three'
import { DRACOLoader, GLTFLoader, OrbitControls } from 'three-stdlib'
import { gsap } from 'gsap'

const props = withDefaults(
    defineProps<{
      modelUrl: string
      background?: string
      minDistance?: number
      maxDistance?: number
    }>(),
    {
      background: '#0b0f19',
      minDistance: 1.2,
      maxDistance: 8,
    }
)

const container = ref<HTMLDivElement | null>(null)
const error = ref<string | null>(null)
const isLoading = ref(true)

let renderer: THREE.WebGLRenderer | null = null
let scene: THREE.Scene | null = null
let camera: THREE.PerspectiveCamera | null = null
let controls: OrbitControls | null = null
let animationId: number | null = null
let currentModel: THREE.Object3D | null = null

let cameraAngle = 0
const cameraRadius = 6
const cameraHeight = 2

function disposeScene() {
  if (animationId) cancelAnimationFrame(animationId)
  animationId = null

  controls?.dispose()
  controls = null

  if (currentModel && scene) scene.remove(currentModel)
  currentModel = null

  if (renderer) {
    renderer.dispose()
    if (renderer.domElement?.parentNode) {
      renderer.domElement.parentNode.removeChild(renderer.domElement)
    }
  }

  renderer = null
  scene = null
  camera = null
}

function fitRenderer() {
  if (!container.value || !renderer || !camera) return

  const width = container.value.clientWidth
  const height = container.value.clientHeight

  renderer.setSize(width, height)
  camera.aspect = width / height
  camera.updateProjectionMatrix()
}

function updateCameraPosition() {
  if (!camera || !controls) return

  const x = Math.sin(cameraAngle) * cameraRadius
  const z = Math.cos(cameraAngle) * cameraRadius

  camera.position.set(x, cameraHeight, z)

  // камера всегда смотрит на модель
  controls.target.set(0, 0.9, 0)
  controls.update()
}

async function loadModel() {
  if (!scene) return

  error.value = null
  isLoading.value = true

  const gltfLoader = new GLTFLoader()
  const draco = new DRACOLoader()

  draco.setDecoderPath('https://www.gstatic.com/draco/v1/decoders/')
  gltfLoader.setDRACOLoader(draco)

  // ⏱️ СТАРТ ЗАМЕРА
  const startTime = performance.now()
  console.log('[MODEL] Start loading:', props.modelUrl)

  try {
    const gltf = await gltfLoader.loadAsync(props.modelUrl)

    // ⏱️ КОНЕЦ ЗАМЕРА
    const endTime = performance.now()
    const loadTime = ((endTime - startTime) / 1000).toFixed(2)

    console.log(`[MODEL] Loaded in ${loadTime}s`)

    if (currentModel) scene.remove(currentModel)

    currentModel = gltf.scene

    currentModel.position.set(-2, -10, -20)
    currentModel.rotation.y = THREE.MathUtils.degToRad(-45)

    scene.add(currentModel)

  } catch (e) {
    const endTime = performance.now()
    console.log('[MODEL] Failed after', ((endTime - startTime) / 1000).toFixed(2), 's')

    error.value =
        'Не удалось загрузить 3D-модель. Проверь путь к файлу и что модель действительно Draco-совместимая.'
    console.error(e)
  } finally {
    draco.dispose()
    isLoading.value = false
  }
}

function rotateLeft() {
  if (!camera) return

  cameraAngle += THREE.MathUtils.degToRad(45)

  gsap.to(
      { angle: cameraAngle - THREE.MathUtils.degToRad(45) },
      {
        angle: cameraAngle,
        duration: 0.8,
        ease: 'power2.out',
        onUpdate() {
          cameraAngle = this.targets()[0].angle
          updateCameraPosition() // ← КАМЕРА СМЕЩАЕТСЯ ВЛЕВО И ПОВОРАЧИВАЕТСЯ К МОДЕЛИ
        },
      }
  )
}

function rotateRight() {
  if (!camera) return

  cameraAngle -= THREE.MathUtils.degToRad(45)

  gsap.to(
      { angle: cameraAngle + THREE.MathUtils.degToRad(45) },
      {
        angle: cameraAngle,
        duration: 0.8,
        ease: 'power2.out',
        onUpdate() {
          cameraAngle = this.targets()[0].angle
          updateCameraPosition() // ← КАМЕРА СМЕЩАЕТСЯ ВПРАВО И ПОВОРАЧИВАЕТСЯ К МОДЕЛИ
        },
      }
  )
}

onMounted(async () => {
  if (!container.value) return

  scene = new THREE.Scene()
  scene.background = new THREE.Color(props.background)

  camera = new THREE.PerspectiveCamera(
      65,
      container.value.clientWidth / container.value.clientHeight,
      0.1,
      2000
  )

  camera.position.set(0, 1.2, 3.2)

  renderer = new THREE.WebGLRenderer({
    antialias: true,
    alpha: true,
  })

  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
  renderer.setSize(container.value.clientWidth, container.value.clientHeight)

  container.value.appendChild(renderer.domElement)

  const ambient = new THREE.AmbientLight(0xffffff, 0.6)
  scene.add(ambient)

  const dir = new THREE.DirectionalLight(0xffffff, 1)
  dir.position.set(2, 6, 6)
  scene.add(dir)

  controls = new OrbitControls(camera, renderer.domElement)
  controls.enableDamping = true
  controls.enableZoom = false
  controls.minDistance = props.minDistance
  controls.maxDistance = props.maxDistance
  controls.target.set(0, 0.9, 0)
  controls.update()
  updateCameraPosition()

  await loadModel()

  const animate = () => {
    animationId = requestAnimationFrame(animate)

    controls?.update()
    renderer?.render(scene!, camera!)
  }

  animate()

  const onResize = () => fitRenderer()
  window.addEventListener('resize', onResize)

  onUnmounted(() => {
    window.removeEventListener('resize', onResize)
  })
})

watch(
    () => props.modelUrl,
    async () => {
      if (!scene) return
      await loadModel()
    }
)

onUnmounted(() => {
  disposeScene()
})
</script>

<template>
  <div class="relative w-full h-full">

    <!-- стрелка влево -->
    <button
        @click="rotateLeft"
        class="absolute left-4 top-1/2 -translate-y-1/2 z-10
             bg-white/20 backdrop-blur-md text-white
             w-12 h-12 rounded-full
             flex items-center justify-center
             text-xl hover:bg-white/40 transition"
    >
      ◀
    </button>

    <!-- стрелка вправо -->
    <button
        @click="rotateRight"
        class="absolute right-4 top-1/2 -translate-y-1/2 z-10
             bg-white/20 backdrop-blur-md text-white
             w-12 h-12 rounded-full
             flex items-center justify-center
             text-xl hover:bg-white/40 transition"
    >
      ▶
    </button>

    <div
        ref="container"
        class="w-full h-full rounded-xl overflow-hidden border border-gray-200 bg-black"
    />

    <div
        v-if="isLoading"
        class="absolute inset-0 grid place-items-center text-sm text-white/80 bg-black/30"
    >
      Загрузка 3D…
    </div>

    <div
        v-if="error"
        class="absolute inset-0 p-4 text-sm text-white bg-red-900/60 backdrop-blur-sm"
    >
      {{ error }}
    </div>
  </div>
</template>