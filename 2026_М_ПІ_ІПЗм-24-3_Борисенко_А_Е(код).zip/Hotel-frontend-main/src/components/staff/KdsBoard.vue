<script setup lang="ts">
import { computed } from 'vue';
import { useHotelStore } from '@/stores/hotel';
import VueApexCharts from 'vue3-apexcharts';

const hotel = useHotelStore();

// ---- Аналітика для Диплому ---- //
const totalOrders = computed(() => hotel.state.orders.length);
const totalRevenue = computed(() => {
  return hotel.state.orders.reduce((acc, curr) => acc + (Number(curr.total_price) || 0), 0);
});
const activeOrdersCount = computed(() => hotel.residentOrdersForManager.length);

const criticalIngredients = computed(() => {
  return hotel.state.ingredients.filter(i => Number(i.count) <= Number(i.min_threshold));
});

// Графік 1: Кількість замовлень за статусом
const ordersByStatusChartOpts = computed(() => ({
  chart: { type: 'donut', fontFamily: 'Inter, sans-serif' },
  labels: ['Нові', 'Готуються', 'Готові', 'Видані', 'Скасовані'],
  colors: ['#3b82f6', '#f59e0b', '#10b981', '#64748b', '#ef4444'],
  dataLabels: { enabled: false },
  plotOptions: { pie: { donut: { size: '70%' } } }
}));

const ordersByStatusSeries = computed(() => {
  const os = hotel.state.orders;
  return [
    os.filter(o => o.status === 'NEW').length,
    os.filter(o => o.status === 'COOKING' || o.status === 'IN_PROGRESS').length,
    os.filter(o => o.status === 'READY').length,
    os.filter(o => o.status === 'SERVED').length,
    os.filter(o => o.status === 'CANCELLED').length,
  ];
});

// Графік 2: Використання Інгредієнтів (Товарні залишки)
const inventoryChartOpts = computed(() => ({
  chart: { type: 'bar', toolbar: { show: false }, fontFamily: 'Inter, sans-serif' },
  plotOptions: { bar: { horizontal: false, columnWidth: '55%', borderRadius: 4 } },
  dataLabels: { enabled: false },
  stroke: { show: true, width: 2, colors: ['transparent'] },
  xaxis: { categories: hotel.state.ingredients.map(i => i.name) },
  yaxis: { title: { text: 'Кількість залишків' } },
  colors: ['#1a1a1a', '#e2e8f0'],
  fill: { opacity: 1 },
}));

const inventorySeries = computed(() => {
  return [
    {
      name: 'Поточний залишок',
      data: hotel.state.ingredients.map(i => i.count)
    },
    {
      name: 'Критичний поріг (Норма)',
      data: hotel.state.ingredients.map(i => i.min_threshold)
    }
  ];
});

// Графік 3: Динаміка замовлень за днями
const ordersByDayChartOpts = computed(() => ({
  chart: { type: 'area', toolbar: { show: false }, fontFamily: 'Inter, sans-serif' },
  colors: ['#3b82f6'],
  dataLabels: { enabled: false },
  stroke: { curve: 'smooth' },
  xaxis: { type: 'datetime' },
  yaxis: { title: { text: 'Сума (₴)' } }
}));

const ordersByDaySeries = computed(() => {
  // Агрегуємо замовлення за створеною датою
  const salesByDate: Record<string, number> = {};
  hotel.state.orders.forEach(o => {
    // Відкидаємо час
    const dStr = new Date(o.created_at).toISOString().split('T')[0];
    salesByDate[dStr] = (salesByDate[dStr] || 0) + (Number(o.total_price) || 0);
  });
  
  const dat = Object.entries(salesByDate).map(([date, val]) => [new Date(date).getTime(), val]).sort((a, b) => a[0] - b[0]);
  return [{ name: 'Виторг', data: dat }];
});

</script>

<template>
  <div class="space-y-6">
    <header class="flex justify-between items-end">
      <div>
        <h2 class="text-2xl font-bold text-gray-900 tracking-tight">KDS Дашборд Аналітики</h2>
        <p class="text-sm text-gray-600">Аналітичний модуль для диплому: "Дослідження методів автоматизації процесів управління рестораного бізнесу"</p>
      </div>
    </header>

    <!-- Сводка (KPIs) -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
      <div class="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm hover:shadow-md transition">
        <div class="text-sm text-gray-500 font-semibold uppercase tracking-wider mb-1">Усього замовлень</div>
        <div class="text-3xl font-black text-gray-900">{{ totalOrders }}</div>
      </div>
      <div class="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm hover:shadow-md transition">
        <div class="text-sm text-gray-500 font-semibold uppercase tracking-wider mb-1">Виторг Ресторану</div>
        <div class="text-3xl font-black text-emerald-600">{{ totalRevenue.toFixed(2) }} ₴</div>
      </div>
      <div class="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm hover:shadow-md transition">
        <div class="text-sm text-gray-500 font-semibold uppercase tracking-wider mb-1">Активні на кухні</div>
        <div class="text-3xl font-black text-amber-600">{{ activeOrdersCount }}</div>
      </div>
      <div class="bg-red-50 rounded-2xl border border-red-200 p-5 shadow-sm hover:shadow-md transition">
        <div class="text-sm text-red-600 font-semibold uppercase tracking-wider mb-1">Критичні залишки</div>
        <div class="text-3xl font-black text-red-700">{{ criticalIngredients.length }} позицій</div>
      </div>
    </div>

    <!-- Графіки -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      <div class="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm lg:col-span-1 flex flex-col items-center hover:shadow-md transition">
        <h3 class="font-bold text-gray-900 self-start mb-4">Статуси Замовлень</h3>
        <VueApexCharts width="100%" type="donut" :options="ordersByStatusChartOpts" :series="ordersByStatusSeries"></VueApexCharts>
      </div>

      <div class="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm lg:col-span-2 hover:shadow-md transition">
        <h3 class="font-bold text-gray-900 mb-4">Динаміка Виторгу Ресторану</h3>
        <VueApexCharts height="250" type="area" :options="ordersByDayChartOpts" :series="ordersByDaySeries"></VueApexCharts>
      </div>

      <div class="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm lg:col-span-3 hover:shadow-md transition">
        <h3 class="font-bold text-gray-900 mb-4">Моніторинг Залишків Складу (Рівень Запасів)</h3>
        <p class="text-xs text-gray-500 mb-2">Автоматизована перевірка складських позицій. Якщо чорний стовпець опускається нижче сірого, система генерує Email менеджеру щодо критичного залишку (налаштовано на бекенді).</p>
        <VueApexCharts height="300" type="bar" :options="inventoryChartOpts" :series="inventorySeries"></VueApexCharts>
      </div>
      
    </div>
  </div>
</template>

