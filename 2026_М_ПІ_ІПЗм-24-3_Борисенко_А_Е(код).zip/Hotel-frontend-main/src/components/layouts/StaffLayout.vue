<script setup lang="ts">
</script>

<template>
  <div class="staff-layout">
    <slot />
  </div>
</template>

<style scoped>
.staff-layout {
  max-width: 1440px;
  margin: 0 auto;
  padding: 1rem;
}
</style>

