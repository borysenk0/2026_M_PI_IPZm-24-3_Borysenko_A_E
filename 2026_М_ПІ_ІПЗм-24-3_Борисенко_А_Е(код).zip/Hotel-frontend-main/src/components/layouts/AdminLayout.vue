<script setup lang="ts">
</script>

<template>
  <div class="admin-layout">
    <slot />
  </div>
</template>

<style scoped>
.admin-layout {
  max-width: 1440px;
  margin: 0 auto;
  padding: 1.5rem 1rem 2rem;
}
</style>

