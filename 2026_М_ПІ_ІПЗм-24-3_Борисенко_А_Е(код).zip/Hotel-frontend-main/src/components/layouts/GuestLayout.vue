<script setup lang="ts">
</script>

<template>
  <div class="guest-layout">
    <slot />
  </div>
</template>

<style scoped>
.guest-layout {
  max-width: 1200px;
  margin: 0 auto;
  padding: 1.5rem 1rem 2rem;
}
</style>

