<script setup lang="ts">
import { computed, ref } from 'vue';
import { useHotelStore } from '@/stores/hotel';
import { useNotification } from '@kyvg/vue3-notification';
import Modal from '@/components/ui/Modal.vue';

const hotel = useHotelStore();
const { notify } = useNotification();

const rows = computed(() =>
  hotel.state.roles.map((r) => ({
    id: r.id,
    name: r.name,
  })),
);

const filterRoleName = ref('');

const filteredRows = computed(() => {
  return rows.value.filter(r => {
    if (filterRoleName.value && !r.name.toLowerCase().includes(filterRoleName.value.toLowerCase())) return false;
    return true;
  });
});

const clearFilters = () => {
  filterRoleName.value = '';
};

const isAddOpen = ref(false);
const form = ref({
  name: '',
});

const handleAdd = () => {
  if (!form.value.name.trim()) {
    notify({ type: 'error', title: 'Помилка', text: 'Введіть назву ролі' });
    return;
  }

  const newId = Math.max(0, ...hotel.state.roles.map(r => r.id)) + 1;
  hotel.state.roles.push({
    id: newId,
    name: form.value.name,
  });

  notify({ type: 'success', title: 'Успішно', text: 'Роль успішно додано' });
  isAddOpen.value = false;
  form.value = { name: '' };
};

const isEditOpen = ref(false);
const editForm = ref({
  id: 0,
  name: '',
});

const openEdit = (row: any) => {
  editForm.value = { ...row };
  isEditOpen.value = true;
};

const handleEdit = () => {
  if (!editForm.value.name.trim()) {
    notify({ type: 'error', title: 'Помилка', text: 'Введіть назву ролі' });
    return;
  }

  const idx = hotel.state.roles.findIndex(r => r.id === editForm.value.id);
  if (idx !== -1) {
    hotel.state.roles[idx] = { ...editForm.value };
    notify({ type: 'success', title: 'Успішно', text: 'Роль оновлено' });
    isEditOpen.value = false;
  } else {
    notify({ type: 'error', title: 'Помилка', text: 'Роль не знайдена' });
  }
};
</script>

<template>
  <div>
    <section class="space-y-4">
      <header class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div>
        <h2 class="text-lg font-bold text-gray-900">Ролі</h2>
        <p class="text-sm text-gray-600">Набір ролей, які використовуються в системі.</p>
      </div>
      <button 
        @click="isAddOpen = true"
        class="bg-black hover:bg-gray-800 text-white px-4 py-2 rounded-xl font-bold text-sm shadow-sm transition"
      >
        Додати роль
      </button>
    </header>

    <!-- Filter Ribbon -->
    <div class="bg-gray-50 border border-gray-200 rounded-2xl p-4 flex gap-4 min-w-[200px] items-end">
      <div class="flex-1 max-w-sm">
        <label class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Пошук за Назвою</label>
        <input v-model="filterRoleName" type="text" placeholder="Уведіть назву..." class="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
      </div>
      <button @click="clearFilters" v-if="filterRoleName" class="px-4 py-2 border border-gray-300 rounded-xl bg-white text-sm font-semibold text-gray-700 hover:bg-gray-100 transition">
        Скинути
      </button>
    </div>

    <div class="bg-white border border-gray-200 rounded-2xl overflow-hidden">
      <table class="w-full text-left">
        <thead class="bg-gray-50 border-b border-gray-200">
          <tr class="text-xs uppercase tracking-wider text-gray-600">
            <th class="p-3">ID</th>
            <th class="p-3">Назва ролі</th>
            <th class="p-3 text-right">Дії</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="row in filteredRows"
            :key="row.id"
            class="border-b border-gray-100 hover:bg-gray-50"
          >
            <td class="p-3 text-sm text-gray-700">{{ row.id }}</td>
            <td class="p-3 font-semibold text-gray-900">{{ row.name }}</td>
            <td class="p-3 text-right">
              <div class="inline-flex gap-2">
                <button
                  type="button"
                  @click="openEdit(row)"
                  class="px-3 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-sm font-semibold"
                >
                  Редагувати
                </button>
                <button
                  type="button"
                  class="px-3 py-2 rounded-lg border border-red-200 bg-white hover:bg-red-50 text-sm font-semibold text-red-700"
                >
                  Видалити
                </button>
              </div>
            </td>
          </tr>
          <tr v-if="filteredRows.length === 0">
            <td colspan="3" class="p-8 text-center text-sm text-gray-500 bg-gray-50/50">
              Ролей не знайдено.
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <Modal :isOpen="isAddOpen" title="Додати роль" @close="isAddOpen = false">
    <div class="space-y-4">
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1">Назва ролі</label>
        <input v-model="form.name" type="text" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" placeholder="manager" />
      </div>
    </div>
    <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-gray-100">
      <button @click="isAddOpen = false" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-xl font-semibold transition">
        Скасувати
      </button>
      <button @click="handleAdd" class="px-6 py-2 bg-[#1a1a1a] hover:bg-black text-white rounded-xl font-bold shadow-sm transition">
        Зберегти
      </button>
    </div>
  </Modal>

  <Modal :isOpen="isEditOpen" title="Редагувати роль" @close="isEditOpen = false">
    <div class="space-y-4">
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1">Назва ролі</label>
        <input v-model="editForm.name" type="text" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" placeholder="manager" />
      </div>
    </div>
    <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-gray-100">
      <button @click="isEditOpen = false" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-xl font-semibold transition">
        Скасувати
      </button>
      <button @click="handleEdit" class="px-6 py-2 bg-[#1a1a1a] hover:bg-black text-white rounded-xl font-bold shadow-sm transition">
        Зберегти
      </button>
    </div>
  </Modal>
  </div>
</template>

