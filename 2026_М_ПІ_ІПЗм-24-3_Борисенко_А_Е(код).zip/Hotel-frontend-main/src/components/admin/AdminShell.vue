<script setup lang="ts">
import Sidebar, { type SidebarItem } from '@/components/admin/Sidebar.vue';

const sidebarItems: SidebarItem[] = [
  { label: 'Дашборд', toName: 'admin-dashboard', permissions: ['admin'] },
  { label: 'Користувачі', toName: 'admin-users', permissions: ['admin'] },
  { label: 'Кімнати', toName: 'admin-rooms', permissions: ['admin'] },
  { label: 'Бронювання', toName: 'admin-bookings', permissions: ['admin'] },
  { label: 'Ролі', toName: 'admin-roles', permissions: ['admin'] },
  { label: 'Замовлення', toName: 'admin-restaurant-orders', permissions: ['admin'] },
  { label: 'Столи', toName: 'admin-restaurant-tables', permissions: ['admin'] },
  { label: 'Склад', toName: 'admin-restaurant-inventory', permissions: ['admin'] },
  { label: 'Меню', toName: 'admin-restaurant-menu', permissions: ['admin'] },
];
</script>

<template>
  <main class="max-w-7xl mx-auto px-4 sm:px-6 py-8">
    <header class="mb-6">
      <h1 class="text-2xl font-bold text-gray-900">Адмін-панель</h1>
      <p class="text-sm text-gray-600">
        Управління користувачами, кімнатами, бронюваннями та ролями.
      </p>
    </header>

    <section class="flex flex-col lg:flex-row gap-6">
      <Sidebar :items="sidebarItems" />
      <div class="grow">
        <RouterView />
      </div>
    </section>
  </main>
</template>

