<script setup lang="ts">
import { computed, ref } from 'vue';
import { useHotelStore } from '@/stores/hotel';
import { useNotification } from '@kyvg/vue3-notification';
import api from '@/api';

const hotel = useHotelStore();
const { notify } = useNotification();
const search = ref('');

const filtered = computed(() => {
  const q = search.value.trim().toLowerCase();
  if (!q) return hotel.state.rooms;
  return hotel.state.rooms.filter(
    (r) => r.number.toString().includes(q) || (r.description && r.description.toLowerCase().includes(q)) || (r.title && r.title.toLowerCase().includes(q)),
  );
});

const statusBadge = (status: string) => {
  if (status === 'AVAILABLE') return 'bg-green-50 text-green-700 border-green-200';
  if (status === 'RESERVED') return 'bg-yellow-50 text-yellow-800 border-yellow-200';
  if (status === 'OCCUPIED') return 'bg-red-50 text-red-700 border-red-200';
  return 'bg-gray-50 text-gray-700 border-gray-200';
};

const onEdit = (roomId: number) => {
  // Пока mock: точечное редактирование добавим позже (modal + form).
  alert(`Редагувати кімнату #${roomId}`);
};

const onDelete = async (roomId: number) => {
  if (!confirm('Видалити номер зі списку?')) return;
  try {
    await api.delete(`/rooms/${roomId}`);
    await hotel.fetchAll();
    notify({ type: 'success', title: 'Успішно', text: 'Номер видалено' });
  } catch(e) {
    notify({ type: 'error', title: 'Помилка', text: 'Не вдалося видалити номер' });
  }
};
</script>

<template>
  <section class="space-y-4">
    <div class="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
      <h2 class="text-lg font-bold text-gray-900">Таблиця номерів</h2>
      <input
        v-model="search"
        type="text"
        placeholder="Пошук (номер/опис)…"
        class="w-full sm:w-80 px-3 py-2 border border-gray-200 rounded-xl bg-white outline-none focus:ring-2 focus:ring-black/10"
      />
    </div>

    <div class="bg-white border border-gray-200 rounded-2xl overflow-hidden">
      <table class="w-full text-left">
        <thead class="bg-gray-50 border-b border-gray-200">
          <tr class="text-xs uppercase tracking-wider text-gray-600">
            <th class="p-3">Номер</th>
            <th class="p-3">Опис</th>
            <th class="p-3">Ціна</th>
            <th class="p-3">Статус</th>
            <th class="p-3 text-right">Дії</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="room in filtered"
            :key="room.id"
            class="border-b border-gray-100 hover:bg-gray-50"
          >
            <td class="p-3 font-semibold text-gray-900">{{ room.number }}</td>
            <td class="p-3 text-sm text-gray-700">{{ room.title }}</td>
            <td class="p-3 text-sm text-gray-700">{{ room.pricePerNight }} ₴</td>
            <td class="p-3">
              <span
                class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border"
                :class="statusBadge(room.status)"
              >
                {{ room.status }}
              </span>
            </td>
            <td class="p-3 text-right">
              <div class="inline-flex gap-2">
                <button
                  type="button"
                  class="px-3 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-sm font-semibold"
                  @click="onEdit(room.id)"
                >
                  Редагувати
                </button>
                <button
                  type="button"
                  class="px-3 py-2 rounded-lg border border-red-200 bg-white hover:bg-red-50 text-sm font-semibold text-red-700"
                  @click="onDelete(room.id)"
                >
                  Видалити
                </button>
              </div>
            </td>
          </tr>
          <tr v-if="filtered.length === 0">
            <td colspan="5" class="p-6 text-center text-sm text-gray-500">Нічого не знайдено</td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</template>

