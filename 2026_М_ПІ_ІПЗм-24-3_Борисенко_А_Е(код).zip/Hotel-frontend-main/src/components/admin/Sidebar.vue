<script setup lang="ts">
import { computed } from 'vue';
import { useAuthStore } from '@/stores/auth';
import { useRoute } from 'vue-router';

type UserRole = 'guest' | 'user' | 'manager' | 'admin';

export interface SidebarItem {
  label: string;
  toName: string;
  permissions: UserRole[];
}

const props = defineProps<{
  items: SidebarItem[];
}>();

const authStore = useAuthStore();

const filteredItems = computed(() =>
  props.items.filter((i) => i.permissions.includes(authStore.role)),
);

const route = useRoute();
</script>

<template>
  <aside class="w-full lg:w-64 shrink-0">
    <div class="bg-white border border-gray-200 rounded-2xl p-3">
      <div class="px-2 py-2 text-xs uppercase tracking-wider text-gray-500">
        Навігація
      </div>
      <nav class="flex flex-col gap-1">
        <router-link
          v-for="item in filteredItems"
          :key="item.toName"
          :to="{ name: item.toName }"
          :class="[
            'px-3 py-2 rounded-xl text-sm font-semibold transition-colors',
            route.name === item.toName 
              ? 'bg-[#1a1a1a] text-white cursor-default' 
              : 'text-gray-700 hover:bg-gray-100 hover:text-black'
          ]"
        >
          {{ item.label }}
        </router-link>
      </nav>
    </div>
  </aside>
</template>

