<script setup lang="ts">
import { computed, ref } from 'vue';
import { useHotelStore } from '@/stores/hotel';
import { useNotification } from '@kyvg/vue3-notification';
import Modal from '@/components/ui/Modal.vue';
import html2pdf from 'html2pdf.js';

const hotel = useHotelStore();
const { notify } = useNotification();

const isAddOpen = ref(false);
const form = ref({
  user_id: hotel.state.users.length > 0 ? hotel.state.users[0].id : null,
  room_id: hotel.state.rooms.length > 0 ? hotel.state.rooms[0].id : null,
  check_in_date: '',
  check_out_date: '',
  total_price: 0,
  status: 'PENDING'
});

const isEditOpen = ref(false);
const editForm = ref({
  id: 0,
  user_id: null as number | null,
  room_id: null as number | null,
  check_in_date: '',
  check_out_date: '',
  total_price: 0,
  status: 'PENDING'
});

import api from '@/api';

const handleAdd = async () => {
  if (!form.value.user_id || !form.value.room_id || !form.value.check_in_date || !form.value.check_out_date) {
    notify({ type: 'error', title: 'Помилка', text: 'Заповніть всі обов\'язкові поля' });
    return;
  }

  if (new Date(form.value.check_in_date) >= new Date(form.value.check_out_date)) {
    notify({ type: 'error', title: 'Помилка', text: 'Дата виселення має бути після дати заселення' });
    return;
  }

  if (form.value.total_price < 0) {
    notify({ type: 'error', title: 'Помилка', text: 'Сума не може бути від\'ємною' });
    return;
  }
  
  try {
    await api.post('/bookings', {
      user_id: form.value.user_id,
      room_id: form.value.room_id,
      check_in_date: form.value.check_in_date,
      check_out_date: form.value.check_out_date,
      total_price: form.value.total_price,
      status: form.value.status
    });
    
    await hotel.fetchAll();
    notify({ type: 'success', title: 'Успішно', text: 'Бронювання успішно додано' });
    isAddOpen.value = false;
    form.value = {
      user_id: hotel.state.users.length > 0 ? hotel.state.users[0].id : null,
      room_id: hotel.state.rooms.length > 0 ? hotel.state.rooms[0].id : null,
      check_in_date: '',
      check_out_date: '',
      total_price: 0,
      status: 'PENDING'
    };
  } catch(e) {
    notify({ type: 'error', title: 'Помилка', text: 'Не вдалося додати бронювання' });
  }
};

const openEdit = (row: any) => {
  const b = hotel.state.bookings.find(bk => bk.id === row.id);
  if (b) {
    // Convert Dates if they are Date objects to strings for input[type="date"]
    const formatDt = (dt: string | Date) => {
      if (!dt) return '';
      const d = new Date(dt);
      return isNaN(d.getTime()) ? '' : d.toISOString().split('T')[0];
    };
    
    editForm.value = {
      id: b.id,
      user_id: b.user_id,
      room_id: b.room_id,
      check_in_date: formatDt(b.check_in_date),
      check_out_date: formatDt(b.check_out_date),
      total_price: b.total_price || 0,
      status: b.status as string
    };
    isEditOpen.value = true;
  }
};

const handleEdit = async () => {
  if (!editForm.value.user_id || !editForm.value.room_id || !editForm.value.check_in_date || !editForm.value.check_out_date) {
    notify({ type: 'error', title: 'Помилка', text: 'Заповніть всі обов\'язкові поля' });
    return;
  }

  if (new Date(editForm.value.check_in_date) >= new Date(editForm.value.check_out_date)) {
    notify({ type: 'error', title: 'Помилка', text: 'Дата виселення має бути після дати заселення' });
    return;
  }

  if (editForm.value.total_price < 0) {
    notify({ type: 'error', title: 'Помилка', text: 'Сума не може бути від\'ємною' });
    return;
  }

  try {
    const payload = { ...editForm.value };
    const id = payload.id;
    delete payload.id;
    await api.put(`/bookings/${id}`, payload);
    await hotel.fetchAll();
    notify({ type: 'success', title: 'Успішно', text: 'Бронювання оновлено' });
    isEditOpen.value = false;
  } catch(e) {
    notify({ type: 'error', title: 'Помилка', text: 'Бронювання не знайдено або помилка сервера' });
  }
};

const handleDelete = async (id: number) => {
  if (!confirm('Видалити бронювання?')) return;
  try {
    await api.delete(`/bookings/${id}`);
    await hotel.fetchAll();
    notify({ type: 'success', title: 'Успішно', text: 'Бронювання видалено' });
  } catch(e) {
    notify({ type: 'error', title: 'Помилка', text: 'Помилка при видаленні' });
  }
}

const rows = computed(() =>
  hotel.state.bookings.map((b) => {
    const user = hotel.state.users.find((u) => u.id === b.user_id);
    const room = hotel.state.rooms.find((r) => r.id === b.room_id);
    return {
      id: b.id,
      guestName: user?.full_name ?? '—',
      roomNumber: room?.number ?? '—',
      checkIn: b.check_in_date,
      checkOut: b.check_out_date,
      status: b.status,
    };
  }),
);

const filterGuest = ref('');
const filterRoom = ref('');
const filterStatus = ref('');
const filterDate = ref('');

const filteredRows = computed(() => {
  return rows.value.filter(row => {
    if (filterGuest.value && !row.guestName.toLowerCase().includes(filterGuest.value.toLowerCase())) return false;
    if (filterRoom.value && row.roomNumber.toString() !== filterRoom.value) return false;
    if (filterStatus.value && row.status !== filterStatus.value) return false;
    if (filterDate.value && row.checkIn !== filterDate.value) return false;
    return true;
  });
});

const uniqueRooms = computed(() => {
  const rms = new Set(rows.value.map(r => r.roomNumber).filter(Boolean));
  return Array.from(rms) as number[];
});

const clearFilters = () => {
  filterGuest.value = '';
  filterRoom.value = '';
  filterStatus.value = '';
  filterDate.value = '';
};

const translateStatus = (status: string) => {
  const map: Record<string, string> = {
    'PENDING': 'Очікує',
    'CONFIRMED': 'Підтверджено',
    'CHECKED_IN': 'Заселено',
    'CHECKED_OUT': 'Виселено',
    'CANCELLED': 'Скасовано'
  };
  return map[status] || status;
};

const statusPill = (status: string) => {
  if (status === 'CHECKED_IN') return 'bg-emerald-50 text-emerald-700 border-emerald-200';
  if (status === 'CONFIRMED') return 'bg-blue-50 text-blue-700 border-blue-200';
  if (status === 'PENDING') return 'bg-amber-50 text-amber-800 border-amber-200';
  if (status === 'CHECKED_OUT') return 'bg-gray-50 text-gray-700 border-gray-200';
  if (status === 'CANCELLED') return 'bg-red-50 text-red-700 border-red-200';
  return 'bg-gray-50 text-gray-700 border-gray-200';
};

const generatePdfReport = () => {
  const element = document.createElement('div');
  element.innerHTML = `
    <div style="padding: 20px; font-family: sans-serif; color: #000;">
      <h1 style="text-align: center; margin-bottom: 20px; font-size: 24px;">Звіт для Бухгалтерії: Бронювання</h1>
      <p style="margin-bottom: 20px;">Дата формування: ${new Date().toLocaleDateString('uk-UA')} ${new Date().toLocaleTimeString('uk-UA')}</p>
      <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
        <thead>
          <tr style="background-color: #f3f4f6;">
            <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">ID</th>
            <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Гість</th>
            <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Номер</th>
            <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Check-In</th>
            <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Check-Out</th>
            <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Статус</th>
          </tr>
        </thead>
        <tbody>
          ${filteredRows.value.map(r => `
            <tr>
              <td style="border: 1px solid #e5e7eb; padding: 8px;">${r.id}</td>
              <td style="border: 1px solid #e5e7eb; padding: 8px;">${r.guestName}</td>
              <td style="border: 1px solid #e5e7eb; padding: 8px;">№ ${r.roomNumber}</td>
              <td style="border: 1px solid #e5e7eb; padding: 8px;">${r.checkIn}</td>
              <td style="border: 1px solid #e5e7eb; padding: 8px;">${r.checkOut}</td>
              <td style="border: 1px solid #e5e7eb; padding: 8px;">${translateStatus(r.status)}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
      <div style="margin-top: 30px; text-align: right;">
        <p><strong>Разом записів:</strong> ${filteredRows.value.length}</p>
        <br/><br/>
        <p>Підпис відповідальної особи: _____________________</p>
      </div>
    </div>
  `;
  const opt = {
    margin:       10,
    filename:     'Звіт_Бронювання_' + new Date().toISOString().split('T')[0] + '.pdf',
    image:        { type: 'jpeg', quality: 0.98 },
    html2canvas:  { scale: 2 },
    jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
  };
  html2pdf().set(opt).from(element).save();
  notify({ type: 'success', title: 'Успішно', text: 'Почалося завантаження PDF звіту' });
};
</script>

<template>
  <div>
    <section class="space-y-4">
      <header class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div>
        <h2 class="text-lg font-bold text-gray-900">Бронювання</h2>
        <p class="text-sm text-gray-600">
          Для кожного запису замість технічного <code>user_id</code> відображається реальне ПІБ користувача.
        </p>
      </div>
      <div class="flex gap-2">
        <button 
          @click="generatePdfReport"
          class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl font-bold text-sm shadow-sm transition inline-flex items-center gap-2"
        >
          <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          PDF Звіт
        </button>
        <button 
          @click="isAddOpen = true"
          class="bg-black hover:bg-gray-800 text-white px-4 py-2 rounded-xl font-bold text-sm shadow-sm transition"
        >
          Додати бронювання
        </button>
      </div>
    </header>

    <!-- Filter Ribbon -->
    <div class="bg-gray-50 border border-gray-200 rounded-2xl p-4 flex flex-wrap gap-4 items-end">
      <div class="flex-1 min-w-[200px]">
        <label class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Пошук за Гостем</label>
        <input v-model="filterGuest" type="text" placeholder="Ім'я гостя..." class="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
      </div>
      <div class="w-32">
        <label class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Номер</label>
        <select v-model="filterRoom" class="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
          <option value="">Усі</option>
          <option v-for="r in uniqueRooms" :key="r" :value="r.toString()">№ {{ r }}</option>
        </select>
      </div>
      <div class="w-40">
        <label class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Статус</label>
        <select v-model="filterStatus" class="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
          <option value="">Усі статуси</option>
          <option value="PENDING">Очікує</option>
          <option value="CONFIRMED">Підтверджено</option>
          <option value="CHECKED_IN">Заселено</option>
          <option value="CHECKED_OUT">Виселено</option>
          <option value="CANCELLED">Скасовано</option>
        </select>
      </div>
      <div class="w-40">
        <label class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Check-In Дата</label>
        <input v-model="filterDate" type="date" class="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
      </div>
      <button @click="clearFilters" v-if="filterGuest || filterRoom || filterStatus || filterDate" class="px-4 py-2 border border-gray-300 rounded-xl bg-white text-sm font-semibold text-gray-700 hover:bg-gray-100 transition">
        Скинути
      </button>
    </div>

    <div class="bg-white border border-gray-200 rounded-2xl overflow-hidden">
      <table class="w-full text-left">
        <thead class="bg-gray-50 border-b border-gray-200">
          <tr class="text-xs uppercase tracking-wider text-gray-600">
            <th class="p-3">ID</th>
            <th class="p-3">Гість</th>
            <th class="p-3">Номер</th>
            <th class="p-3">Check-in</th>
            <th class="p-3">Check-out</th>
            <th class="p-3">Статус</th>
            <th class="p-3 text-right">Дії</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="row in filteredRows"
            :key="row.id"
            class="border-b border-gray-100 hover:bg-gray-50"
          >
            <td class="p-3 text-sm text-gray-700">{{ row.id }}</td>
            <td class="p-3 font-semibold text-gray-900">{{ row.guestName }}</td>
            <td class="p-3 text-sm text-gray-800">№ {{ row.roomNumber }}</td>
            <td class="p-3 text-sm text-gray-700">{{ row.checkIn }}</td>
            <td class="p-3 text-sm text-gray-700">{{ row.checkOut }}</td>
            <td class="p-3">
              <span
                class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border"
                :class="statusPill(row.status)"
              >
                {{ translateStatus(row.status) }}
              </span>
            </td>
            <td class="p-3 text-right">
              <div class="inline-flex gap-2">
                <button
                  type="button"
                  @click="openEdit(row)"
                  class="px-3 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-sm font-semibold"
                >
                  Редагувати
                </button>
                <button
                  type="button"
                  @click="handleDelete(row.id)"
                  class="px-3 py-2 rounded-lg border border-red-200 bg-white hover:bg-red-50 text-sm font-semibold text-red-700"
                >
                  Видалити
                </button>
              </div>
            </td>
          </tr>
          <tr v-if="filteredRows.length === 0">
            <td colspan="7" class="p-8 text-center text-sm text-gray-500 bg-gray-50/50">
              Бронювань не знайдено.
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <Modal :isOpen="isAddOpen" title="Додати бронювання" @close="isAddOpen = false">
    <div class="space-y-4">
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Гість</label>
          <select v-model="form.user_id" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none bg-white">
            <option v-for="u in hotel.state.users" :key="u.id" :value="u.id">
              {{ u.full_name }} ({{ u.email }})
            </option>
          </select>
        </div>
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Номер</label>
          <select v-model="form.room_id" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none bg-white">
            <option v-for="r in hotel.state.rooms" :key="r.id" :value="r.id" :disabled="['OCCUPIED', 'RESERVED'].includes(r.status)">
              № {{ r.number }} {{ ['OCCUPIED', 'RESERVED'].includes(r.status) ? '(Зайнято/Бронь)' : '(Вільний)' }}
            </option>
          </select>
        </div>
      </div>
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Check-in</label>
          <input v-model="form.check_in_date" type="date" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" />
        </div>
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Check-out</label>
          <input v-model="form.check_out_date" type="date" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" />
        </div>
      </div>
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Сума (₴)</label>
          <input v-model="form.total_price" type="number" step="1" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" />
        </div>
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Статус</label>
          <select v-model="form.status" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none bg-white">
            <option value="PENDING">Очікує (PENDING)</option>
            <option value="CONFIRMED">Підтверджено (CONFIRMED)</option>
            <option value="CHECKED_IN">Заселено (CHECKED_IN)</option>
            <option value="CHECKED_OUT">Виселено (CHECKED_OUT)</option>
            <option value="CANCELLED">Скасовано (CANCELLED)</option>
          </select>
        </div>
      </div>
    </div>
    <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-gray-100">
      <button @click="isAddOpen = false" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-xl font-semibold transition">
        Скасувати
      </button>
      <button @click="handleAdd" class="px-6 py-2 bg-[#1a1a1a] hover:bg-black text-white rounded-xl font-bold shadow-sm transition">
        Зберегти
      </button>
    </div>
  </Modal>

  <Modal :isOpen="isEditOpen" title="Редагувати бронювання" @close="isEditOpen = false">
    <div class="space-y-4">
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Гість</label>
          <select v-model="editForm.user_id" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none bg-white">
            <option v-for="u in hotel.state.users" :key="u.id" :value="u.id">
              {{ u.full_name }} ({{ u.email }})
            </option>
          </select>
        </div>
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Номер</label>
          <select v-model="editForm.room_id" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none bg-white">
            <option v-for="r in hotel.state.rooms" :key="r.id" :value="r.id" :disabled="['OCCUPIED', 'RESERVED'].includes(r.status) && r.id !== editForm.room_id">
              № {{ r.number }} {{ ['OCCUPIED', 'RESERVED'].includes(r.status) && r.id !== editForm.room_id ? '(Зайнято/Бронь)' : '(Вільний)' }}
            </option>
          </select>
        </div>
      </div>
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Check-in</label>
          <input v-model="editForm.check_in_date" type="date" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" />
        </div>
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Check-out</label>
          <input v-model="editForm.check_out_date" type="date" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" />
        </div>
      </div>
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Сума (₴)</label>
          <input v-model="editForm.total_price" type="number" step="1" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" />
        </div>
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Статус</label>
          <select v-model="editForm.status" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none bg-white">
            <option value="PENDING">Очікує (PENDING)</option>
            <option value="CONFIRMED">Підтверджено (CONFIRMED)</option>
            <option value="CHECKED_IN">Заселено (CHECKED_IN)</option>
            <option value="CHECKED_OUT">Виселено (CHECKED_OUT)</option>
            <option value="CANCELLED">Скасовано (CANCELLED)</option>
          </select>
        </div>
      </div>
    </div>
    <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-gray-100">
      <button @click="isEditOpen = false" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-xl font-semibold transition">
        Скасувати
      </button>
      <button @click="handleEdit" class="px-6 py-2 bg-[#1a1a1a] hover:bg-black text-white rounded-xl font-bold shadow-sm transition">
        Зберегти
      </button>
    </div>
  </Modal>
  </div>
</template>

