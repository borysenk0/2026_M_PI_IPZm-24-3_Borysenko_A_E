<script setup lang="ts">
import { computed, onMounted } from 'vue';
import { useInventoryStore } from '@/stores/inventory';

const inventoryStore = useInventoryStore();

onMounted(() => {
  inventoryStore.loadIngredients();
});

const rows = computed(() =>
  [...inventoryStore.items].sort((a, b) => a.name.localeCompare(b.name)),
);
</script>

<template>
  <section class="space-y-4">
    <header>
      <h2 class="text-lg font-bold text-gray-900">Склад (інгредієнти)</h2>
      <p class="text-sm text-gray-600">
        Рядки із залишком нижче порогу підсвічуються червоним.
      </p>
    </header>

    <div class="bg-white border border-gray-200 rounded-2xl overflow-hidden">
      <table class="w-full text-left">
        <thead class="bg-gray-50 border-b border-gray-200">
          <tr class="text-xs uppercase tracking-wider text-gray-600">
            <th class="p-3">Інгредієнт</th>
            <th class="p-3">Од.</th>
            <th class="p-3">Залишок</th>
            <th class="p-3">Поріг</th>
            <th class="p-3 text-right">Дії</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="item in rows"
            :key="item.id"
            class="border-b border-gray-100 hover:bg-gray-50"
            :class="item.currentStock <= item.minThreshold ? 'bg-red-50' : ''"
          >
            <td class="p-3 font-semibold text-gray-900">{{ item.name }}</td>
            <td class="p-3 text-sm text-gray-700">{{ item.unit }}</td>
            <td class="p-3 text-sm">
              <span :class="item.currentStock <= item.minThreshold ? 'text-red-700 font-semibold' : 'text-gray-700'">
                {{ item.currentStock }}
              </span>
            </td>
            <td class="p-3 text-sm text-gray-700">{{ item.minThreshold }}</td>
            <td class="p-3 text-right">
              <div class="inline-flex gap-2">
                <button
                  type="button"
                  class="px-3 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-sm font-semibold"
                >
                  Редагувати
                </button>
                <button
                  type="button"
                  class="px-3 py-2 rounded-lg border border-red-200 bg-white hover:bg-red-50 text-sm font-semibold text-red-700"
                >
                  Видалити
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</template>

