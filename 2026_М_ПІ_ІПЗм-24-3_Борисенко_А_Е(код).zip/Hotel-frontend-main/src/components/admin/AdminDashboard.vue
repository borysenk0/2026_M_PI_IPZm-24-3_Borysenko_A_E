<script setup lang="ts">
import { computed } from 'vue';
import { useHotelStore } from '@/stores/hotel';
import VueApexCharts from 'vue3-apexcharts';

const hotel = useHotelStore();

// System statistics
const stats = computed(() => [
  { label: 'Користувачів', value: hotel.state.users.length, color: 'text-indigo-600', bg: 'bg-indigo-50' },
  { label: 'Кімнат', value: hotel.state.rooms.length, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  { label: 'Активних Бронювань', value: hotel.state.bookings.filter(b => b.status === 'PENDING' || b.status === 'CONFIRMED' || b.status === 'CHECKED_IN').length, color: 'text-amber-600', bg: 'bg-amber-50' },
  { label: 'Замовлень Ресторану', value: hotel.state.orders.length, color: 'text-rose-600', bg: 'bg-rose-50' },
]);

// Room Statuses (Pie Chart)
const roomStatusSeries = computed(() => {
  let occ = 0, avail = 0, res = 0, main = 0;
  hotel.state.rooms.forEach(r => {
    if (r.status === 'OCCUPIED') occ++;
    else if (r.status === 'AVAILABLE') avail++;
    else if (r.status === 'RESERVED') res++;
    else main++;
  });
  return [avail, occ, res, main];
});

const roomStatusOptions = {
  chart: { type: 'donut', fontFamily: 'Inter, sans-serif' },
  labels: ['Вільні', 'Зайняті', 'Заброньовані', 'Обслуговування'],
  colors: ['#10b981', '#ef4444', '#f59e0b', '#6b7280'],
  plotOptions: {
    pie: {
      expandOnClick: false,
      donut: { size: '65%' }
    }
  },
  dataLabels: { enabled: false },
};

// Booking Activity (Bar Chart Mock based on real bookings mapped to recent ids conceptually)
const currentMonthBookings = computed(() => {
  // Real logic would be formatting created_at, but we simply slice to show concept
  const lastBookings = hotel.state.bookings.slice(-10);
  return [{
    name: 'Бронювання',
    data: lastBookings.map(b => b.id)
  }];
});

const bookingOptions = {
  chart: { type: 'bar', toolbar: { show: false }, fontFamily: 'Inter, sans-serif' },
  colors: ['#3b82f6'],
  plotOptions: {
    bar: { borderRadius: 4, columnWidth: '50%' }
  },
  dataLabels: { enabled: false },
  xaxis: { categories: hotel.state.bookings.slice(-10).map((_, i) => `Запис ${i+1}`) },
  yaxis: { title: { text: "ID Бронювання" } }
};

</script>

<template>
  <div class="space-y-6">
    <!-- Stat Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <div 
        v-for="stat in stats" :key="stat.label"
        class="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm flex flex-col justify-between"
      >
        <span class="text-xs font-bold text-gray-500 uppercase tracking-wider">{{ stat.label }}</span>
        <div class="mt-4 flex items-center justify-between">
          <span class="text-4xl font-extrabold text-gray-900">{{ stat.value }}</span>
          <div :class="`w-12 h-12 rounded-full flex items-center justify-center ${stat.bg}`">
            <svg xmlns="http://www.w3.org/2000/svg" :class="`h-6 w-6 ${stat.color}`" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
          </div>
        </div>
      </div>
    </div>

    <!-- Charts Area -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div class="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm lg:col-span-2">
        <h3 class="text-lg font-bold text-gray-900 mb-4">Останні Бронювання</h3>
        <VueApexCharts type="bar" height="300" :options="bookingOptions" :series="currentMonthBookings" />
      </div>

      <div class="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
        <h3 class="text-lg font-bold text-gray-900 mb-4">Статус номерного фонду</h3>
        <div class="flex items-center justify-center min-h-[300px]">
          <VueApexCharts type="donut" width="100%" :options="roomStatusOptions" :series="roomStatusSeries" />
        </div>
      </div>
    </div>
  </div>
</template>
