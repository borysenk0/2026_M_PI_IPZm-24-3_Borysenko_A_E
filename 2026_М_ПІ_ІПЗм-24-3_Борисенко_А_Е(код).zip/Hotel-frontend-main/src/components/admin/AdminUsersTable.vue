<script setup lang="ts">
import { computed, ref } from 'vue';
import { useHotelStore } from '@/stores/hotel';
import { useNotification } from '@kyvg/vue3-notification';
import Modal from '@/components/ui/Modal.vue';
import api from '@/api';

const hotel = useHotelStore();
const { notify } = useNotification();

const isEditOpen = ref(false);
const editForm = ref({
  id: 0,
  full_name: '',
  email: '',
  role_id: null as number | null,
});

const openEdit = (row: any) => {
  const u = hotel.state.users.find(user => user.id === row.id);
  if (u) {
    editForm.value = { id: u.id, full_name: u.full_name, email: u.email, role_id: u.role_id };
    isEditOpen.value = true;
  }
};

const handleEdit = async () => {
  if (!editForm.value.full_name || !editForm.value.email || !editForm.value.role_id) {
    notify({ type: 'error', title: 'Помилка', text: 'Заповніть всі поля' });
    return;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(editForm.value.email)) {
    notify({ type: 'error', title: 'Помилка', text: 'Некоректний формат email' });
    return;
  }

  try {
    const payload = { ...editForm.value };
    const id = payload.id;
    delete payload.id;
    await api.put(`/users/${id}`, payload);
    await hotel.fetchAll();
    notify({ type: 'success', title: 'Успішно', text: 'Користувача оновлено' });
    isEditOpen.value = false;
  } catch(e) {
    notify({ type: 'error', title: 'Помилка', text: 'Користувача не знайдено або помилка сервера' });
  }
};

const handleDelete = async (id: number) => {
  if (!confirm('Видалити користувача?')) return;
  try {
    await api.delete(`/users/${id}`);
    await hotel.fetchAll();
    notify({ type: 'success', title: 'Успішно', text: 'Користувача видалено' });
  } catch(e) {
    notify({ type: 'error', title: 'Помилка', text: 'Помилка при видаленні' });
  }
};

const rows = computed(() =>
  hotel.state.users.map((u) => {
    const role = hotel.state.roles.find((r) => r.id === u.role_id);
    return {
      id: u.id,
      fullName: u.full_name,
      email: u.email,
      roleName: role?.name ?? '—',
    };
  }),
);

const filterText = ref('');
const filterRole = ref('');

const filteredRows = computed(() => {
  return rows.value.filter((r) => {
    if (filterText.value) {
      const q = filterText.value.toLowerCase();
      if (!r.fullName.toLowerCase().includes(q) && !r.email.toLowerCase().includes(q)) {
        return false;
      }
    }
    if (filterRole.value && r.roleName !== filterRole.value) {
      return false;
    }
    return true;
  });
});

const clearFilters = () => {
  filterText.value = '';
  filterRole.value = '';
};
</script>

<template>
  <div>
    <section class="space-y-4">
      <header class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 class="text-lg font-bold text-gray-900">Користувачі</h2>
          <p class="text-sm text-gray-600">Повний список користувачів системи та їх ролей.</p>
        </div>
      </header>

      <!-- Filter Ribbon -->
      <div class="bg-gray-50 border border-gray-200 rounded-2xl p-4 flex flex-wrap gap-4 items-end">
        <div class="flex-1 min-w-[200px]">
          <label class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Пошук за ПІБ або Email</label>
          <input v-model="filterText" type="text" placeholder="Іван Іванов..." class="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
        </div>
        <div class="w-48">
          <label class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Роль</label>
          <select v-model="filterRole" class="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
            <option value="">Усі ролі</option>
            <option v-for="r in hotel.state.roles" :key="r.id" :value="r.name">{{ r.name }}</option>
          </select>
        </div>
        <button @click="clearFilters" v-if="filterText || filterRole" class="px-4 py-2 border border-gray-300 rounded-xl bg-white text-sm font-semibold text-gray-700 hover:bg-gray-100 transition">
          Скинути
        </button>
      </div>

      <div class="bg-white border border-gray-200 rounded-2xl overflow-hidden">
        <table class="w-full text-left">
          <thead class="bg-gray-50 border-b border-gray-200">
            <tr class="text-xs uppercase tracking-wider text-gray-600">
              <th class="p-3">ID</th>
              <th class="p-3">ПІБ</th>
              <th class="p-3">Email</th>
              <th class="p-3">Роль</th>
              <th class="p-3 text-right">Дії</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="row in filteredRows"
              :key="row.id"
              class="border-b border-gray-100 hover:bg-gray-50"
            >
              <td class="p-3 text-sm text-gray-700">{{ row.id }}</td>
              <td class="p-3 font-semibold text-gray-900">{{ row.fullName }}</td>
              <td class="p-3 text-sm text-gray-800">{{ row.email }}</td>
              <td class="p-3 text-sm text-gray-700">{{ row.roleName }}</td>
              <td class="p-3 text-right">
                <div class="inline-flex gap-2">
                  <button
                    type="button"
                    @click="openEdit(row)"
                    class="px-3 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-sm font-semibold"
                  >
                    Редагувати
                  </button>
                  <button
                    type="button"
                    @click="handleDelete(row.id)"
                    class="px-3 py-2 rounded-lg border border-red-200 bg-white hover:bg-red-50 text-sm font-semibold text-red-700"
                  >
                    Видалити
                  </button>
                </div>
              </td>
            </tr>
            <tr v-if="filteredRows.length === 0">
              <td colspan="5" class="p-8 text-center text-sm text-gray-500 bg-gray-50/50">
                Користувачів не знайдено.
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <Modal :isOpen="isEditOpen" title="Редагувати користувача" @close="isEditOpen = false">
      <div class="space-y-4">
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">ПІБ</label>
          <input v-model="editForm.full_name" type="text" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" placeholder="Іван Іванов" />
        </div>
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Email</label>
          <input v-model="editForm.email" type="email" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none" placeholder="ivan@example.com" />
        </div>
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-1">Роль</label>
          <select v-model="editForm.role_id" class="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-black outline-none bg-white">
            <option v-for="r in hotel.state.roles" :key="r.id" :value="r.id">
              {{ r.name }}
            </option>
          </select>
        </div>
      </div>
      <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-gray-100">
        <button @click="isEditOpen = false" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-xl font-semibold transition">
          Скасувати
        </button>
        <button @click="handleEdit" class="px-6 py-2 bg-[#1a1a1a] hover:bg-black text-white rounded-xl font-bold shadow-sm transition">
          Зберегти
        </button>
      </div>
    </Modal>
  </div>
</template>

