<script setup lang="ts">
import { computed, reactive, ref } from 'vue';
import { useInventoryStore } from '@/stores/inventory';

const inventoryStore = useInventoryStore();

type RecipeRow = {
  ingredientId: number | null;
  amount: number | null;
};

const form = reactive({
  name: '',
  category: 'Сніданки',
  price: 0,
  prepTimeMinutes: 10,
  rows: [{ ingredientId: null, amount: null }] as RecipeRow[],
});

const canSubmit = computed(() => {
  if (!form.name.trim()) return false;
  if (form.price <= 0) return false;
  if (form.prepTimeMinutes < 0) return false;
  const validRows = form.rows.filter((r) => r.ingredientId && r.amount && r.amount > 0);
  return validRows.length > 0;
});

const addRow = () => {
  form.rows.push({ ingredientId: null, amount: null });
};

const removeRow = (idx: number) => {
  if (form.rows.length === 1) return;
  form.rows.splice(idx, 1);
};

const ingredientOptions = computed(() =>
  [...inventoryStore.items].sort((a, b) => a.name.localeCompare(b.name)),
);

const submit = () => {
  // Пока mock: позже будет POST /menu-items + /recipes
  const payload = {
    name: form.name,
    category: form.category,
    price: form.price,
    prepTimeMinutes: form.prepTimeMinutes,
    recipe: form.rows
      .filter((r) => r.ingredientId && r.amount && r.amount > 0)
      .map((r) => ({
        ingredientId: r.ingredientId!,
        amount: r.amount!,
      })),
  };

  // eslint-disable-next-line no-console
  console.log('New menu item payload (mock)', payload);
  // eslint-disable-next-line no-alert
  alert('Створено (mock). Дивись payload у консолі.');

  form.name = '';
  form.price = 0;
  form.prepTimeMinutes = 10;
  form.rows = [{ ingredientId: null, amount: null }];
};
</script>

<template>
  <section class="space-y-6">
    <header>
      <h2 class="text-lg font-bold text-gray-900">Ресторан · Рецепти</h2>
      <p class="text-sm text-gray-600">
        Форма створення страви з динамічним додаванням інгредієнтів.
      </p>
    </header>

    <div class="bg-white border border-gray-200 rounded-2xl p-5">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label class="block text-xs uppercase tracking-wider text-gray-600 mb-1">Назва</label>
          <input
            v-model="form.name"
            type="text"
            class="w-full px-3 py-2 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-black/10"
            placeholder="Наприклад: Омлет готельний"
          />
        </div>
        <div>
          <label class="block text-xs uppercase tracking-wider text-gray-600 mb-1">Категорія</label>
          <input
            v-model="form.category"
            type="text"
            class="w-full px-3 py-2 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-black/10"
            placeholder="Сніданки"
          />
        </div>
        <div>
          <label class="block text-xs uppercase tracking-wider text-gray-600 mb-1">Ціна</label>
          <input
            v-model.number="form.price"
            type="number"
            min="0"
            step="1"
            class="w-full px-3 py-2 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-black/10"
          />
        </div>
        <div>
          <label class="block text-xs uppercase tracking-wider text-gray-600 mb-1">Час (хв)</label>
          <input
            v-model.number="form.prepTimeMinutes"
            type="number"
            min="0"
            step="1"
            class="w-full px-3 py-2 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-black/10"
          />
        </div>
      </div>

      <div class="mt-6">
        <div class="flex items-center justify-between mb-2">
          <h3 class="font-semibold text-gray-900">Рецептура</h3>
          <button
            type="button"
            class="px-3 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-sm font-semibold"
            @click="addRow"
          >
            + Додати інгредієнт
          </button>
        </div>

        <div class="space-y-2">
          <div
            v-for="(row, idx) in form.rows"
            :key="idx"
            class="grid grid-cols-1 md:grid-cols-12 gap-2 items-center"
          >
            <div class="md:col-span-7">
              <select
                v-model.number="row.ingredientId"
                class="w-full px-3 py-2 border border-gray-200 rounded-xl bg-white outline-none focus:ring-2 focus:ring-black/10"
              >
                <option :value="null">Оберіть інгредієнт</option>
                <option v-for="ing in ingredientOptions" :key="ing.id" :value="ing.id">
                  {{ ing.name }}
                </option>
              </select>
            </div>
            <div class="md:col-span-3">
              <input
                v-model.number="row.amount"
                type="number"
                min="0"
                step="0.001"
                class="w-full px-3 py-2 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-black/10"
                placeholder="Кіл-ть"
              />
            </div>
            <div class="md:col-span-2 flex justify-end">
              <button
                type="button"
                class="px-3 py-2 rounded-lg border border-red-200 bg-white hover:bg-red-50 text-sm font-semibold text-red-700"
                @click="removeRow(idx)"
              >
                Видалити
              </button>
            </div>
          </div>
        </div>
      </div>

      <div class="mt-6 flex justify-end">
        <button
          type="button"
          class="px-4 py-2 rounded-xl bg-black text-white font-semibold hover:bg-gray-900 disabled:opacity-40"
          :disabled="!canSubmit"
          @click="submit"
        >
          Створити страву (mock)
        </button>
      </div>
    </div>
  </section>
</template>

